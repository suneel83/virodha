import React from "react";
import "./NotificationManagementCompose.css";

function NotificationManagementCompose(props) {
  const {
    overlapGroup1,
    notifyUsers,
    path2,
    rectangleCopy11,
    path3,
    selectUser,
    polygon3,
    title,
    notificationType,
    polygon5,
    message,
    attachment,
    attachmentSvgrepoCom,
    sendNotification,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="notification-management-compose screen">
        <div className="overlap-group1-27" style={{ backgroundImage: `url(${overlapGroup1})` }}>
          <div className="flex-row-16">
            <div className="notify-users">{notifyUsers}</div>
            <div className="icons">
              <div className="ui-gambling-website">
                <div className="x4-34">
                  <div className="notification">
                    <div className="overlap-group-57">
                      <img className="path" src="/img/path-1x-png@1x.png" />
                      <img className="path-11" src={path2} />
                      <img className="oval" src="/img/oval@1x.png" />
                      <img className="rectangle-copy-11" src={rectangleCopy11} />
                      <img className="path-12" src={path3} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="flex-row-17">
            <div className="select-user poppins-medium-cape-cod-12px">{selectUser}</div>
            <div className="overlap-group-56">
              <img className="polygon" src={polygon3} />
            </div>
          </div>
          <div className="flex-row-18">
            <div className="title-1 poppins-medium-cape-cod-12px">{title}</div>
            <div className="rectangle-2117-1"></div>
          </div>
          <div className="flex-row-19">
            <div className="notification-type poppins-medium-cape-cod-12px">{notificationType}</div>
            <div className="overlap-group-56">
              <img className="polygon" src={polygon5} />
            </div>
          </div>
          <div className="flex-row-20">
            <div className="message poppins-medium-cape-cod-12px">{message}</div>
            <div className="rectangle-2118"></div>
          </div>
          <div className="flex-row-21">
            <div className="attachment poppins-medium-cape-cod-12px">{attachment}</div>
            <div className="overlap-group3-16">
              <img className="icon-paperclip" src={attachmentSvgrepoCom} />
            </div>
          </div>
          <div className="overlap-group4-12">
            <div className="send-notification">{sendNotification}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default NotificationManagementCompose;
