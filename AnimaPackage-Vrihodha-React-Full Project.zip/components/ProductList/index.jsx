import React from "react";
import { Link } from "react-router-dom";
import Group35 from "../Group35";
import AvatarSvgrepoCom from "../AvatarSvgrepoCom";
import Group42 from "../Group42";
import B from "../B";
import "./ProductList.css";

function ProductList(props) {
  const {
    x18,
    leaf11,
    dashboard,
    orderManagement,
    manageNotifications,
    adminPanel,
    x41,
    x42,
    x43,
    leaf12,
    leaf2,
    untitledDesign,
    laptopSvgrepoCom,
    iconUser,
    menuOrderSvgrepoCom,
    iconNotifications,
    sellProductSvgrepoCom,
    subCategoryList,
    productsList1,
    enterArrowSvgrepoCom1,
    enterArrowSvgrepoCom2,
    welcome,
    admin,
    path77,
    path78,
    productManagement,
    line1,
    overlapGroup2,
    productsList2,
    search,
    plusSvgrepoCom1,
    addProduct,
    text3,
    category,
    subCategory,
    productName,
    prodId,
    action,
    number1,
    number2,
    poovan,
    fruits1,
    place,
    textEdit1,
    iconTrash1,
    number3,
    fruits2,
    apple,
    kashmirAppleG1,
    number4,
    textEdit2,
    iconTrash2,
    number5,
    fruits3,
    color,
    australianOrchid,
    number6,
    textEdit3,
    iconTrash3,
    path74,
    number7,
    fruits4,
    grapes,
    sonaGrapes,
    number8,
    textEdit4,
    iconTrash4,
    number9,
    vegitables,
    spinach,
    ponnakanni,
    number10,
    textEdit5,
    iconTrash5,
    number11,
    number12,
    number13,
    number14,
    avatarSvgrepoComProps,
    b1Props,
    b2Props,
    b3Props,
    b4Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="product-list screen">
        <div className="overlap-group14-4">
          <div className="overlap-group3-9">
            <div className="rectangle-2-6"></div>
            <img className="x18-6" src={x18} />
            <div className="rectangle-1-6"></div>
            <img className="leaf1-12" src={leaf11} />
            <Link to="/dashboard-pending-orders">
              <div className="rectangle-3-2"></div>
            </Link>
            <div className="rectangle-7-3"></div>
            <div className="rectangle-8-3"></div>
            <div className="dashboard-3 poppins-medium-don-juan-17px">{dashboard}</div>
            <div className="order-management-6 poppins-medium-don-juan-17px">{orderManagement}</div>
            <div className="manage-notifications-6 poppins-medium-don-juan-17px">{manageNotifications}</div>
            <div className="admin-panel-6 poppins-semi-bold-chicago-33px">{adminPanel}</div>
            <img className="x4-18" src={x41} />
            <img className="x4-19" src={x42} />
            <img className="x4-20" src={x43} />
            <img className="leaf1-13" src={leaf12} />
            <img className="leaf2-6" src={leaf2} />
            <img className="untitled-design-7" src={untitledDesign} />
            <img className="laptop-svgrepo-com-3" src={laptopSvgrepoCom} />
            <Group35 />
            <img className="icon-user-4" src={iconUser} />
            <img className="menu-order-svgrepo-com-7" src={menuOrderSvgrepoCom} />
            <img className="icon-notifications-4" src={iconNotifications} />
            <div className="rectangle-6-3"></div>
            <img className="sell-product-svgrepo-com-6" src={sellProductSvgrepoCom} />
            <Link to="/sub-category-list">
              <div className="sub-category-list poppins-medium-lemon-glacier-14px">{subCategoryList}</div>
            </Link>
            <div className="products-list poppins-medium-lemon-glacier-14px">{productsList1}</div>
            <img className="enter-arrow-svgrepo-com-4" src={enterArrowSvgrepoCom1} />
            <img className="enter-arrow-svgrepo-com-5" src={enterArrowSvgrepoCom2} />
            <div className="welcome-6 poppins-medium-don-juan-14px">{welcome}</div>
            <div className="admin-6 poppins-medium-don-juan-14px">{admin}</div>
            <div className="path-container-7">
              <img className="path-77-3" src={path77} />
              <img className="path-78-3" src={path78} />
            </div>
            <AvatarSvgrepoCom
              path82={avatarSvgrepoComProps.path82}
              path85={avatarSvgrepoComProps.path85}
              path86={avatarSvgrepoComProps.path86}
              path87={avatarSvgrepoComProps.path87}
              path89={avatarSvgrepoComProps.path89}
            />
            <Group42 />
            <div className="product-management-3 poppins-medium-white-17px">{productManagement}</div>
          </div>
          <img className="line-1-4" src={line1} />
          <div className="overlap-group2-10" style={{ backgroundImage: `url(${overlapGroup2})` }}>
            <div className="flex-row-2">
              <div className="products-list-1 poppins-semi-bold-everglade-30px">{productsList2}</div>
              <div className="search-3 poppins-semi-bold-cape-cod-18px">{search}</div>
              <div className="rectangle-2112-3"></div>
              <a href="javascript:ShowOverlay('add-product', 'animate-appear');">
                <div className="group-39">
                  <div className="plus-svgrepo-com-1-1" style={{ backgroundImage: `url(${plusSvgrepoCom1})` }}></div>
                  <div className="add-product poppins-medium-white-17px">{addProduct}</div>
                </div>
              </a>
            </div>
            <div className="overlap-group6-5 poppins-medium-cape-cod-18px">
              <div className="text-3">{text3}</div>
              <div className="category-1">{category}</div>
              <B className={b1Props.className} />
              <div className="sub-category">{subCategory}</div>
              <B className={b2Props.className} />
              <div className="product-name">{productName}</div>
              <B className={b3Props.className} />
              <div className="prod-id">{prodId}</div>
              <B className={b4Props.className} />
              <div className="action-1">{action}</div>
            </div>
            <div className="overlap-group7-4">
              <a href="javascript:ShowOverlay('edit-product', 'animate-appear');">
                <div className="rectangle-11-2"></div>
              </a>
              <div className="number-83 poppins-normal-cape-cod-18px">{number1}</div>
              <div className="number-84 poppins-semi-bold-dell-18px">{number2}</div>
              <div className="poovan poppins-semi-bold-dell-18px">{poovan}</div>
              <div className="fruits-1 poppins-semi-bold-dell-18px">{fruits1}</div>
              <div className="place poppins-semi-bold-dell-18px">{place}</div>
              <a href="javascript:ShowOverlay('edit-product', 'animate-appear');">
                <img className="text-edit-14" src={textEdit1} />
              </a>
              <img className="icon-trash-17" src={iconTrash1} />
            </div>
            <div className="overlap-group5-3">
              <div className="number-85 poppins-normal-cape-cod-18px">{number3}</div>
              <div className="fruits-2 poppins-semi-bold-dell-18px">{fruits2}</div>
              <div className="apple poppins-semi-bold-dell-18px">{apple}</div>
              <div className="kashmir-apple-g1 poppins-semi-bold-dell-18px">{kashmirAppleG1}</div>
              <div className="number-86 poppins-semi-bold-dell-18px">{number4}</div>
              <img className="text-edit-15" src={textEdit2} />
              <img className="icon-trash-15" src={iconTrash2} />
            </div>
            <div className="overlap-group9-4">
              <div className="number-87 poppins-normal-cape-cod-18px">{number5}</div>
              <div className="fruits-3 poppins-semi-bold-dell-18px">{fruits3}</div>
              <div className="color poppins-semi-bold-dell-18px">{color}</div>
              <div className="australian-orchid poppins-semi-bold-dell-18px">{australianOrchid}</div>
              <div className="number-88 poppins-semi-bold-dell-18px">{number6}</div>
              <img className="text-edit-16" src={textEdit3} />
              <img className="icon-trash-16" src={iconTrash3} />
            </div>
            <div className="overlap-group8-5">
              <img className="path-74-1" src={path74} />
              <div className="flex-row-3">
                <div className="number-81 poppins-normal-cape-cod-18px">{number7}</div>
                <div className="fruits-4 poppins-semi-bold-dell-18px">{fruits4}</div>
                <div className="grapes poppins-semi-bold-dell-18px">{grapes}</div>
                <div className="sona-grapes poppins-semi-bold-dell-18px">{sonaGrapes}</div>
                <div className="number-89 poppins-semi-bold-dell-18px">{number8}</div>
                <img className="text-edit-17" src={textEdit4} />
                <img className="icon-trash-16" src={iconTrash4} />
              </div>
            </div>
            <div className="overlap-group4-6">
              <div className="number-81 poppins-normal-cape-cod-18px">{number9}</div>
              <div className="vegitables-1 poppins-semi-bold-dell-18px">{vegitables}</div>
              <div className="spinach poppins-semi-bold-dell-18px">{spinach}</div>
              <div className="ponnakanni poppins-semi-bold-dell-18px">{ponnakanni}</div>
              <div className="number-90 poppins-semi-bold-dell-18px">{number10}</div>
              <img className="text-edit-18" src={textEdit5} />
              <img className="icon-trash-15" src={iconTrash5} />
            </div>
            <div className="overlap-group-container-6">
              <div className="overlap-group11-5">
                <div className="number-91 poppins-medium-shady-lady-15px">{number11}</div>
              </div>
              <div className="overlap-group1-21">
                <div className="number-82 poppins-medium-shady-lady-15px">{number12}</div>
              </div>
              <div className="overlap-group1-21">
                <div className="number-82 poppins-medium-shady-lady-15px">{number13}</div>
              </div>
              <div className="overlap-group10-1">
                <div className="number-92 poppins-medium-shady-lady-15px">{number14}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProductList;
