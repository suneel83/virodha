import React from "react";
import "./EditProduct.css";

function EditProduct(props) {
  const {
    editProduct,
    productCategory,
    productName,
    productImage,
    mrp,
    unit,
    description,
    selectProductCategory,
    polygon1,
    upload,
    sellingPrice,
    qty,
    close,
    update,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="edit-product screen">
        <div className="overlap-group-64">
          <div className="edit-product-1 poppins-semi-bold-cape-cod-21px">{editProduct}</div>
          <div className="flex-row-42">
            <div className="flex-col-30 poppins-medium-cape-cod-13px">
              <div className="product-category-1">{productCategory}</div>
              <p className="product-name-3">{productName}</p>
              <div className="product-image-1">{productImage}</div>
              <div className="mrp-4">{mrp}</div>
              <div className="unit-1">{unit}</div>
              <div className="description-5">{description}</div>
            </div>
            <div className="flex-col-31">
              <div className="overlap-group3-23">
                <div className="select-product-category-1 poppins-medium-westar-11px">{selectProductCategory}</div>
                <img className="polygon-1-1" src={polygon1} />
              </div>
              <div className="rectangle-2109-1"></div>
              <div className="overlap-group6-13">
                <div className="rectangle-2111-5"></div>
                <div className="upload-5 poppins-normal-white-12px">{upload}</div>
              </div>
              <div className="flex-row-43">
                <div className="rectangle-2178"></div>
                <div className="overlap-group5-14">
                  <div className="selling-price-3 poppins-medium-cape-cod-13px">{sellingPrice}</div>
                  <div className="rectangle-2189"></div>
                </div>
              </div>
              <div className="flex-row-44">
                <div className="rectangle-2179-1"></div>
                <div className="qty-5 poppins-medium-cape-cod-13px">{qty}</div>
                <div className="rectangle-2184"></div>
              </div>
              <div className="rectangle-2110-2"></div>
              <div className="overlap-group-container-15">
                <div className="overlap-group4-19">
                  <div className="close-6 poppins-medium-cape-cod-15px">{close}</div>
                </div>
                <div className="overlap-group2-22">
                  <div className="update-3 poppins-medium-romance-15px">{update}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EditProduct;
