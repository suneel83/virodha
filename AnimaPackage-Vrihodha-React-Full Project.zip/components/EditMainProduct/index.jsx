import React from "react";
import "./EditMainProduct.css";

function EditMainProduct(props) {
  const {
    flexCol,
    editMainProduct,
    category,
    vegitables,
    polygon3,
    productImage,
    upload,
    productName,
    unitKgsLts,
    beetroot,
    kgs,
    update,
    close,
    mrp,
    description,
    number1,
    qty,
    number2,
    sellingPrice,
    number3,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="edit-main-product screen">
        <div className="overlap-group9-14 poppins-medium-cape-cod-15px">
          <div className="flex-col-47" style={{ backgroundImage: `url(${flexCol})` }}>
            <div className="flex-col-48">
              <div className="edit-main-product-1 poppins-semi-bold-everglade-30px">{editMainProduct}</div>
              <div className="flex-row-62">
                <div className="category-7">{category}</div>
                <div className="overlap-group1-33">
                  <div className="vegitables-6">{vegitables}</div>
                  <img className="polygon-3-4" src={polygon3} />
                </div>
                <div className="product-image-4">{productImage}</div>
                <div className="overlap-group5-21">
                  <div className="rectangle-2111-7"></div>
                  <div className="upload-7 poppins-normal-white-12px">{upload}</div>
                </div>
              </div>
            </div>
            <div className="flex-row-63">
              <div className="flex-row-64">
                <div className="flex-col-49">
                  <div className="product-name-6">{productName}</div>
                  <div className="unit-kgs-lts-3">{unitKgsLts}</div>
                </div>
                <div className="flex-col-50">
                  <div className="overlap-group6-20">
                    <div className="beetroot-2 poppins-medium-cape-cod-15px">{beetroot}</div>
                  </div>
                  <div className="overlap-group3-31">
                    <div className="kgs-1 poppins-medium-cape-cod-15px">{kgs}</div>
                  </div>
                  <div className="overlap-group-container-25">
                    <div className="overlap-group2-30">
                      <div className="update-4 poppins-medium-snow-flurry-15px">{update}</div>
                    </div>
                    <div className="overlap-group7-14">
                      <div className="close-10 poppins-medium-cape-cod-15px">{close}</div>
                    </div>
                  </div>
                </div>
                <div className="flex-col-51">
                  <div className="mrp-8">{mrp}</div>
                  <div className="description-9">{description}</div>
                </div>
              </div>
              <div className="flex-col-52">
                <div className="flex-row-65">
                  <div className="overlap-group8-14">
                    <div className="number-165">{number1}</div>
                  </div>
                  <div className="qty-9">{qty}</div>
                  <div className="overlap-group4-27">
                    <div className="number-166">{number2}</div>
                  </div>
                </div>
                <div className="rectangle-2176-3"></div>
              </div>
            </div>
          </div>
          <div className="rectangle-2187-3"></div>
          <div className="selling-price-5">{sellingPrice}</div>
          <div className="number-167">{number3}</div>
        </div>
      </div>
    </div>
  );
}

export default EditMainProduct;
