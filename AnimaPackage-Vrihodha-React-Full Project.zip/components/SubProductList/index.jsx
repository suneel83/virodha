import React from "react";
import { Link } from "react-router-dom";
import Group35 from "../Group35";
import AvatarSvgrepoCom from "../AvatarSvgrepoCom";
import "./SubProductList.css";

function SubProductList(props) {
  const {
    x18,
    leaf11,
    dashboard,
    productManagement1,
    orderManagement,
    manageNotifications,
    adminPanel,
    x41,
    x42,
    x43,
    leaf12,
    leaf2,
    untitledDesign,
    laptopSvgrepoCom,
    usersSilhouettesSvgrepoCom,
    sellProductSvgrepoCom1,
    menuOrderSvgrepoCom,
    notificationSvgrepoCom,
    productManagement2,
    sellProductSvgrepoCom2,
    mainProductsList,
    subProductsList1,
    enterArrowSvgrepoCom1,
    enterArrowSvgrepoCom2,
    welcome,
    admin,
    path77,
    path78,
    line1,
    overlapGroup3,
    subProductsList2,
    search,
    plusSvgrepoCom1,
    addSubProduct,
    text30,
    productCategory,
    subProductName,
    mainProduct,
    subProdId,
    action,
    number1,
    number2,
    poovan,
    fruits1,
    place,
    textEdit1,
    binSvgrepoCom1,
    number3,
    fruits2,
    kashmirAppleG1,
    apple,
    number4,
    textEdit2,
    binSvgrepoCom2,
    number5,
    fruits3,
    australianOrchid,
    color,
    number6,
    textEdit3,
    binSvgrepoCom3,
    path74,
    number7,
    fruits4,
    sonaGrapes,
    grapes,
    number8,
    textEdit4,
    binSvgrepoCom4,
    number9,
    vegitables,
    ponnakanni,
    spinach,
    number10,
    textEdit5,
    binSvgrepoCom5,
    avatarSvgrepoComProps,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="sub-product-list screen">
        <div className="overlap-group10-6">
          <div className="overlap-group2-31">
            <div className="rectangle-2-16"></div>
            <img className="x18-14" src={x18} />
            <div className="rectangle-1-14"></div>
            <img className="leaf1-28" src={leaf11} />
            <Link to="/dashboard">
              <div className="rectangle-3-9"></div>
            </Link>
            <div className="rectangle-6-11"></div>
            <div className="rectangle-7-10"></div>
            <div className="rectangle-8-10"></div>
            <div className="dashboard-11 poppins-medium-don-juan-17px">{dashboard}</div>
            <div className="product-management-11 poppins-medium-don-juan-17px">{productManagement1}</div>
            <div className="order-management-14 poppins-medium-don-juan-17px">{orderManagement}</div>
            <div className="manage-notifications-14 poppins-medium-don-juan-17px">{manageNotifications}</div>
            <div className="admin-panel-14 poppins-semi-bold-chicago-33px">{adminPanel}</div>
            <img className="x4-46" src={x41} />
            <img className="x4-47" src={x42} />
            <img className="x4-48" src={x43} />
            <img className="leaf1-29" src={leaf12} />
            <img className="leaf2-14" src={leaf2} />
            <img className="untitled-design-15" src={untitledDesign} />
            <img className="laptop-svgrepo-com-10" src={laptopSvgrepoCom} />
            <Group35 />
            <img className="users-silhouettes-svgrepo-com-4" src={usersSilhouettesSvgrepoCom} />
            <img className="sell-product-svgrepo-com-15" src={sellProductSvgrepoCom1} />
            <img className="menu-order-svgrepo-com-14" src={menuOrderSvgrepoCom} />
            <img className="notification-svgrepo-com-4" src={notificationSvgrepoCom} />
            <div className="rectangle-6-12"></div>
            <div className="product-management-12 poppins-medium-white-17px">{productManagement2}</div>
            <img className="sell-product-svgrepo-com-16" src={sellProductSvgrepoCom2} />
            <Link to="/main-product-list">
              <div className="main-products-list-2 poppins-medium-lemon-glacier-14px">{mainProductsList}</div>
            </Link>
            <div className="sub-products-list-1 poppins-medium-lemon-glacier-14px">{subProductsList1}</div>
            <img className="enter-arrow-svgrepo-com-14" src={enterArrowSvgrepoCom1} />
            <img className="enter-arrow-svgrepo-com-15" src={enterArrowSvgrepoCom2} />
            <div className="welcome-14 poppins-medium-don-juan-14px">{welcome}</div>
            <div className="admin-13 poppins-medium-don-juan-14px">{admin}</div>
            <div className="path-container-13">
              <img className="path-77-9" src={path77} />
              <img className="path-78-9" src={path78} />
            </div>
            <AvatarSvgrepoCom
              path82={avatarSvgrepoComProps.path82}
              path85={avatarSvgrepoComProps.path85}
              path86={avatarSvgrepoComProps.path86}
              path87={avatarSvgrepoComProps.path87}
              path89={avatarSvgrepoComProps.path89}
            />
          </div>
          <img className="line-1-12" src={line1} />
          <div className="overlap-group3-32" style={{ backgroundImage: `url(${overlapGroup3})` }}>
            <div className="flex-row-66">
              <div className="sub-products-list-2 poppins-semi-bold-everglade-30px">{subProductsList2}</div>
              <div className="search-9 poppins-semi-bold-cape-cod-18px">{search}</div>
              <div className="rectangle-2112-8"></div>
              <a href="javascript:ShowOverlay('add-product', 'animate-appear');">
                <div className="group-39-3">
                  <div className="plus-svgrepo-com-1-8" style={{ backgroundImage: `url(${plusSvgrepoCom1})` }}></div>
                  <div className="add-sub-product poppins-medium-white-17px">{addSubProduct}</div>
                </div>
              </a>
            </div>
            <div className="overlap-group9-15 poppins-medium-cape-cod-18px">
              <div className="text-30">{text30}</div>
              <div className="product-category-4">{productCategory}</div>
              <div className="sub-product-name-3">{subProductName}</div>
              <div className="main-product">{mainProduct}</div>
              <div className="sub-prod-id">{subProdId}</div>
              <div className="action-6">{action}</div>
            </div>
            <div className="overlap-group7-15">
              <a href="javascript:ShowOverlay('edit-product', 'animate-appear');">
                <div className="rectangle-11-4"></div>
              </a>
              <div className="number-169 poppins-normal-cape-cod-18px">{number1}</div>
              <div className="number-170 poppins-semi-bold-dell-18px">{number2}</div>
              <div className="poovan-2 poppins-semi-bold-dell-18px">{poovan}</div>
              <div className="fruits-17 poppins-semi-bold-dell-18px">{fruits1}</div>
              <div className="place-4 poppins-semi-bold-dell-18px">{place}</div>
              <a href="javascript:ShowOverlay('edit-product', 'animate-appear');">
                <img className="text-edit-32" src={textEdit1} />
              </a>
              <img className="bin-svgrepo-com-9" src={binSvgrepoCom1} />
            </div>
            <div className="overlap-group8-15">
              <div className="number-168 poppins-normal-cape-cod-18px">{number3}</div>
              <div className="fruits-18 poppins-semi-bold-dell-18px">{fruits2}</div>
              <div className="kashmir-apple-g1-2 poppins-semi-bold-dell-18px">{kashmirAppleG1}</div>
              <div className="apple-4 poppins-semi-bold-dell-18px">{apple}</div>
              <div className="number-171 poppins-semi-bold-dell-18px">{number4}</div>
              <img className="text-edit-30" src={textEdit2} />
              <img className="bin-svgrepo-com-8" src={binSvgrepoCom2} />
            </div>
            <div className="overlap-group-70">
              <div className="number-168 poppins-normal-cape-cod-18px">{number5}</div>
              <div className="fruits-19 poppins-semi-bold-dell-18px">{fruits3}</div>
              <div className="australian-orchid-2 poppins-semi-bold-dell-18px">{australianOrchid}</div>
              <div className="color-4 poppins-semi-bold-dell-18px">{color}</div>
              <div className="number-172 poppins-semi-bold-dell-18px">{number6}</div>
              <img className="text-edit-30" src={textEdit3} />
              <img className="bin-svgrepo-com-8" src={binSvgrepoCom3} />
            </div>
            <div className="overlap-group4-28">
              <img className="path-74-6" src={path74} />
              <div className="flex-row-67">
                <div className="number-173 poppins-normal-cape-cod-18px">{number7}</div>
                <div className="fruits-20 poppins-semi-bold-dell-18px">{fruits4}</div>
                <div className="sona-grapes-3 poppins-semi-bold-dell-18px">{sonaGrapes}</div>
                <div className="grapes-5 poppins-semi-bold-dell-18px">{grapes}</div>
                <div className="number-174 poppins-semi-bold-dell-18px">{number8}</div>
                <img className="text-edit-31" src={textEdit4} />
                <img className="bin-svgrepo-com-8" src={binSvgrepoCom4} />
              </div>
            </div>
            <div className="overlap-group-70">
              <div className="number-175 poppins-normal-cape-cod-18px">{number9}</div>
              <div className="vegitables-7 poppins-semi-bold-dell-18px">{vegitables}</div>
              <div className="ponnakanni-2 poppins-semi-bold-dell-18px">{ponnakanni}</div>
              <div className="spinach-4 poppins-semi-bold-dell-18px">{spinach}</div>
              <div className="number-176 poppins-semi-bold-dell-18px">{number10}</div>
              <img className="text-edit-31" src={textEdit5} />
              <img className="bin-svgrepo-com-8" src={binSvgrepoCom5} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SubProductList;
