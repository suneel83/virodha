import React from "react";
import "./OrderDetails.css";

function OrderDetails(props) {
  const {
    orderDetails,
    orderId,
    car1009311,
    address,
    customerName,
    hendry,
    contactNumber,
    phone,
    a453RdFloorRoh,
    status,
    rectangle2096,
    delivered,
    spanText1,
    spanText2,
    spanText3,
    spanText4,
    spanText5,
    totalRs243,
    surname,
    deliveryCharge,
    rs0,
    close,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="order-details screen" onclick="window.open('javascript:history.back()', '_self');">
        <div className="overlap-group-59 border-1px-dove-gray">
          <div className="order-details-1">{orderDetails}</div>
          <div className="overlap-group1-28">
            <div className="flex-col-18">
              <div className="flex-row-27">
                <div className="order-id-4 poppins-normal-black-15px">{orderId}</div>
                <div className="car-1-0093-11-3 poppins-medium-japanese-laurel-13px">{car1009311}</div>
                <div className="address-1 poppins-normal-black-15px">{address}</div>
              </div>
              <div className="flex-row-28">
                <div className="customer-name-1 poppins-normal-black-15px">{customerName}</div>
                <div className="hendry-5 poppins-normal-japanese-laurel-15px">{hendry}</div>
              </div>
              <div className="flex-row-29">
                <div className="contact-number-1 poppins-normal-black-15px">{contactNumber}</div>
                <div className="phone-7 poppins-normal-japanese-laurel-15px">{phone}</div>
              </div>
            </div>
            <p className="a45-3rd-floorroh-1 poppins-normal-japanese-laurel-15px">{a453RdFloorRoh}</p>
          </div>
          <div className="flex-row-30">
            <div className="status-3 poppins-medium-black-15px">{status}</div>
            <div className="overlap-group3-18">
              <img className="rectangle-2096" src={rectangle2096} />
              <div className="delivered-3 poppins-normal-white-14px">{delivered}</div>
            </div>
          </div>
          <div className="flex-row-31">
            <div className="flex-col-19">
              <p className="product-name-walnut-new">
                <span className="poppins-medium-black-15px">{spanText1}</span>
                <span className="poppins-normal-black-15px">{spanText2}</span>
                <span>{spanText3}</span>
              </p>
              <div className="qty-1-1">
                <span className="poppins-medium-black-15px">{spanText4}</span>
                <span className="poppins-normal-black-15px">{spanText5}</span>
              </div>
              <div className="total-rs-243 poppins-semi-bold-green-house-32px">{totalRs243}</div>
            </div>
            <div className="flex-col-20">
              <div className="surname-1">{surname}</div>
              <div className="overlap-group5-9 poppins-semi-bold-cod-gray-14px">
                <div className="delivery-charge">{deliveryCharge}</div>
                <div className="rs-0">{rs0}</div>
              </div>
              <div className="overlap-group4-14">
                <div className="close-2 poppins-normal-white-15px">{close}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default OrderDetails;
