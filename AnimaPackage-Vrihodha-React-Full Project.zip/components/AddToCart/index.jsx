import React from "react";
import RatingSvgrepoCom2 from "../RatingSvgrepoCom2";
import "./AddToCart.css";

function AddToCart(props) {
  const {
    x9,
    inStock,
    beetroot,
    x15CustomerReviews,
    price1,
    price2,
    quantity,
    inKilograms,
    number,
    addToCart,
    heartSvgrepoCom,
    addToWishlist,
    prev,
    next,
    ratingSvgrepoCom2Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="add-to-cart-3 screen">
        <div className="overlap-group1-36">
          <img className="x9" src={x9} />
          <div className="flex-col-65">
            <div className="overlap-group4-33">
              <div className="rectangle-31-1"></div>
              <div className="in-stock-1 poppins-normal-cod-gray-16px">{inStock}</div>
            </div>
            <div className="overlap-group5-26">
              <div className="beetroot-4 poppins-semi-bold-crusoe-41px">{beetroot}</div>
              <div className="x15-customer-reviews-1 poppins-normal-cod-gray-16px">{x15CustomerReviews}</div>
              <RatingSvgrepoCom2
                iconStar2={ratingSvgrepoCom2Props.iconStar2}
                iconStar3={ratingSvgrepoCom2Props.iconStar3}
                iconStar4={ratingSvgrepoCom2Props.iconStar4}
                className={ratingSvgrepoCom2Props.className}
              />
              <div className="price-6 poppins-bold-sea-green-23px">{price1}</div>
            </div>
            <div className="price-7 poppins-bold-crusoe-34px">{price2}</div>
            <div className="flex-row-77">
              <div className="quantity-1 poppins-semi-bold-crusoe-18px">{quantity}</div>
              <div className="in-kilograms poppins-normal-cod-gray-16px">{inKilograms}</div>
            </div>
            <div className="overlap-group-container-29">
              <div className="overlap-group3-37 border-1px-dove-gray">
                <div className="number-186 poppins-normal-cod-gray-16px">{number}</div>
              </div>
              <div className="overlap-group2-36">
                <div className="add-to-cart-4 poppins-normal-white-15px">{addToCart}</div>
              </div>
            </div>
            <div className="flex-row-78">
              <div className="heart-svgrepo-com-1" style={{ backgroundImage: `url(${heartSvgrepoCom})` }}></div>
              <div className="add-to-wishlist-1 poppins-normal-cod-gray-11px">{addToWishlist}</div>
            </div>
          </div>
          <div className="prev-1 poppins-normal-cod-gray-16px">{prev}</div>
          <div className="flex-col-66">
            <div className="multiply-cross-svgrepo-com-1">
              <div className="group-28-1">
                <div className="overlap-group-80">
                  <div className="rectangle-36-1"></div>
                  <div className="rectangle-37-1"></div>
                </div>
              </div>
            </div>
            <div className="next-1 poppins-normal-cod-gray-16px">{next}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AddToCart;
