import React from "react";
import { Link } from "react-router-dom";
import "./Dashboard.css";

function Dashboard(props) {
  const {
    overlapGroup7,
    goOrganicGetHealthy,
    x18,
    line1,
    leaf11,
    welcome,
    admin,
    group50,
    adminPanel,
    x41,
    x42,
    x43,
    leaf12,
    leaf2,
    untitledDesign,
    group56,
    group35,
    usersSilhouettesSvgrepoCom,
    group57,
    sellProductSvgrepoCom,
    orderContainer,
    menuOrderSvgrepoCom,
    orderManagement,
    notificationSvgrepoCom,
    manageNotifications,
    logOutCircleSvgrepoCom,
    avatarSvgrepoCom,
    overlapGroup4,
    newOrders,
    number1,
    overlapGroup6,
    pendingOrders,
    number2,
    overlapGroup5,
    cancelledOrders,
    number3,
    overlapGroup2,
    appUsers,
    thisWeek,
    number4,
    overlapGroup1,
    orders,
    latestOrderHistory,
    no,
    orderId,
    userDetails,
    status,
    amount,
    details,
    number5,
    car1009311,
    hendry,
    rectangle16,
    delivered1,
    rs28700,
    group55,
    number6,
    car1004341,
    name1,
    delivered2,
    rs54300,
    view1,
    number7,
    car1003156,
    markov,
    rectangle19,
    outForDelivery,
    rs85400,
    overlapGroup16,
    view2,
    number8,
    car1006126,
    name2,
    rectangle18,
    delivered3,
    rs87400,
    view3,
    number9,
    car2002125,
    name3,
    rectangle20,
    cancelled,
    rs90400,
    view4,
    hiAdminCheckYourVrihodhaStatus,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="dashboard-8 screen">
        <div className="overlap-group22-1">
          <div className="overlap-group7-12" style={{ backgroundImage: `url(${overlapGroup7})` }}>
            <div className="go-organic-get-healthy-3 poppins-semi-bold-white-61px">{goOrganicGetHealthy}</div>
          </div>
          <div className="overlap-group3-27">
            <div className="rectangle-2-13"></div>
            <img className="x18-11" src={x18} />
            <img className="line-1-9" src={line1} />
            <div className="rectangle-1-11"></div>
            <img className="leaf1-22" src={leaf11} />
            <div className="welcome-11 poppins-medium-don-juan-14px">{welcome}</div>
            <div className="admin-11 poppins-medium-don-juan-14px">{admin}</div>
            <Link to="/sub-category-list">
              <img className="group-50-3" src={group50} />
            </Link>
            <div className="admin-panel-11 poppins-semi-bold-chicago-33px">{adminPanel}</div>
            <img className="x4-35" src={x41} />
            <img className="x4-36" src={x42} />
            <img className="x4-37" src={x43} />
            <img className="leaf1-23" src={leaf12} />
            <img className="leaf2-11" src={leaf2} />
            <img className="untitled-design-12" src={untitledDesign} />
            <img className="group-56-3" src={group56} />
            <Link to="/user-management-user-data">
              <img className="group-35-13" src={group35} />
            </Link>
            <img className="users-silhouettes-svgrepo-com-2" src={usersSilhouettesSvgrepoCom} />
            <Link to="/category-list">
              <div className="group-42-4">
                <Link to="/category-list">
                  <div className="group-40-4">
                    <img className="group-57-4" src={group57} />
                  </div>
                </Link>
              </div>
            </Link>
            <img className="sell-product-svgrepo-com-12" src={sellProductSvgrepoCom} />
            <Link to="/all-orders">
              <div className="group-44-1">
                <div className="order-container-3" style={{ backgroundImage: `url(${orderContainer})` }}>
                  <img className="menu-order-svgrepo-com-11" src={menuOrderSvgrepoCom} />
                  <div className="order-management-11 poppins-medium-don-juan-17px">{orderManagement}</div>
                </div>
              </div>
            </Link>
            <Link to="/notification-management">
              <div className="group-41-3">
                <img className="notification-svgrepo-com-2" src={notificationSvgrepoCom} />
                <div className="manage-notifications-11 poppins-medium-don-juan-17px">{manageNotifications}</div>
              </div>
            </Link>
            <img className="log-out-circle-svgrepo-com-3" src={logOutCircleSvgrepoCom} />
            <img className="avatar-svgrepo-com-16" src={avatarSvgrepoCom} />
          </div>
          <div
            className="overlap-group4-23 poppins-semi-bold-white-41px"
            style={{ backgroundImage: `url(${overlapGroup4})` }}
          >
            <div className="new-orders">{newOrders}</div>
            <div className="number-148">{number1}</div>
          </div>
          <div
            className="overlap-group6-17 poppins-semi-bold-white-41px"
            style={{ backgroundImage: `url(${overlapGroup6})` }}
          >
            <div className="pending-orders-4">{pendingOrders}</div>
            <div className="number-149">{number2}</div>
          </div>
          <div
            className="overlap-group5-18 poppins-semi-bold-white-41px"
            style={{ backgroundImage: `url(${overlapGroup5})` }}
          >
            <div className="cancelled-orders-4">{cancelledOrders}</div>
            <div className="number-150">{number3}</div>
          </div>
          <div className="overlap-group2-26" style={{ backgroundImage: `url(${overlapGroup2})` }}>
            <div className="flex-row-51">
              <div className="app-users poppins-semi-bold-white-41px">{appUsers}</div>
              <div className="this-week">{thisWeek}</div>
            </div>
            <div className="number-151 poppins-semi-bold-white-41px">{number4}</div>
          </div>
          <div className="overlap-group1-30" style={{ backgroundImage: `url(${overlapGroup1})` }}>
            <div className="orders poppins-semi-bold-everglade-30px">{orders}</div>
            <div className="latest-order-history poppins-normal-cape-cod-15px">{latestOrderHistory}</div>
            <div className="overlap-group12-4 poppins-medium-cape-cod-18px">
              <div className="no-3">{no}</div>
              <div className="order-id-6">{orderId}</div>
              <div className="user-details-2">{userDetails}</div>
              <div className="status-5">{status}</div>
              <div className="amount-2">{amount}</div>
              <div className="details-4">{details}</div>
            </div>
            <div className="overlap-group13-5">
              <div className="number-152 poppins-normal-cape-cod-15px">{number5}</div>
              <div className="car-1-0093-11-5 poppins-normal-cape-cod-15px">{car1009311}</div>
              <div className="hendry-8 poppins-normal-cape-cod-15px">{hendry}</div>
              <div className="overlap-group-68">
                <img className="rectangle-20" src={rectangle16} />
                <div className="delivered-4 poppins-normal-white-14px">{delivered1}</div>
              </div>
              <div className="rs28700-1 poppins-semi-bold-dell-15px">{rs28700}</div>
              <img className="group-55-3" src={group55} />
            </div>
            <div className="overlap-group10-5">
              <div className="number-153 poppins-normal-cape-cod-15px">{number6}</div>
              <div className="car-1-0043-41-4 poppins-normal-cape-cod-15px">{car1004341}</div>
              <div className="name-11 poppins-normal-cape-cod-15px">{name1}</div>
              <div className="overlap-group15-1">
                <div className="rectangle-17-1"></div>
                <div className="delivered-4 poppins-normal-white-14px">{delivered2}</div>
              </div>
              <div className="rs54300-2 poppins-semi-bold-dell-15px">{rs54300}</div>
              <div className="overlap-group14-6">
                <div className="view-11 poppins-normal-white-14px">{view1}</div>
              </div>
            </div>
            <div className="overlap-group11-7">
              <div className="number-154 poppins-normal-cape-cod-15px">{number7}</div>
              <div className="car-1-0031-56-4 poppins-normal-cape-cod-15px">{car1003156}</div>
              <div className="markov-4 poppins-normal-cape-cod-15px">{markov}</div>
              <div className="overlap-group17-3">
                <img className="rectangle-19-1" src={rectangle19} />
                <div className="out-for-delivery-7 poppins-normal-white-14px">{outForDelivery}</div>
              </div>
              <div className="rs85400-2 poppins-semi-bold-dell-15px">{rs85400}</div>
              <div className="overlap-group16-3" style={{ backgroundImage: `url(${overlapGroup16})` }}>
                <div className="view-11 poppins-normal-white-14px">{view2}</div>
              </div>
            </div>
            <div className="overlap-group9-12">
              <div className="number-155 poppins-normal-cape-cod-15px">{number8}</div>
              <div className="car-1-0061-26-2 poppins-normal-cape-cod-15px">{car1006126}</div>
              <div className="name-12 poppins-normal-cape-cod-15px">{name2}</div>
              <div className="overlap-group19-2">
                <img className="rectangle-20" src={rectangle18} />
                <div className="delivered-4 poppins-normal-white-14px">{delivered3}</div>
              </div>
              <div className="rs87400-2 poppins-semi-bold-dell-15px">{rs87400}</div>
              <div className="overlap-group18-2">
                <div className="view-11 poppins-normal-white-14px">{view3}</div>
              </div>
            </div>
            <div className="overlap-group8-12">
              <div className="number-156 poppins-normal-cape-cod-15px">{number9}</div>
              <div className="car-2-0021-25-2 poppins-normal-cape-cod-15px">{car2002125}</div>
              <div className="name-13 poppins-normal-cape-cod-15px">{name3}</div>
              <div className="overlap-group21-2">
                <img className="rectangle-20" src={rectangle20} />
                <div className="cancelled-5 poppins-normal-white-14px">{cancelled}</div>
              </div>
              <div className="rs90400-2 poppins-semi-bold-dell-15px">{rs90400}</div>
              <div className="overlap-group20-2">
                <div className="view-11 poppins-normal-white-14px">{view4}</div>
              </div>
            </div>
          </div>
          <div className="hi-admin-check-your-vrihodha-status-3 poppins-semi-bold-eerie-black-33px">
            {hiAdminCheckYourVrihodhaStatus}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
