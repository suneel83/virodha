import React from "react";
import { Link } from "react-router-dom";
import RatingSvgrepoCom from "../RatingSvgrepoCom";
import Group24 from "../Group24";
import Group26 from "../Group26";
import "./HomePage1.css";

function HomePage1(props) {
  const {
    opt1,
    opt2,
    opt3,
    pickAStarterOption,
    shopGroceries,
    newProducts1,
    newProducts2,
    weDeliverYouEnjoy,
    chooseFromSelectP,
    addInYourGrocery,
    saveYourselfATrip,
    x31,
    x11,
    x21,
    x12,
    phone,
    freeExpressDeliveryEasyReturns,
    untitledDesign1,
    title,
    liveHealthy,
    iconCall,
    group6,
    group7,
    place1,
    shop,
    surname1,
    blog,
    place2,
    iconCart,
    iconUser,
    all,
    vegitables,
    fruits,
    breads,
    surname2,
    group8,
    group9,
    group10,
    group11,
    group12,
    group13,
    group14,
    group15,
    image1H6,
    h7_100Organic,
    whatMakesUsDifferent,
    untitledDesign6,
    grownWithNaturalFertilizers,
    weedsAreControlledNaturally,
    diseaseIsPrevente,
    organicProduceCont,
    x70OffForAllOrga,
    knowMore,
    bg2H61,
    bg2H62,
    whatOurCustomersSay,
    alsoLikeTheFact,
    x1821829287_CammyLinUxDesignerCircl,
    x22,
    x13,
    x32,
    x16,
    x132,
    x14,
    x15,
    place3,
    text32,
    text33,
    text34,
    text35,
    text36,
    text37,
    text38,
    text39,
    text40,
    spinach,
    beetroot,
    cauliflower,
    place4,
    apple,
    color,
    grapes,
    ratingSvgrepoCom,
    proceedToCheckout,
    price,
    iconPlay1,
    iconPlay2,
    search,
    iconSearch,
    line1,
    line5,
    line6,
    line7,
    line8,
    line2,
    line3,
    line4,
    selectOptions1,
    greaterThanSvgrepoCom1,
    selectOptions2,
    greaterThanSvgrepoCom2,
    addToCart,
    greaterThanSvgrepoCom3,
    ratingSvgrepoCom1Props,
    ratingSvgrepoCom2Props,
    ratingSvgrepoCom3Props,
    ratingSvgrepoCom4Props,
    ratingSvgrepoCom5Props,
    ratingSvgrepoCom6Props,
    ratingSvgrepoCom7Props,
    group26Props,
    group241Props,
    group242Props,
    group243Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="home-page-1 screen">
        <div className="overlap-group13-6">
          <div className="rectangle-9-2"></div>
          <img className="opt1" src={opt1} />
          <img className="opt2" src={opt2} />
          <img className="opt3" src={opt3} />
          <div className="pick-a-starter-option poppins-extra-extra-bold-forest-green-23px">{pickAStarterOption}</div>
          <div className="shop-groceries poppins-extra-extra-bold-forest-green-23px">{shopGroceries}</div>
          <div className="new-products poppins-extra-extra-bold-camarone-37px">{newProducts1}</div>
          <div className="new-products poppins-extra-extra-bold-camarone-37px">{newProducts2}</div>
          <div className="we-deliver-you-enjoy poppins-extra-extra-bold-forest-green-23px">{weDeliverYouEnjoy}</div>
          <div className="choose-from-select-p poppins-semi-bold-midnight-moss-18px">{chooseFromSelectP}</div>
          <div className="add-in-your-grocery poppins-semi-bold-midnight-moss-18px">{addInYourGrocery}</div>
          <div className="save-yourself-a-trip poppins-semi-bold-midnight-moss-18px">{saveYourselfATrip}</div>
          <img className="x3" src={x31} />
          <img className="x1" src={x11} />
          <img className="x2-3" src={x21} />
        </div>
        <div className="overlap-group17-4 poppins-semi-bold-midnight-moss-23px">
          <div className="overlap-group12-5">
            <div className="rectangle-1-16 border-1px-dove-gray"></div>
            <img className="x1-1" src={x12} />
            <div className="phone-10">{phone}</div>
            <div className="free-express-delivery-easy-returns">{freeExpressDeliveryEasyReturns}</div>
            <img className="untitled-design-1-1" src={untitledDesign1} />
            <h1 className="title-3 poppins-semi-bold-white-72px">{title}</h1>
            <div className="live-healthy poppins-semi-bold-white-72px">{liveHealthy}</div>
            <img className="icon-call" src={iconCall} />
            <img className="group-6" src={group6} />
            <img className="group-7-1" src={group7} />
          </div>
          <div className="place-7">{place1}</div>
          <div className="shop">{shop}</div>
          <div className="surname-3">{surname1}</div>
          <div className="blog">{blog}</div>
          <div className="place-8">{place2}</div>
          <img className="icon-cart" src={iconCart} />
          <img className="icon-user-10" src={iconUser} />
        </div>
        <div className="overlap-group15-2 border-1px-dove-gray">
          <div className="all">{all}</div>
        </div>
        <div className="vegitables-8 poppins-medium-black-27px">{vegitables}</div>
        <div className="fruits-22 poppins-medium-black-27px">{fruits}</div>
        <div className="breads-1 poppins-medium-black-27px">{breads}</div>
        <div className="surname-4 poppins-medium-black-27px">{surname2}</div>
        <img className="group-8" src={group8} />
        <img className="group-9-1" src={group9} />
        <img className="group-10" src={group10} />
        <img className="group-11" src={group11} />
        <img className="group-12" src={group12} />
        <img className="group-13" src={group13} />
        <img className="group-14" src={group14} />
        <img className="group-15" src={group15} />
        <div className="overlap-group10-7">
          <div className="rectangle-4-2"></div>
          <div className="group-29-1"></div>
          <img className="image1-h6" src={image1H6} />
          <img className="h7_100organic" src={h7_100Organic} />
          <div className="what-makes-us-different poppins-extra-extra-bold-camarone-37px">{whatMakesUsDifferent}</div>
          <img className="untitled-design-6-1" src={untitledDesign6} />
          <div className="rectangle-5-9"></div>
          <div className="rectangle-6-14"></div>
          <div className="rectangle-7-12"></div>
          <div className="rectangle-8-12"></div>
          <div className="grown-with-natural-fertilizers poppins-normal-black-29px">{grownWithNaturalFertilizers}</div>
          <div className="weeds-are-controlled-naturally poppins-normal-black-29px">{weedsAreControlledNaturally}</div>
          <div className="disease-is-prevente poppins-normal-black-29px">{diseaseIsPrevente}</div>
          <div className="organic-produce-cont poppins-normal-black-29px">{organicProduceCont}</div>
          <div className="x70-off-for-all-orga">{x70OffForAllOrga}</div>
          <div className="rectangle-19-2"></div>
          <div className="know-more poppins-medium-black-24px">{knowMore}</div>
        </div>
        <div className="overlap-group9-16">
          <img className="bg2-h6" src={bg2H61} />
          <img className="bg2-h6" src={bg2H62} />
          <div className="what-our-customers-say poppins-extra-extra-bold-camarone-37px">{whatOurCustomersSay}</div>
          <div className="also-like-the-fact">{alsoLikeTheFact}</div>
          <img className="x182-1829287_cammy-li" src={x1821829287_CammyLinUxDesignerCircl} />
          <img className="x2-4" src={x22} />
          <img className="x1-2" src={x13} />
          <img className="x3-1" src={x32} />
        </div>
        <img className="x16" src={x16} />
        <img className="x13" src={x132} />
        <img className="x14" src={x14} />
        <img className="x15" src={x15} />
        <div className="rectangle-10-3"></div>
        <div className="place-9 poppins-medium-eerie-black-24px">{place3}</div>
        <div className="text-32 poppins-medium-eerie-black-24px">{text32}</div>
        <div className="text-33 poppins-bold-sea-green-24px">{text33}</div>
        <div className="text-34 poppins-bold-sea-green-24px">{text34}</div>
        <div className="text-35 poppins-bold-sea-green-24px">{text35}</div>
        <div className="text-36 poppins-bold-sea-green-24px">{text36}</div>
        <div className="text-37 poppins-bold-sea-green-24px">{text37}</div>
        <div className="text-38 poppins-bold-sea-green-24px">{text38}</div>
        <div className="text-39 poppins-bold-sea-green-24px">{text39}</div>
        <div className="text-40 poppins-bold-sea-green-24px">{text40}</div>
        <div className="spinach-6 poppins-medium-eerie-black-24px">{spinach}</div>
        <div className="beetroot-3 poppins-medium-eerie-black-24px">{beetroot}</div>
        <div className="cauliflower-1 poppins-medium-eerie-black-24px">{cauliflower}</div>
        <div className="place-10 poppins-medium-eerie-black-24px">{place4}</div>
        <div className="apple-6 poppins-medium-eerie-black-24px">{apple}</div>
        <div className="color-6 poppins-medium-eerie-black-24px">{color}</div>
        <div className="grapes-7 poppins-medium-eerie-black-24px">{grapes}</div>
        <img className="rating-svgrepo-com" src={ratingSvgrepoCom} />
        <RatingSvgrepoCom iconStar2={ratingSvgrepoCom1Props.iconStar2} iconStar4={ratingSvgrepoCom1Props.iconStar4} />
        <RatingSvgrepoCom
          iconStar2={ratingSvgrepoCom2Props.iconStar2}
          iconStar4={ratingSvgrepoCom2Props.iconStar4}
          className={ratingSvgrepoCom2Props.className}
        />
        <RatingSvgrepoCom
          iconStar2={ratingSvgrepoCom3Props.iconStar2}
          iconStar4={ratingSvgrepoCom3Props.iconStar4}
          className={ratingSvgrepoCom3Props.className}
        />
        <RatingSvgrepoCom
          iconStar2={ratingSvgrepoCom4Props.iconStar2}
          iconStar4={ratingSvgrepoCom4Props.iconStar4}
          className={ratingSvgrepoCom4Props.className}
        />
        <RatingSvgrepoCom
          iconStar2={ratingSvgrepoCom5Props.iconStar2}
          iconStar4={ratingSvgrepoCom5Props.iconStar4}
          className={ratingSvgrepoCom5Props.className}
        />
        <RatingSvgrepoCom
          iconStar2={ratingSvgrepoCom6Props.iconStar2}
          iconStar4={ratingSvgrepoCom6Props.iconStar4}
          className={ratingSvgrepoCom6Props.className}
        />
        <RatingSvgrepoCom
          iconStar2={ratingSvgrepoCom7Props.iconStar2}
          iconStar4={ratingSvgrepoCom7Props.iconStar4}
          className={ratingSvgrepoCom7Props.className}
        />
        <div className="overlap-group11-8 poppins-medium-black-24px">
          <div className="proceed-to-checkout">{proceedToCheckout}</div>
          <div className="price-4">{price}</div>
        </div>
        <img className="icon-play" src={iconPlay1} />
        <img className="icon-play-1" src={iconPlay2} />
        <div className="search-container">
          <div className="search-11">{search}</div>
          <img className="icon-search" src={iconSearch} />
        </div>
        <img className="line-1-14" src={line1} />
        <img className="line-5-1" src={line5} />
        <img className="line-6-1" src={line6} />
        <img className="line-7" src={line7} />
        <img className="line-8" src={line8} />
        <img className="line-2-1" src={line2} />
        <img className="line-3-2" src={line3} />
        <img className="line-4-1" src={line4} />
        <div className="group-container-10">
          <div className="overlap-group-76">
            <div className="group-17-1">
              <div className="select-options poppins-semi-bold-eerie-black-19px">{selectOptions1}</div>
            </div>
            <img className="greater-than-svgrepo-com" src={greaterThanSvgrepoCom1} />
          </div>
          <a href="javascript:ShowOverlay('select-options', 'animate-appear');">
            <div className="group-23-1">
              <div className="overlap-group-75">
                <div className="group-17-1">
                  <div className="select-options-1 poppins-semi-bold-eerie-black-19px">{selectOptions2}</div>
                </div>
                <img className="greater-than-svgrepo-com" src={greaterThanSvgrepoCom2} />
              </div>
            </div>
          </a>
        </div>
        <Group24 />
        <a href="javascript:ShowOverlay('add-to-cart', 'animate-appear');">
          <div className="group-25-1">
            <div className="overlap-group-75">
              <div className="group-17-2">
                <div className="add-to-cart poppins-semi-bold-eerie-black-19px">{addToCart}</div>
              </div>
              <img className="greater-than-svgrepo-com" src={greaterThanSvgrepoCom3} />
            </div>
          </div>
        </a>
        <Group26 />
        <Group26 className={group26Props.className} />
        <Group24 className={group241Props.className} />
        <Group24 className={group242Props.className} />
        <Group24 className={group243Props.className} />
      </div>
    </div>
  );
}

export default HomePage1;
