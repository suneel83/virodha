import React from "react";
import { Link } from "react-router-dom";
import BinSvgrepoCom from "../BinSvgrepoCom";
import X2020Calendar from "../X2020Calendar";
import B from "../B";
import UsersSilhouettesSvgrepoCom from "../UsersSilhouettesSvgrepoCom";
import SellProductSvgrepoCom from "../SellProductSvgrepoCom";
import MenuOrderSvgrepoCom from "../MenuOrderSvgrepoCom";
import NotificationSvgrepoCom from "../NotificationSvgrepoCom";
import AvatarSvgrepoCom from "../AvatarSvgrepoCom";
import "./UserManagementUserData.css";

function UserManagementUserData(props) {
  const {
    untitledDesign17,
    usersData1,
    checkYourUsersDetailsHere,
    no,
    userName,
    phone1,
    email,
    regDate,
    actions,
    details,
    number1,
    phone2,
    hendry,
    hendryHotmailCom,
    petercralYahooCom,
    makovGmailCom,
    daniel232GmailCom,
    jpmorganGmailCom,
    date1,
    date2,
    date3,
    date4,
    date5,
    name1,
    markov,
    name2,
    name3,
    phone3,
    phone4,
    phone5,
    phone6,
    number2,
    number3,
    number4,
    number5,
    view1,
    view2,
    view3,
    view4,
    view5,
    iconTrash,
    rectangle1596,
    fromDate,
    mmDdYyyy1,
    mmDdYyyy2,
    toDate,
    showUsers,
    calenderSvgrepoCom1,
    calenderSvgrepoCom2,
    number6,
    number7,
    number8,
    number9,
    search,
    adminPanel,
    untitledDesign,
    leaf11,
    userManagement,
    usersData2,
    categoryManagement,
    productManagement,
    orderManagement,
    manageNotifications,
    x41,
    x42,
    x43,
    x18,
    leaf12,
    leaf2,
    laptopSvgrepoCom,
    dashboard,
    categoryAltSvgrepoCom,
    enterArrowSvgrepoCom,
    welcome,
    admin,
    path77,
    path78,
    binSvgrepoCom1Props,
    binSvgrepoCom2Props,
    binSvgrepoCom3Props,
    x2020CalendarProps,
    b1Props,
    b2Props,
    b3Props,
    usersSilhouettesSvgrepoComProps,
    avatarSvgrepoComProps,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="user-management-user-data screen">
        <div className="overlap-group-container-1">
          <div className="overlap-group46">
            <img className="untitled-design-17" src={untitledDesign17} />
            <div className="rectangle-9"></div>
            <div className="users-data poppins-semi-bold-everglade-30px">{usersData1}</div>
            <p className="check-your-users-details-here poppins-normal-cape-cod-15px">{checkYourUsersDetailsHere}</p>
            <div className="rectangle-10"></div>
            <div className="no-1 poppins-medium-cape-cod-15px-2">{no}</div>
            <div className="user-name poppins-medium-cape-cod-15px-2">{userName}</div>
            <div className="phone poppins-medium-cape-cod-15px-2">{phone1}</div>
            <div className="email poppins-medium-cape-cod-15px-2">{email}</div>
            <div className="reg-date poppins-medium-cape-cod-15px-2">{regDate}</div>
            <div className="actions-1 poppins-medium-cape-cod-15px-2">{actions}</div>
            <div className="details-1 poppins-medium-cape-cod-15px-2">{details}</div>
            <div className="rectangle-11"></div>
            <div className="rectangle-12"></div>
            <div className="rectangle-13"></div>
            <div className="rectangle-14"></div>
            <div className="rectangle-15"></div>
            <div className="number-12 poppins-normal-cape-cod-15px">{number1}</div>
            <div className="phone-1 poppins-normal-cape-cod-15px">{phone2}</div>
            <div className="hendry-1 poppins-normal-cape-cod-15px">{hendry}</div>
            <div className="hendryhotmailcom poppins-normal-cape-cod-15px">{hendryHotmailCom}</div>
            <div className="petercralyahoocom poppins-normal-cape-cod-15px">{petercralYahooCom}</div>
            <div className="makovgmailcom poppins-normal-cape-cod-15px">{makovGmailCom}</div>
            <div className="daniel232gmailcom poppins-normal-cape-cod-15px">{daniel232GmailCom}</div>
            <div className="jpmorgangmailcom poppins-normal-cape-cod-15px">{jpmorganGmailCom}</div>
            <div className="date poppins-normal-cape-cod-15px">{date1}</div>
            <div className="date-1 poppins-normal-cape-cod-15px">{date2}</div>
            <div className="date-2 poppins-normal-cape-cod-15px">{date3}</div>
            <div className="date-3 poppins-normal-cape-cod-15px">{date4}</div>
            <div className="date-4 poppins-normal-cape-cod-15px">{date5}</div>
            <div className="name-3 poppins-normal-cape-cod-15px">{name1}</div>
            <div className="markov-1 poppins-normal-cape-cod-15px">{markov}</div>
            <div className="name-4 poppins-normal-cape-cod-15px">{name2}</div>
            <div className="name-5 poppins-normal-cape-cod-15px">{name3}</div>
            <div className="phone-2 poppins-normal-cape-cod-15px">{phone3}</div>
            <div className="phone-3 poppins-normal-cape-cod-15px">{phone4}</div>
            <div className="phone-4 poppins-normal-cape-cod-15px">{phone5}</div>
            <div className="phone-5 poppins-normal-cape-cod-15px">{phone6}</div>
            <div className="number-13 poppins-normal-cape-cod-15px">{number2}</div>
            <div className="number-14 poppins-normal-cape-cod-15px">{number3}</div>
            <div className="number-15 poppins-normal-cape-cod-15px">{number4}</div>
            <div className="number-16 poppins-normal-cape-cod-15px">{number5}</div>
            <a href="javascript:ShowOverlay('users-data-view', 'animate-appear');">
              <div className="rectangle-21"></div>
            </a>
            <div className="rectangle-22"></div>
            <div className="rectangle-23"></div>
            <div className="rectangle-24"></div>
            <div className="rectangle-25"></div>
            <div className="view-1 poppins-normal-white-14px">{view1}</div>
            <div className="view-2 poppins-normal-white-14px">{view2}</div>
            <div className="view-3 poppins-normal-white-14px">{view3}</div>
            <div className="view-4 poppins-normal-white-14px">{view4}</div>
            <div className="view-5 poppins-normal-white-14px">{view5}</div>
            <img className="icon-trash-4" src={iconTrash} />
            <BinSvgrepoCom />
            <BinSvgrepoCom className={binSvgrepoCom1Props.className} />
            <BinSvgrepoCom className={binSvgrepoCom2Props.className} />
            <BinSvgrepoCom className={binSvgrepoCom3Props.className} />
            <div className="rectangle-1594"></div>
            <img className="rectangle-1596" src={rectangle1596} />
            <div className="rectangle-1595"></div>
            <X2020Calendar />
            <X2020Calendar className={x2020CalendarProps.className} />
            <div className="from-date poppins-semi-bold-don-juan-14px">{fromDate}</div>
            <div className="mm-dd-yyyy poppins-normal-mountain-mist-12px">{mmDdYyyy1}</div>
            <div className="mm-dd-yyyy-1 poppins-normal-mountain-mist-12px">{mmDdYyyy2}</div>
            <div className="to-date poppins-semi-bold-don-juan-14px">{toDate}</div>
            <div className="show-users poppins-normal-white-12px">{showUsers}</div>
            <img className="calender-svgrepo-com" src={calenderSvgrepoCom1} />
            <img className="calender-svgrepo-com-1" src={calenderSvgrepoCom2} />
            <div className="rectangle-2163"></div>
            <div className="rectangle-2164"></div>
            <div className="rectangle-2165"></div>
            <div className="rectangle-2166"></div>
            <div className="number-17 poppins-medium-shady-lady-15px">{number6}</div>
            <div className="number-18 poppins-medium-shady-lady-15px">{number7}</div>
            <div className="number-19 poppins-medium-shady-lady-15px">{number8}</div>
            <div className="number-20 poppins-medium-shady-lady-15px">{number9}</div>
            <B className={b1Props.className} />
            <B className={b2Props.className} />
            <B className={b3Props.className} />
            <div className="search poppins-semi-bold-cape-cod-18px">{search}</div>
            <div className="rectangle-2112"></div>
          </div>
          <div className="overlap-group47">
            <div className="rectangle-1-1"></div>
            <div className="admin-panel-1 poppins-semi-bold-chicago-33px">{adminPanel}</div>
            <img className="untitled-design-1" src={untitledDesign} />
            <div className="rectangle-2-1"></div>
            <img className="leaf1-2" src={leaf11} />
            <div className="rectangle-4"></div>
            <div className="rectangle-5"></div>
            <div className="rectangle-6"></div>
            <div className="rectangle-7"></div>
            <div className="rectangle-8"></div>
            <div className="user-management poppins-medium-white-17px">{userManagement}</div>
            <div className="users-data-1 poppins-medium-lemon-glacier-14px">{usersData2}</div>
            <div className="category-management poppins-medium-don-juan-17px">{categoryManagement}</div>
            <div className="product-management poppins-medium-don-juan-17px">{productManagement}</div>
            <div className="order-management-1 poppins-medium-don-juan-17px">{orderManagement}</div>
            <div className="manage-notifications-1 poppins-medium-don-juan-17px">{manageNotifications}</div>
            <img className="x4-3" src={x41} />
            <img className="x4-4" src={x42} />
            <img className="x4-5" src={x43} />
            <img className="x18-1" src={x18} />
            <img className="leaf1-3" src={leaf12} />
            <img className="leaf2-1" src={leaf2} />
            <Link to="/dashboard-pending-orders">
              <div className="group-33">
                <img className="laptop-svgrepo-com" src={laptopSvgrepoCom} />
                <div className="dashboard poppins-medium-don-juan-17px">{dashboard}</div>
              </div>
            </Link>
            <UsersSilhouettesSvgrepoCom
              path1={usersSilhouettesSvgrepoComProps.path1}
              path2={usersSilhouettesSvgrepoComProps.path2}
              path6={usersSilhouettesSvgrepoComProps.path6}
              path3={usersSilhouettesSvgrepoComProps.path3}
              path4={usersSilhouettesSvgrepoComProps.path4}
              path5={usersSilhouettesSvgrepoComProps.path5}
            />
            <img className="category-alt-svgrepo-com" src={categoryAltSvgrepoCom} />
            <SellProductSvgrepoCom />
            <MenuOrderSvgrepoCom />
            <NotificationSvgrepoCom />
            <img className="enter-arrow-svgrepo-com" src={enterArrowSvgrepoCom} />
            <div className="welcome-1 poppins-medium-don-juan-14px">{welcome}</div>
            <div className="admin-1 poppins-medium-don-juan-14px">{admin}</div>
            <div className="path-container">
              <img className="path-77" src={path77} />
              <img className="path-78" src={path78} />
            </div>
            <AvatarSvgrepoCom
              path82={avatarSvgrepoComProps.path82}
              path85={avatarSvgrepoComProps.path85}
              path86={avatarSvgrepoComProps.path86}
              path87={avatarSvgrepoComProps.path87}
              path89={avatarSvgrepoComProps.path89}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default UserManagementUserData;
