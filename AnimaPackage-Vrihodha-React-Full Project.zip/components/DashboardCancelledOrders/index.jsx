import React from "react";
import { Link } from "react-router-dom";
import Group42 from "../Group42";
import Group41 from "../Group41";
import XMLID1454 from "../XMLID1454";
import B from "../B";
import "./DashboardCancelledOrders.css";

function DashboardCancelledOrders(props) {
  const {
    overlapGroup8,
    goOrganicGetHealthy,
    x18,
    line1,
    leaf11,
    welcome,
    admin,
    group50,
    adminPanel,
    x41,
    x42,
    x43,
    leaf12,
    leaf2,
    untitledDesign,
    group56,
    group35,
    iconUser,
    sellProductSvgrepoCom,
    orderContainer,
    menuOrderSvgrepoCom,
    orderManagement,
    logOutCircleSvgrepoCom,
    avatarSvgrepoCom1,
    number1,
    avatarSvgrepoCom2,
    hiAdminYouHave5,
    overlapGroup6,
    cancelledOrders1,
    navbarLinkNo,
    navbarLinkOrderId,
    navbarLinkUserDetails,
    navbarLinkStatus,
    navbarLinkAmount,
    navbarLinkDetails,
    navbarLinkActions,
    navbarLinkNumber,
    navbarLinkCar1009311,
    navbarLinkAnandha,
    rectangle16,
    cancelled1,
    navbarLinkRs48700,
    group55,
    textEdit1,
    iconTrash1,
    number2,
    car1004341,
    premKumar,
    rectangle2219,
    cancelled2,
    rs34300,
    view1,
    textEdit2,
    iconTrash2,
    number3,
    car1003156,
    kavitha,
    rectangle2220,
    cancelled3,
    rs65400,
    overlapGroup31,
    view2,
    textEdit3,
    iconTrash3,
    number4,
    hiAdminCheckYourVrihodhaStatus,
    x2,
    outForDelivery,
    number5,
    overlapGroup1,
    cancelledOrders2,
    number6,
    overlapGroup2,
    totalAppUsers,
    number7,
    overlapGroup32,
    pendingOrders,
    number8,
    xMLID1454Props,
    b1Props,
    b2Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="dashboard-cancelled-orders screen">
        <div className="overlap-group14-3">
          <div className="overlap-group8-3" style={{ backgroundImage: `url(${overlapGroup8})` }}>
            <div className="go-organic-get-healthy-2 poppins-semi-bold-white-61px">{goOrganicGetHealthy}</div>
          </div>
          <div className="overlap-group7-3">
            <div className="rectangle-2-4"></div>
            <img className="x18-4" src={x18} />
            <img className="line-1-2" src={line1} />
            <div className="rectangle-1-4"></div>
            <img className="leaf1-8" src={leaf11} />
            <div className="welcome-4 poppins-medium-don-juan-14px">{welcome}</div>
            <div className="admin-4 poppins-medium-don-juan-14px">{admin}</div>
            <img className="group-50-2" src={group50} />
            <div className="admin-panel-4 poppins-semi-bold-chicago-33px">{adminPanel}</div>
            <img className="x4-12" src={x41} />
            <img className="x4-13" src={x42} />
            <img className="x4-14" src={x43} />
            <img className="leaf1-9" src={leaf12} />
            <img className="leaf2-4" src={leaf2} />
            <img className="untitled-design-5" src={untitledDesign} />
            <img className="group-56-2" src={group56} />
            <img className="group-35-2" src={group35} />
            <img className="icon-user-2" src={iconUser} />
            <Group42 />
            <img className="sell-product-svgrepo-com-4" src={sellProductSvgrepoCom} />
            <div className="order-container-2" style={{ backgroundImage: `url(${orderContainer})` }}>
              <img className="menu-order-svgrepo-com-5" src={menuOrderSvgrepoCom} />
              <div className="order-management-4 poppins-medium-don-juan-17px">{orderManagement}</div>
            </div>
            <Group41 />
            <img className="log-out-circle-svgrepo-com-2" src={logOutCircleSvgrepoCom} />
            <img className="avatar-svgrepo-com-14" src={avatarSvgrepoCom1} />
            <XMLID1454
              xmlid_504_={xMLID1454Props.xmlid_504_}
              xmlid_507_={xMLID1454Props.xmlid_507_}
              xmlid_509_={xMLID1454Props.xmlid_509_}
              xmlid_510_={xMLID1454Props.xmlid_510_}
              xmlid_511_={xMLID1454Props.xmlid_511_}
              className={xMLID1454Props.className}
            />
            <div className="ellipse-45-2 border-1px-swirl"></div>
            <div className="number-64 poppins-bold-black-14px">{number1}</div>
            <div className="rectangle-2212-2"></div>
            <img className="avatar-svgrepo-com-15" src={avatarSvgrepoCom2} />
            <p className="hi-admin-you-have-5-2 poppins-medium-don-juan-14px">{hiAdminYouHave5}</p>
          </div>
          <div className="overlap-group6-3" style={{ backgroundImage: `url(${overlapGroup6})` }}>
            <div className="cancelled-orders-2 poppins-semi-bold-everglade-30px">{cancelledOrders1}</div>
            <div className="navbar-2 poppins-medium-cape-cod-18px">
              <div className="navbar-link-no-1">{navbarLinkNo}</div>
              <div className="navbar-link-order-id-1">{navbarLinkOrderId}</div>
              <B />
              <div className="navbar-link-user-details-1">{navbarLinkUserDetails}</div>
              <B className={b1Props.className} />
              <div className="navbar-link-status-1">{navbarLinkStatus}</div>
              <div className="navbar-link-amount-1">{navbarLinkAmount}</div>
              <B className={b2Props.className} />
              <div className="navbar-link-details-1">{navbarLinkDetails}</div>
              <div className="navbar-link-actions-1">{navbarLinkActions}</div>
            </div>
            <div className="navbar-3">
              <div className="navbar-link-number-1 poppins-normal-cape-cod-15px">{navbarLinkNumber}</div>
              <div className="navbar-link-car-1-0093-11-1 poppins-normal-cape-cod-15px">{navbarLinkCar1009311}</div>
              <div className="navbar-link-anandha poppins-normal-cape-cod-15px">{navbarLinkAnandha}</div>
              <div className="overlap-group-40">
                <img className="rectangle-18" src={rectangle16} />
                <div className="cancelled-1 poppins-normal-white-14px">{cancelled1}</div>
              </div>
              <div className="navbar-link-rs48700-1 poppins-semi-bold-dell-15px">{navbarLinkRs48700}</div>
              <img className="group-55-2" src={group55} />
              <img className="text-edit-7" src={textEdit1} />
              <img className="icon-trash-8" src={iconTrash1} />
            </div>
            <div className="overlap-group9-2">
              <div className="number-63 poppins-normal-cape-cod-15px">{number2}</div>
              <div className="car-1-0043-41-3 poppins-normal-cape-cod-15px">{car1004341}</div>
              <div className="prem-kumar poppins-normal-cape-cod-15px">{premKumar}</div>
              <div className="overlap-group1-19">
                <img className="rectangle-18" src={rectangle2219} />
                <div className="cancelled-1 poppins-normal-white-14px">{cancelled2}</div>
              </div>
              <div className="rs34300-1 poppins-semi-bold-dell-15px">{rs34300}</div>
              <div className="overlap-group2-7">
                <div className="view-9 poppins-normal-white-14px">{view1}</div>
              </div>
              <img className="text-edit-8" src={textEdit2} />
              <img className="icon-trash-9" src={iconTrash2} />
            </div>
            <div className="overlap-group11-3">
              <div className="number-63 poppins-normal-cape-cod-15px">{number3}</div>
              <div className="car-1-0031-56-3 poppins-normal-cape-cod-15px">{car1003156}</div>
              <div className="kavitha poppins-normal-cape-cod-15px">{kavitha}</div>
              <div className="overlap-group4-4">
                <img className="rectangle-18" src={rectangle2220} />
                <div className="cancelled-1 poppins-normal-white-14px">{cancelled3}</div>
              </div>
              <div className="rs65400-1 poppins-semi-bold-dell-15px">{rs65400}</div>
              <div className="overlap-group3-6" style={{ backgroundImage: `url(${overlapGroup31})` }}>
                <div className="view-9 poppins-normal-white-14px">{view2}</div>
              </div>
              <img className="text-edit-9" src={textEdit3} />
              <img className="icon-trash-10" src={iconTrash3} />
            </div>
            <div className="overlap-group13-2">
              <div className="number-65 poppins-medium-shady-lady-15px">{number4}</div>
            </div>
          </div>
          <div className="hi-admin-check-your-vrihodha-status-2 poppins-semi-bold-eerie-black-33px">
            {hiAdminCheckYourVrihodhaStatus}
          </div>
          <Link to="/dashboard-out-for-delivery">
            <div className="group-60-1">
              <div className="overlap-group-41 poppins-semi-bold-white-41px">
                <img className="x2-2" src={x2} />
                <div className="out-for-delivery-5">{outForDelivery}</div>
                <div className="number-66">{number5}</div>
              </div>
            </div>
          </Link>
          <div
            className="overlap-group1-20 poppins-semi-bold-white-41px"
            style={{ backgroundImage: `url(${overlapGroup1})` }}
          >
            <div className="cancelled-orders-3">{cancelledOrders2}</div>
            <div className="number-67">{number6}</div>
          </div>
          <Link to="/user-management-user-data">
            <div className="group-59-2">
              <div
                className="overlap-group2-8 poppins-semi-bold-white-41px"
                style={{ backgroundImage: `url(${overlapGroup2})` }}
              >
                <div className="total-app-users-2">{totalAppUsers}</div>
                <div className="number-68">{number7}</div>
              </div>
            </div>
          </Link>
          <Link to="/dashboard-pending-orders">
            <div className="group-62-1">
              <div
                className="overlap-group3-7 poppins-semi-bold-white-41px"
                style={{ backgroundImage: `url(${overlapGroup32})` }}
              >
                <div className="pending-orders-3">{pendingOrders}</div>
                <div className="number-69">{number8}</div>
              </div>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}

export default DashboardCancelledOrders;
