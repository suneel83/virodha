import React from "react";
import { Link } from "react-router-dom";
import Group35 from "../Group35";
import "./NotificationManagement.css";

function NotificationManagement(props) {
  const {
    x18,
    leaf11,
    dashboard,
    welcome,
    administrator,
    categoryManagement,
    productManagement,
    orderManagement,
    manageNotifications,
    adminPanel,
    x41,
    x42,
    x43,
    leaf12,
    leaf2,
    untitledDesign,
    laptopSvgrepoCom,
    iconUser,
    categoryAltSvgrepoCom,
    sellProductSvgrepoCom,
    menuOrderSvgrepoCom,
    iconNotifications,
    line1,
    overlapGroup2,
    notifyUsers,
    path2,
    rectangleCopy11,
    path3,
    selectUser,
    polygon3,
    title,
    message,
    attachment,
    iconPaperclip,
    sendNotification,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="notification-management screen">
        <div className="overlap-group6-19">
          <div className="overlap-group1-31">
            <div className="rectangle-2-15"></div>
            <img className="x18-13" src={x18} />
            <div className="rectangle-1-13"></div>
            <img className="leaf1-26" src={leaf11} />
            <Link to="/dashboard">
              <div className="rectangle-3-8"></div>
            </Link>
            <div className="rectangle-5-7"></div>
            <div className="rectangle-6-10"></div>
            <div className="rectangle-7-9"></div>
            <div className="rectangle-8-9"></div>
            <div className="dashboard-10 poppins-medium-don-juan-17px">{dashboard}</div>
            <div className="welcome-13 poppins-medium-don-juan-14px">{welcome}</div>
            <div className="administrator poppins-medium-don-juan-16px">{administrator}</div>
            <div className="category-management-7 poppins-medium-don-juan-17px">{categoryManagement}</div>
            <div className="product-management-10 poppins-medium-don-juan-17px">{productManagement}</div>
            <div className="order-management-13 poppins-medium-don-juan-17px">{orderManagement}</div>
            <div className="manage-notifications-13 poppins-medium-white-17px">{manageNotifications}</div>
            <div className="admin-panel-13 poppins-semi-bold-chicago-33px">{adminPanel}</div>
            <img className="x4-42" src={x41} />
            <img className="x4-43" src={x42} />
            <img className="x4-44" src={x43} />
            <img className="leaf1-27" src={leaf12} />
            <img className="leaf2-13" src={leaf2} />
            <img className="untitled-design-14" src={untitledDesign} />
            <img className="laptop-svgrepo-com-9" src={laptopSvgrepoCom} />
            <Group35 />
            <img className="icon-user-9" src={iconUser} />
            <img className="category-alt-svgrepo-com-7" src={categoryAltSvgrepoCom} />
            <img className="sell-product-svgrepo-com-14" src={sellProductSvgrepoCom} />
            <img className="menu-order-svgrepo-com-13" src={menuOrderSvgrepoCom} />
            <img className="icon-notifications-9" src={iconNotifications} />
          </div>
          <img className="line-1-11" src={line1} />
          <div className="overlap-group2-28" style={{ backgroundImage: `url(${overlapGroup2})` }}>
            <div className="flex-row-53">
              <div className="notify-users-1 poppins-semi-bold-everglade-30px">{notifyUsers}</div>
              <div className="icons-1">
                <div className="ui-gambling-website-1">
                  <div className="x4-45">
                    <div className="notification-1">
                      <div className="overlap-group-69">
                        <img className="path-13" src="/img/path@1x.png" />
                        <img className="path-14" src={path2} />
                        <img className="oval-1" src="/img/oval@1x.png" />
                        <img className="rectangle-copy-11-1" src={rectangleCopy11} />
                        <img className="path-15" src={path3} />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex-row-54">
              <div className="select-user-1 poppins-medium-cape-cod-15px">{selectUser}</div>
              <div className="overlap-group3-29">
                <img className="polygon-3-2" src={polygon3} />
              </div>
            </div>
            <div className="flex-row-55">
              <div className="title-2 poppins-medium-cape-cod-15px">{title}</div>
              <div className="rectangle-2117-2"></div>
            </div>
            <div className="flex-row-56">
              <div className="message-1 poppins-medium-cape-cod-15px">{message}</div>
              <div className="rectangle-2118-1"></div>
            </div>
            <div className="flex-row-57">
              <div className="attachment-1 poppins-medium-cape-cod-15px">{attachment}</div>
              <div className="overlap-group5-20">
                <img className="icon-paperclip-1" src={iconPaperclip} />
              </div>
            </div>
            <div className="overlap-group4-25">
              <div className="send-notification-1">{sendNotification}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default NotificationManagement;
