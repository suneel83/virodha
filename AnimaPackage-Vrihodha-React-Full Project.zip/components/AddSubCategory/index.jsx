import React from "react";
import "./AddSubCategory.css";

function AddSubCategory(props) {
  const {
    flexCol,
    addSubCategory,
    category,
    polygon3,
    subCategoryImage,
    upload,
    subCategoryName,
    unitKgsLts,
    add,
    close,
    mrp,
    sellingPrice,
    description,
    qty,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="add-sub-category-1 screen">
        <div className="flex-col-1" style={{ backgroundImage: `url(${flexCol})` }}>
          <div className="flex-col-2">
            <div className="add-sub-category-2 poppins-semi-bold-everglade-30px">{addSubCategory}</div>
            <div className="flex-row-8">
              <div className="category-3 poppins-medium-cape-cod-15px">{category}</div>
              <div className="overlap-group3-14">
                <img className="polygon-3" src={polygon3} />
              </div>
              <div className="sub-category-image poppins-medium-cape-cod-15px">{subCategoryImage}</div>
              <div className="overlap-group2-15">
                <div className="rectangle-2111"></div>
                <div className="upload poppins-normal-white-12px">{upload}</div>
              </div>
            </div>
          </div>
          <div className="flex-row-9">
            <div className="flex-row-10 poppins-medium-cape-cod-15px">
              <div className="flex-col-3">
                <div className="sub-category-name">{subCategoryName}</div>
                <div className="unit-kgs-lts">{unitKgsLts}</div>
              </div>
              <div className="flex-col-4">
                <div className="rectangle-2117"></div>
                <div className="rectangle-2173"></div>
                <div className="overlap-group-container-9">
                  <div className="overlap-group1-25">
                    <div className="add poppins-medium-snow-flurry-15px">{add}</div>
                  </div>
                  <div className="overlap-group4-10">
                    <div className="close poppins-medium-cape-cod-15px">{close}</div>
                  </div>
                </div>
              </div>
              <div className="flex-col-5">
                <div className="mrp-1">{mrp}</div>
                <div className="selling-price">{sellingPrice}</div>
                <div className="description">{description}</div>
              </div>
            </div>
            <div className="flex-col-6">
              <div className="flex-row-11">
                <div className="flex-col-7">
                  <div className="rectangle-2175"></div>
                  <div className="rectangle-2187"></div>
                </div>
                <div className="qty-1 poppins-medium-cape-cod-15px">{qty}</div>
                <div className="rectangle-2182"></div>
              </div>
              <div className="rectangle-2176"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AddSubCategory;
