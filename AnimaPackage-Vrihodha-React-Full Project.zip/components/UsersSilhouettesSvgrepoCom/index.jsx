import React from "react";
import "./UsersSilhouettesSvgrepoCom.css";

function UsersSilhouettesSvgrepoCom(props) {
  const { path1, path2, path6, path3, path4, path5, className } = props;

  return (
    <div className={`users-silhouettes-svgrepo-com ${className || ""}`}>
      <div className="group-1">
        <div className="path-container-1">
          <img className="path-1" src={path1} />
          <img className="path-2" src={path2} />
          <img className="path-6" src={path6} />
        </div>
        <div className="path-container-2">
          <img className="path-3" src={path3} />
          <img className="path-4" src={path4} />
          <img className="path-5" src={path5} />
        </div>
      </div>
    </div>
  );
}

export default UsersSilhouettesSvgrepoCom;
