import React from "react";
import { Link } from "react-router-dom";
import Group42 from "../Group42";
import Group41 from "../Group41";
import XMLID1454 from "../XMLID1454";
import B from "../B";
import "./DashboardOutForDelivery.css";

function DashboardOutForDelivery(props) {
  const {
    overlapGroup8,
    goOrganicGetHealthy,
    x18,
    line1,
    leaf11,
    welcome,
    admin,
    group50,
    adminPanel,
    x41,
    x42,
    x43,
    leaf12,
    leaf2,
    untitledDesign,
    group56,
    group35,
    iconUser,
    sellProductSvgrepoCom,
    orderContainer,
    menuOrderSvgrepoCom,
    orderManagement,
    logOutCircleSvgrepoCom,
    avatarSvgrepoCom1,
    number1,
    avatarSvgrepoCom2,
    hiAdminYouHave5,
    overlapGroup6,
    outForDelivery1,
    navbarLinkNo,
    navbarLinkOrderId,
    navbarLinkUserDetails,
    navbarLinkStatus,
    navbarLinkAmount,
    navbarLinkDetails,
    navbarLinkActions,
    navbarLinkNumber,
    navbarLinkCar1009311,
    navbarLinkName,
    rectangle16,
    outForDelivery2,
    navbarLinkRs48700,
    group55,
    textEdit1,
    iconTrash1,
    number2,
    car1004341,
    ashokKumar,
    rectangle2217,
    outForDelivery3,
    rs34300,
    view1,
    textEdit2,
    iconTrash2,
    number3,
    car1003156,
    name,
    rectangle2218,
    outForDelivery4,
    rs65400,
    overlapGroup31,
    view2,
    textEdit3,
    iconTrash3,
    number4,
    hiAdminCheckYourVrihodhaStatus,
    x2,
    outForDelivery5,
    number5,
    overlapGroup1,
    cancelledOrders,
    number6,
    overlapGroup2,
    totalAppUsers,
    number7,
    overlapGroup32,
    pendingOrders,
    number8,
    xMLID1454Props,
    b1Props,
    b2Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="dashboard-out-for-delivery screen">
        <div className="overlap-group14-2">
          <div className="overlap-group8-2" style={{ backgroundImage: `url(${overlapGroup8})` }}>
            <div className="go-organic-get-healthy-1 poppins-semi-bold-white-61px">{goOrganicGetHealthy}</div>
          </div>
          <div className="overlap-group7-2">
            <div className="rectangle-2-3"></div>
            <img className="x18-3" src={x18} />
            <img className="line-1-1" src={line1} />
            <div className="rectangle-1-3"></div>
            <img className="leaf1-6" src={leaf11} />
            <div className="welcome-3 poppins-medium-don-juan-14px">{welcome}</div>
            <div className="admin-3 poppins-medium-don-juan-14px">{admin}</div>
            <img className="group-50-1" src={group50} />
            <div className="admin-panel-3 poppins-semi-bold-chicago-33px">{adminPanel}</div>
            <img className="x4-9" src={x41} />
            <img className="x4-10" src={x42} />
            <img className="x4-11" src={x43} />
            <img className="leaf1-7" src={leaf12} />
            <img className="leaf2-3" src={leaf2} />
            <img className="untitled-design-4" src={untitledDesign} />
            <img className="group-56-1" src={group56} />
            <img className="group-35-1" src={group35} />
            <img className="icon-user-1" src={iconUser} />
            <Group42 />
            <img className="sell-product-svgrepo-com-3" src={sellProductSvgrepoCom} />
            <div className="order-container-1" style={{ backgroundImage: `url(${orderContainer})` }}>
              <img className="menu-order-svgrepo-com-4" src={menuOrderSvgrepoCom} />
              <div className="order-management-3 poppins-medium-don-juan-17px">{orderManagement}</div>
            </div>
            <Group41 />
            <img className="log-out-circle-svgrepo-com-1" src={logOutCircleSvgrepoCom} />
            <img className="avatar-svgrepo-com-12" src={avatarSvgrepoCom1} />
            <XMLID1454
              xmlid_504_={xMLID1454Props.xmlid_504_}
              xmlid_507_={xMLID1454Props.xmlid_507_}
              xmlid_509_={xMLID1454Props.xmlid_509_}
              xmlid_510_={xMLID1454Props.xmlid_510_}
              xmlid_511_={xMLID1454Props.xmlid_511_}
              className={xMLID1454Props.className}
            />
            <div className="ellipse-45-1 border-1px-swirl"></div>
            <div className="number-57 poppins-bold-black-14px">{number1}</div>
            <div className="rectangle-2212-1"></div>
            <img className="avatar-svgrepo-com-13" src={avatarSvgrepoCom2} />
            <p className="hi-admin-you-have-5-1 poppins-medium-don-juan-14px">{hiAdminYouHave5}</p>
          </div>
          <div className="overlap-group6-2" style={{ backgroundImage: `url(${overlapGroup6})` }}>
            <div className="out-for-delivery-3 poppins-semi-bold-everglade-30px">{outForDelivery1}</div>
            <div className="navbar poppins-medium-cape-cod-18px">
              <div className="navbar-link-no">{navbarLinkNo}</div>
              <div className="navbar-link-order-id">{navbarLinkOrderId}</div>
              <B />
              <div className="navbar-link-user-details">{navbarLinkUserDetails}</div>
              <B className={b1Props.className} />
              <div className="navbar-link-status">{navbarLinkStatus}</div>
              <div className="navbar-link-amount">{navbarLinkAmount}</div>
              <B className={b2Props.className} />
              <div className="navbar-link-details">{navbarLinkDetails}</div>
              <div className="navbar-link-actions">{navbarLinkActions}</div>
            </div>
            <div className="navbar-1">
              <div className="navbar-link-number poppins-normal-cape-cod-15px">{navbarLinkNumber}</div>
              <div className="navbar-link-car-1-0093-11 poppins-normal-cape-cod-15px">{navbarLinkCar1009311}</div>
              <div className="navbar-link-name poppins-normal-cape-cod-15px">{navbarLinkName}</div>
              <div className="overlap-group-38">
                <img className="rectangle-16" src={rectangle16} />
                <div className="out-for-delivery-2 poppins-normal-white-14px">{outForDelivery2}</div>
              </div>
              <div className="navbar-link-rs48700 poppins-semi-bold-dell-15px">{navbarLinkRs48700}</div>
              <img className="group-55-1" src={group55} />
              <img className="text-edit-4" src={textEdit1} />
              <img className="icon-trash-5" src={iconTrash1} />
            </div>
            <div className="overlap-group12-2">
              <div className="number-56 poppins-normal-cape-cod-15px">{number2}</div>
              <div className="car-1-0043-41-2 poppins-normal-cape-cod-15px">{car1004341}</div>
              <div className="ashok-kumar poppins-normal-cape-cod-15px">{ashokKumar}</div>
              <div className="overlap-group1-17">
                <img className="rectangle-16" src={rectangle2217} />
                <div className="out-for-delivery-2 poppins-normal-white-14px">{outForDelivery3}</div>
              </div>
              <div className="rs34300 poppins-semi-bold-dell-15px">{rs34300}</div>
              <div className="overlap-group2-5">
                <div className="view-8 poppins-normal-white-14px">{view1}</div>
              </div>
              <img className="text-edit-5" src={textEdit2} />
              <img className="icon-trash-6" src={iconTrash2} />
            </div>
            <div className="overlap-group11-2">
              <div className="number-56 poppins-normal-cape-cod-15px">{number3}</div>
              <div className="car-1-0031-56-2 poppins-normal-cape-cod-15px">{car1003156}</div>
              <div className="name-6 poppins-normal-cape-cod-15px">{name}</div>
              <div className="overlap-group4-3">
                <img className="rectangle-16" src={rectangle2218} />
                <div className="out-for-delivery-2 poppins-normal-white-14px">{outForDelivery4}</div>
              </div>
              <div className="rs65400 poppins-semi-bold-dell-15px">{rs65400}</div>
              <div className="overlap-group3-4" style={{ backgroundImage: `url(${overlapGroup31})` }}>
                <div className="view-8 poppins-normal-white-14px">{view2}</div>
              </div>
              <img className="text-edit-6" src={textEdit3} />
              <img className="icon-trash-7" src={iconTrash3} />
            </div>
            <div className="overlap-group13-1">
              <div className="number-58 poppins-medium-shady-lady-15px">{number4}</div>
            </div>
          </div>
          <div className="hi-admin-check-your-vrihodha-status-1 poppins-semi-bold-eerie-black-33px">
            {hiAdminCheckYourVrihodhaStatus}
          </div>
          <div className="overlap-group-39 poppins-semi-bold-white-41px">
            <img className="x2-1" src={x2} />
            <div className="out-for-delivery-4">{outForDelivery5}</div>
            <div className="number-59">{number5}</div>
          </div>
          <Link to="/dashboard-cancelled-orders">
            <div className="group-61-1">
              <div
                className="overlap-group1-18 poppins-semi-bold-white-41px"
                style={{ backgroundImage: `url(${overlapGroup1})` }}
              >
                <div className="cancelled-orders-1">{cancelledOrders}</div>
                <div className="number-60">{number6}</div>
              </div>
            </div>
          </Link>
          <Link to="/user-management-user-data">
            <div className="group-59-1">
              <div
                className="overlap-group2-6 poppins-semi-bold-white-41px"
                style={{ backgroundImage: `url(${overlapGroup2})` }}
              >
                <div className="total-app-users-1">{totalAppUsers}</div>
                <div className="number-61">{number7}</div>
              </div>
            </div>
          </Link>
          <Link to="/dashboard-pending-orders">
            <div className="group-62">
              <div
                className="overlap-group3-5 poppins-semi-bold-white-41px"
                style={{ backgroundImage: `url(${overlapGroup32})` }}
              >
                <div className="pending-orders-2">{pendingOrders}</div>
                <div className="number-62">{number8}</div>
              </div>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}

export default DashboardOutForDelivery;
