import React from "react";
import Layer2 from "../Layer2";
import "./PendingOrdersAction.css";

function PendingOrdersAction(props) {
  const {
    ordersStatus,
    orderId,
    car1009311,
    address,
    customerName,
    hendry,
    contactNumber,
    phone,
    a453RdFloorRoh,
    changeStatus,
    overlapGroup,
    path97,
    rectangle2203,
    pending,
    rectangle2202,
    outForDelivery,
    rectangle2096,
    delivered,
    rectangle2204,
    cancelled,
    cancellationReason,
    update,
    layer21Props,
    layer22Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="pending-orders-action screen">
        <div className="flex-col-14 border-1px-dove-gray">
          <div className="flex-col-15">
            <div className="orders-status">{ordersStatus}</div>
            <div className="overlap-group3-17">
              <div className="flex-col-16">
                <div className="flex-row-22">
                  <div className="order-id-3 poppins-normal-black-15px">{orderId}</div>
                  <div className="car-1-0093-11-2 poppins-medium-japanese-laurel-13px">{car1009311}</div>
                  <div className="address poppins-normal-black-15px">{address}</div>
                </div>
                <div className="flex-row-23">
                  <div className="customer-name poppins-normal-black-15px">{customerName}</div>
                  <div className="hendry-4 poppins-normal-japanese-laurel-15px">{hendry}</div>
                </div>
                <div className="flex-row-24">
                  <div className="contact-number poppins-normal-black-15px">{contactNumber}</div>
                  <div className="phone-6 poppins-normal-japanese-laurel-15px">{phone}</div>
                </div>
              </div>
              <p className="a45-3rd-floorroh poppins-normal-japanese-laurel-15px">{a453RdFloorRoh}</p>
            </div>
            <div className="change-status">{changeStatus}</div>
          </div>
          <div className="flex-row-25">
            <div className="layer-2">
              <div className="radio-button-on">
                <div className="overlap-group-58" style={{ backgroundImage: `url(${overlapGroup})` }}>
                  <img className="path-97" src={path97} />
                </div>
              </div>
            </div>
            <div className="overlap-group2-17">
              <img className="rectangle-2-12" src={rectangle2203} />
              <div className="pending-2 poppins-normal-white-14px">{pending}</div>
            </div>
            <Layer2 />
            <div className="overlap-group6-9">
              <img className="rectangle-2202" src={rectangle2202} />
              <div className="out-for-delivery-6 poppins-normal-white-14px">{outForDelivery}</div>
            </div>
            <Layer2 className={layer21Props.className} />
            <div className="overlap-group5-8">
              <img className="rectangle-2-12" src={rectangle2096} />
              <div className="delivered-2 poppins-normal-white-14px">{delivered}</div>
            </div>
          </div>
          <div className="flex-col-17">
            <div className="flex-row-26">
              <Layer2 className={layer22Props.className} />
              <div className="overlap-group4-13">
                <img className="rectangle-2-12" src={rectangle2204} />
                <div className="cancelled-4 poppins-normal-white-14px">{cancelled}</div>
              </div>
              <div className="cancellationreason">{cancellationReason}</div>
              <div className="rectangle-2211 border-1px-dove-gray"></div>
            </div>
            <div className="overlap-group7-7">
              <div className="update-1 poppins-medium-romance-15px">{update}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default PendingOrdersAction;
