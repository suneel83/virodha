import React from "react";
import RatingSvgrepoCom2 from "../RatingSvgrepoCom2";
import "./SelectOptions.css";

function SelectOptions(props) {
  const {
    x4,
    inStock,
    place,
    x15CustomerReviews,
    text41,
    type,
    poovan,
    sevvalai,
    price,
    rasthali,
    pachanaadan,
    name,
    quantity,
    inDozen,
    number,
    addToCart,
    heartSvgrepoCom,
    addToWishlist,
    prev,
    next,
    ratingSvgrepoCom2Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="select-options-3 screen">
        <div className="overlap-group1-35">
          <img className="x4-53" src={x4} />
          <div className="flex-col-62">
            <div className="overlap-group3-36">
              <div className="rectangle-31"></div>
              <div className="in-stock poppins-normal-cod-gray-16px">{inStock}</div>
            </div>
            <div className="overlap-group6-23">
              <div className="place-11 poppins-semi-bold-crusoe-41px">{place}</div>
              <div className="x15-customer-reviews poppins-normal-cod-gray-16px">{x15CustomerReviews}</div>
              <RatingSvgrepoCom2
                iconStar2={ratingSvgrepoCom2Props.iconStar2}
                iconStar3={ratingSvgrepoCom2Props.iconStar3}
                iconStar4={ratingSvgrepoCom2Props.iconStar4}
              />
              <div className="text-41 poppins-bold-sea-green-23px">{text41}</div>
            </div>
            <div className="flex-row-74 poppins-normal-cod-gray-15px">
              <div className="flex-col-63">
                <div className="type poppins-semi-bold-crusoe-18px">{type}</div>
                <div className="overlap-group5-25">
                  <div className="poovan-4 poppins-normal-cod-gray-15px">{poovan}</div>
                </div>
                <div className="sevvalai poppins-normal-cod-gray-15px">{sevvalai}</div>
                <div className="price-5 poppins-bold-crusoe-34px">{price}</div>
              </div>
              <div className="rasthali">{rasthali}</div>
              <div className="pachanaadan">{pachanaadan}</div>
              <div className="name-14">{name}</div>
            </div>
            <div className="flex-row-75">
              <div className="quantity poppins-semi-bold-crusoe-18px">{quantity}</div>
              <div className="in-dozen poppins-normal-cod-gray-16px">{inDozen}</div>
            </div>
            <div className="overlap-group-container-28">
              <div className="overlap-group4-32 border-1px-dove-gray">
                <div className="number-185 poppins-normal-cod-gray-16px">{number}</div>
              </div>
              <div className="overlap-group2-35">
                <div className="add-to-cart-2 poppins-normal-white-15px">{addToCart}</div>
              </div>
            </div>
            <div className="flex-row-76">
              <div className="heart-svgrepo-com" style={{ backgroundImage: `url(${heartSvgrepoCom})` }}></div>
              <div className="add-to-wishlist poppins-normal-cod-gray-11px">{addToWishlist}</div>
            </div>
          </div>
          <div className="prev poppins-normal-cod-gray-16px">{prev}</div>
          <div className="flex-col-64">
            <div className="multiply-cross-svgrepo-com">
              <div className="group-28">
                <div className="overlap-group-79">
                  <div className="rectangle-36"></div>
                  <div className="rectangle-37"></div>
                </div>
              </div>
            </div>
            <div className="next poppins-normal-cod-gray-16px">{next}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SelectOptions;
