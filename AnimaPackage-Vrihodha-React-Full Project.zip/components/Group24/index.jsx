import React from "react";
import "./Group24.css";

function Group24(props) {
  const { className } = props;

  return (
    <div className={`group-24 ${className || ""}`}>
      <div className="overlap-group-77">
        <div className="group-17-3">
          <div className="select-options-2 poppins-semi-bold-eerie-black-19px">Select Options</div>
        </div>
        <img className="greater-than-svgrepo-com-1" src="/img/greater-than-svgrepo-com-1@1x.png" />
      </div>
    </div>
  );
}

export default Group24;
