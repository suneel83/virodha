import React from "react";
import "./EditSubCategory.css";

function EditSubCategory(props) {
  const {
    flexCol,
    editSubCategory,
    category,
    vegitables,
    polygon3,
    subCategoryImage,
    upload,
    subCategoryName,
    unitKgsLts,
    beetroot,
    kgs,
    update,
    close,
    mrp,
    description,
    number1,
    qty,
    number2,
    sellingPrice,
    number3,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="edit-sub-category screen">
        <div className="overlap-group9-8 poppins-medium-cape-cod-15px">
          <div className="flex-col-8" style={{ backgroundImage: `url(${flexCol})` }}>
            <div className="flex-col-9">
              <div className="edit-sub-category-1 poppins-semi-bold-everglade-30px">{editSubCategory}</div>
              <div className="flex-row-12">
                <div className="category-4">{category}</div>
                <div className="overlap-group3-15">
                  <div className="vegitables-4">{vegitables}</div>
                  <img className="polygon-3-1" src={polygon3} />
                </div>
                <div className="sub-category-image-1">{subCategoryImage}</div>
                <div className="overlap-group1-26">
                  <div className="rectangle-2111-1"></div>
                  <div className="upload-1 poppins-normal-white-12px">{upload}</div>
                </div>
              </div>
            </div>
            <div className="flex-row-13">
              <div className="flex-row-14">
                <div className="flex-col-10">
                  <div className="sub-category-name-1">{subCategoryName}</div>
                  <div className="unit-kgs-lts-1">{unitKgsLts}</div>
                </div>
                <div className="flex-col-11">
                  <div className="overlap-group5-7">
                    <div className="beetroot poppins-medium-cape-cod-15px">{beetroot}</div>
                  </div>
                  <div className="overlap-group6-8">
                    <div className="kgs poppins-medium-cape-cod-15px">{kgs}</div>
                  </div>
                  <div className="overlap-group-container-10">
                    <div className="overlap-group7-6">
                      <div className="update poppins-medium-snow-flurry-15px">{update}</div>
                    </div>
                    <div className="overlap-group4-11">
                      <div className="close-1 poppins-medium-cape-cod-15px">{close}</div>
                    </div>
                  </div>
                </div>
                <div className="flex-col-12">
                  <div className="mrp-2">{mrp}</div>
                  <div className="description-1">{description}</div>
                </div>
              </div>
              <div className="flex-col-13">
                <div className="flex-row-15">
                  <div className="overlap-group8-8">
                    <div className="number-137">{number1}</div>
                  </div>
                  <div className="qty-2">{qty}</div>
                  <div className="overlap-group2-16">
                    <div className="number-138">{number2}</div>
                  </div>
                </div>
                <div className="rectangle-2176-1"></div>
              </div>
            </div>
          </div>
          <div className="rectangle-2187-1"></div>
          <div className="selling-price-1">{sellingPrice}</div>
          <div className="number-139">{number3}</div>
        </div>
      </div>
    </div>
  );
}

export default EditSubCategory;
