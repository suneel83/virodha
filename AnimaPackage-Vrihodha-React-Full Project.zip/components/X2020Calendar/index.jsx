import React from "react";
import "./X2020Calendar.css";

function X2020Calendar(props) {
  const { className } = props;

  return (
    <div className={`x2020-calendar ${className || ""}`}>
      <div className="overlap-group4-1">
        <div className="january">
          <div className="overlap-group-2">
            <div className="january-2020 poppins-medium-white-9px">January 2020</div>
          </div>
          <div className="overlap-group-container-2">
            <div className="overlap-group-3">
              <div className="m poppins-normal-black-8px">M</div>
            </div>
            <div className="overlap-group-4">
              <div className="t poppins-normal-black-9px">T</div>
            </div>
            <div className="overlap-group2-2">
              <div className="w poppins-normal-black-9px">W</div>
            </div>
            <div className="overlap-group-5">
              <div className="t-1 poppins-normal-black-9px">T</div>
            </div>
            <div className="overlap-group-5">
              <div className="f poppins-normal-black-9px">F</div>
            </div>
            <div className="overlap-group-6">
              <div className="price poppins-normal-black-8px">S</div>
            </div>
            <div className="overlap-group-7">
              <div className="price-1 poppins-normal-black-8px">S</div>
            </div>
          </div>
          <div className="overlap-group-container-2">
            <div className="overlap-group-8">
              <div className="number-21 poppins-normal-shady-lady-9px">30</div>
            </div>
            <div className="overlap-group-9">
              <div className="number-22 poppins-normal-shady-lady-7px">31</div>
            </div>
            <div className="overlap-group-10">
              <div className="number-23 poppins-normal-black-8px">1</div>
            </div>
            <div className="overlap-group-11">
              <div className="number-26 poppins-normal-black-8px">2</div>
            </div>
            <div className="overlap-group-11">
              <div className="number-27 poppins-normal-black-8px">3</div>
            </div>
            <div className="overlap-group-12">
              <div className="number-24 poppins-normal-black-7px">4</div>
            </div>
            <div className="overlap-group-13">
              <div className="number-24 poppins-normal-black-7px">5</div>
            </div>
          </div>
          <div className="overlap-group-container-2">
            <div className="overlap-group-14">
              <div className="number-24 poppins-normal-black-7px">6</div>
            </div>
            <div className="overlap-group1-3">
              <div className="number-28 poppins-normal-black-9px">7</div>
            </div>
            <div className="overlap-group-13">
              <div className="number-24 poppins-normal-black-7px">8</div>
            </div>
            <div className="overlap-group-13">
              <div className="number-24 poppins-normal-black-7px">9</div>
            </div>
            <div className="overlap-group2-3">
              <div className="number-29 poppins-normal-black-9px">10</div>
            </div>
            <div className="overlap-group-12">
              <div className="number-24 poppins-normal-black-7px">11</div>
            </div>
            <div className="overlap-group-15">
              <div className="number-22 poppins-normal-black-7px">12</div>
            </div>
          </div>
          <div className="overlap-group-container-2">
            <div className="overlap-group-16">
              <div className="number-22 poppins-normal-black-7px">13</div>
            </div>
            <div className="overlap-group-17">
              <div className="number-30 poppins-normal-black-9px">14</div>
            </div>
            <div className="overlap-group-18">
              <div className="number-31 poppins-normal-black-9px">15</div>
            </div>
            <div className="overlap-group-18">
              <div className="number-32 poppins-normal-black-9px">16</div>
            </div>
            <div className="overlap-group-19">
              <div className="number-33 poppins-normal-black-8px">17</div>
            </div>
            <div className="overlap-group-17">
              <div className="number-34 poppins-normal-black-9px">18</div>
            </div>
            <div className="overlap-group-18">
              <div className="number-35 poppins-normal-black-9px">19</div>
            </div>
          </div>
          <div className="overlap-group-container-2">
            <div className="overlap-group-20">
              <div className="number-21 poppins-normal-black-9px">20</div>
            </div>
            <div className="overlap-group-21">
              <div className="number-22 poppins-normal-black-7px">21</div>
            </div>
            <div className="overlap-group-22">
              <div className="number-25 poppins-normal-black-8px">22</div>
            </div>
            <div className="overlap-group-22">
              <div className="number-25 poppins-normal-black-8px">23</div>
            </div>
            <div className="overlap-group-20">
              <div className="number-21 poppins-normal-black-9px">24</div>
            </div>
            <div className="overlap-group-23">
              <div className="number-21 poppins-normal-black-9px">25</div>
            </div>
            <div className="overlap-group-20">
              <div className="number-21 poppins-normal-black-9px">26</div>
            </div>
          </div>
          <div className="overlap-group-container-2">
            <div className="overlap-group1-4">
              <div className="number-21 poppins-normal-black-9px">27</div>
            </div>
            <div className="overlap-group3-2">
              <div className="number-21 poppins-normal-black-9px">28</div>
            </div>
            <div className="overlap-group-8">
              <div className="number-21 poppins-normal-black-9px">29</div>
            </div>
            <div className="overlap-group-8">
              <div className="number-21 poppins-normal-black-9px">30</div>
            </div>
            <div className="overlap-group-24">
              <div className="number-22 poppins-normal-black-7px">31</div>
            </div>
            <div className="overlap-group-25">
              <div className="number-23 poppins-normal-shady-lady-8px">1</div>
            </div>
            <div className="overlap-group-10">
              <div className="number-36 poppins-normal-shady-lady-8px">2</div>
            </div>
          </div>
        </div>
        <img className="path-62" src="/img/path-62-1@1x.png" />
        <img className="path-63" src="/img/path-63-1@1x.png" />
      </div>
    </div>
  );
}

export default X2020Calendar;
