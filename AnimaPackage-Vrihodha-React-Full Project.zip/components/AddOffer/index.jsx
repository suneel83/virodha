import React from "react";
import "./AddOffer.css";

function AddOffer(props) {
  const {
    addAnOffer,
    productCategory,
    mainProductName,
    subProductName1,
    mrp,
    unit,
    description,
    selectProductCategory,
    polygon1,
    selectProductName,
    polygon2,
    subProductName2,
    polygon4,
    offerPrice,
    qty,
    close,
    add,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="add-offer-1 screen">
        <div className="overlap-group-65">
          <div className="add-an-offer poppins-semi-bold-cape-cod-21px">{addAnOffer}</div>
          <div className="flex-row-45">
            <div className="flex-col-32 poppins-medium-cape-cod-13px">
              <div className="product-category-2">{productCategory}</div>
              <div className="main-product-name">{mainProductName}</div>
              <div className="sub-product-name">{subProductName1}</div>
              <div className="mrp-5">{mrp}</div>
              <div className="unit-2">{unit}</div>
              <div className="description-6">{description}</div>
            </div>
            <div className="flex-col-33">
              <div className="overlap-group-container-16 poppins-medium-westar-11px">
                <div className="overlap-group2-23">
                  <div className="select-product-category-2">{selectProductCategory}</div>
                  <img className="polygon-1-2" src={polygon1} />
                </div>
                <div className="overlap-group6-14">
                  <div className="select-product-name">{selectProductName}</div>
                  <img className="polygon-2" src={polygon2} />
                </div>
                <div className="overlap-group4-20">
                  <div className="sub-product-name-1">{subProductName2}</div>
                  <img className="polygon-4" src={polygon4} />
                </div>
              </div>
              <div className="flex-row-46">
                <div className="flex-col-34">
                  <div className="rectangle-21-4"></div>
                  <div className="rectangle-2179-2"></div>
                </div>
                <div className="flex-col-35 poppins-medium-cape-cod-13px">
                  <div className="offer-price-1">{offerPrice}</div>
                  <div className="qty-6">{qty}</div>
                </div>
                <div className="flex-col-36">
                  <div className="rectangle-21-4"></div>
                  <div className="rectangle-2181-1"></div>
                </div>
              </div>
              <div className="rectangle-2110-3"></div>
              <div className="overlap-group-container-17">
                <div className="overlap-group5-15">
                  <div className="close-7 poppins-medium-cape-cod-15px">{close}</div>
                </div>
                <div className="overlap-group3-24">
                  <div className="add-3 poppins-medium-romance-15px">{add}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AddOffer;
