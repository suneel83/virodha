import React from "react";
import "./B.css";

function B(props) {
  const { className } = props;

  return (
    <div className={`b ${className || ""}`}>
      <img className="path-94" src="/img/path-94-10@1x.png" />
      <img className="path-93" src="/img/path-93-10@1x.png" />
    </div>
  );
}

export default B;
