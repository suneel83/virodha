import React from "react";
import "./AddProduct.css";

function AddProduct(props) {
  const {
    addProduct,
    plusSvgrepoCom1,
    productCategory,
    productName,
    productImage,
    mrp,
    unit,
    description,
    selectProductCategory,
    polygon1,
    upload,
    sellingPrice,
    qty,
    close,
    add,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="add-product-1 screen">
        <div className="overlap-group-63">
          <div className="add-product-2 poppins-semi-bold-cape-cod-21px">{addProduct}</div>
          <div className="overlap-group2-21 border-0-5px-dove-gray">
            <div className="plus-svgrepo-com-1-6" style={{ backgroundImage: `url(${plusSvgrepoCom1})` }}></div>
          </div>
          <div className="flex-row-40">
            <div className="flex-col-25 poppins-medium-cape-cod-13px">
              <div className="product-category">{productCategory}</div>
              <p className="product-name-2">{productName}</p>
              <div className="product-image">{productImage}</div>
              <div className="mrp-3">{mrp}</div>
              <div className="unit">{unit}</div>
              <div className="description-4">{description}</div>
            </div>
            <div className="flex-col-26">
              <div className="overlap-group3-22">
                <div className="select-product-category poppins-medium-westar-11px">{selectProductCategory}</div>
                <img className="polygon-1" src={polygon1} />
              </div>
              <div className="rectangle-2109"></div>
              <div className="overlap-group5-13">
                <div className="rectangle-2111-4"></div>
                <div className="upload-4 poppins-normal-white-12px">{upload}</div>
              </div>
              <div className="flex-row-41">
                <div className="flex-col-27">
                  <div className="rectangle-21-3"></div>
                  <div className="rectangle-2179"></div>
                </div>
                <div className="flex-col-28 poppins-medium-cape-cod-13px">
                  <div className="selling-price-2">{sellingPrice}</div>
                  <div className="qty-4">{qty}</div>
                </div>
                <div className="flex-col-29">
                  <div className="rectangle-21-3"></div>
                  <div className="rectangle-2181"></div>
                </div>
              </div>
              <div className="rectangle-2110-1"></div>
              <div className="overlap-group-container-14">
                <div className="overlap-group4-18">
                  <div className="close-5 poppins-medium-cape-cod-15px">{close}</div>
                </div>
                <div className="overlap-group6-12">
                  <div className="add-2 poppins-medium-romance-15px">{add}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AddProduct;
