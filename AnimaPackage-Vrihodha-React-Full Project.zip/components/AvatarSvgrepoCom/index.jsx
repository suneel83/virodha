import React from "react";
import "./AvatarSvgrepoCom.css";

function AvatarSvgrepoCom(props) {
  const { path82, path85, path86, path87, path89 } = props;

  return (
    <div className="avatar-svgrepo-com-2">
      <div className="group-53">
        <div className="group-52">
          <div className="overlap-group1-5">
            <div className="overlap-group-26">
              <img className="path-79" src="/img/path-79-1@1x.png" />
              <img className="path-80" src="/img/path-80-1@1x.png" />
              <div className="rectangle-2185"></div>
              <div className="rectangle-2186"></div>
              <img className="path-81" src="/img/path-81-1@1x.png" />
              <img className="path-82" src={path82} />
              <img className="path-83" src="/img/path-83-1@1x.png" />
              <img className="path-84" src="/img/path-84-1@1x.png" />
              <img className="path-85" src={path85} />
            </div>
            <img className="path-86" src={path86} />
            <img className="path-87" src={path87} />
            <img className="path-88" src="/img/path-88-1@1x.png" />
            <img className="path-89" src={path89} />
            <img className="path-90" src="/img/path-90-1@1x.png" />
            <img className="path-91" src="/img/path-91-1@1x.png" />
            <img className="path-92" src="/img/path-92-1@1x.png" />
          </div>
        </div>
      </div>
    </div>
  );
}

export default AvatarSvgrepoCom;
