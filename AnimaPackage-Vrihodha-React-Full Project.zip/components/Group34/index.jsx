import React from "react";
import "./Group34.css";

function Group34() {
  return (
    <div className="group-34-1">
      <div className="submit-1 poppins-medium-white-21px">SUBMIT</div>
    </div>
  );
}

export default Group34;
