import React from "react";
import "./SellProductSvgrepoCom.css";

function SellProductSvgrepoCom(props) {
  const { className } = props;

  return (
    <div className={`sell-product-svgrepo-com-1 ${className || ""}`}>
      <img className="path-8" src="/img/path-8-1@1x.png" />
      <img className="path-7" src="/img/path-7-1@1x.png" />
    </div>
  );
}

export default SellProductSvgrepoCom;
