import React from "react";
import { Link } from "react-router-dom";
import Group35 from "../Group35";
import AvatarSvgrepoCom from "../AvatarSvgrepoCom";
import "./GenerateOffer.css";

function GenerateOffer(props) {
  const {
    x18,
    leaf11,
    dashboard,
    productManagement1,
    orderManagement,
    manageNotifications,
    adminPanel,
    x41,
    x42,
    x43,
    leaf12,
    leaf2,
    untitledDesign,
    laptopSvgrepoCom,
    iconUser,
    sellProductSvgrepoCom1,
    menuOrderSvgrepoCom,
    iconNotifications,
    productManagement2,
    sellProductSvgrepoCom2,
    subCategoryList,
    productsList,
    enterArrowSvgrepoCom1,
    enterArrowSvgrepoCom2,
    welcome,
    admin,
    path77,
    path78,
    line1,
    overlapGroup2,
    productsOnOffer,
    search,
    plusSvgrepoCom1,
    addOffer,
    text20,
    categoryName,
    subItem,
    mainItem,
    qty,
    mrp,
    offerPrice,
    action,
    number1,
    fruits1,
    poovan,
    place,
    number2,
    rs2500,
    rs20001,
    textEdit1,
    iconTrash1,
    number3,
    fruits2,
    kashmirAppleG1,
    apple,
    number4,
    rs15000,
    rs8000,
    textEdit2,
    iconTrash2,
    number5,
    fruits3,
    australianOrchid,
    color,
    number6,
    rs5000,
    rs3000,
    textEdit3,
    iconTrash3,
    path74,
    number7,
    fruits4,
    sonaGrapes,
    grapes,
    number8,
    rs4000,
    rs20002,
    textEdit4,
    iconTrash4,
    number9,
    vegitables,
    ponnakanni,
    spinach,
    number10,
    rs1500,
    rs20003,
    textEdit5,
    iconTrash5,
    submitOffer,
    number11,
    number12,
    number13,
    number14,
    avatarSvgrepoComProps,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="generate-offer screen">
        <div className="overlap-group14-5">
          <div className="overlap-group3-13">
            <div className="rectangle-2-11"></div>
            <img className="x18-10" src={x18} />
            <div className="rectangle-1-10"></div>
            <img className="leaf1-20" src={leaf11} />
            <div className="rectangle-3-6"></div>
            <div className="rectangle-6-7"></div>
            <div className="rectangle-7-7"></div>
            <div className="rectangle-8-7"></div>
            <div className="dashboard-7 poppins-medium-don-juan-17px">{dashboard}</div>
            <div className="product-management-7 poppins-medium-don-juan-17px">{productManagement1}</div>
            <div className="order-management-10 poppins-medium-don-juan-17px">{orderManagement}</div>
            <div className="manage-notifications-10 poppins-medium-don-juan-17px">{manageNotifications}</div>
            <div className="admin-panel-10 poppins-semi-bold-chicago-33px">{adminPanel}</div>
            <img className="x4-31" src={x41} />
            <img className="x4-32" src={x42} />
            <img className="x4-33" src={x43} />
            <img className="leaf1-21" src={leaf12} />
            <img className="leaf2-10" src={leaf2} />
            <img className="untitled-design-11" src={untitledDesign} />
            <img className="laptop-svgrepo-com-7" src={laptopSvgrepoCom} />
            <Group35 />
            <img className="icon-user-8" src={iconUser} />
            <img className="sell-product-svgrepo-com-10" src={sellProductSvgrepoCom1} />
            <img className="menu-order-svgrepo-com-10" src={menuOrderSvgrepoCom} />
            <img className="icon-notifications-8" src={iconNotifications} />
            <div className="rectangle-6-8"></div>
            <div className="product-management-8 poppins-medium-white-17px">{productManagement2}</div>
            <img className="sell-product-svgrepo-com-11" src={sellProductSvgrepoCom2} />
            <div className="sub-category-list-4 poppins-medium-lemon-glacier-14px">{subCategoryList}</div>
            <div className="products-list-3 poppins-medium-lemon-glacier-14px">{productsList}</div>
            <img className="enter-arrow-svgrepo-com-10" src={enterArrowSvgrepoCom1} />
            <img className="enter-arrow-svgrepo-com-11" src={enterArrowSvgrepoCom2} />
            <div className="welcome-10 poppins-medium-don-juan-14px">{welcome}</div>
            <div className="admin-10 poppins-medium-don-juan-14px">{admin}</div>
            <div className="path-container-11">
              <img className="path-77-7" src={path77} />
              <img className="path-78-7" src={path78} />
            </div>
            <AvatarSvgrepoCom
              path82={avatarSvgrepoComProps.path82}
              path85={avatarSvgrepoComProps.path85}
              path86={avatarSvgrepoComProps.path86}
              path87={avatarSvgrepoComProps.path87}
              path89={avatarSvgrepoComProps.path89}
            />
          </div>
          <img className="line-1-8" src={line1} />
          <div className="overlap-group2-14" style={{ backgroundImage: `url(${overlapGroup2})` }}>
            <div className="flex-row-6">
              <div className="products-on-offer poppins-semi-bold-everglade-30px">{productsOnOffer}</div>
              <div className="search-7 poppins-semi-bold-cape-cod-18px">{search}</div>
              <div className="rectangle-2112-6"></div>
              <a href="javascript:ShowOverlay('add-offer', 'animate-appear');">
                <div className="group-39-2">
                  <div className="plus-svgrepo-com-1-4" style={{ backgroundImage: `url(${plusSvgrepoCom1})` }}></div>
                  <div className="add-offer poppins-medium-white-17px">{addOffer}</div>
                </div>
              </a>
            </div>
            <div className="overlap-group5-6 poppins-medium-cape-cod-18px">
              <div className="text-20">{text20}</div>
              <div className="category-name">{categoryName}</div>
              <div className="sub-item">{subItem}</div>
              <div className="main-item">{mainItem}</div>
              <div className="qty">{qty}</div>
              <div className="mrp">{mrp}</div>
              <div className="offer-price">{offerPrice}</div>
              <div className="action-4">{action}</div>
            </div>
            <div className="overlap-group6-7">
              <div className="number-127 poppins-normal-cape-cod-18px">{number1}</div>
              <div className="fruits-8 poppins-semi-bold-dell-18px">{fruits1}</div>
              <div className="poovan-1 poppins-semi-bold-dell-18px">{poovan}</div>
              <div className="place-2 poppins-semi-bold-dell-18px">{place}</div>
              <div className="number-128 poppins-semi-bold-dell-18px">{number2}</div>
              <div className="rs2500 poppins-semi-bold-dell-18px">{rs2500}</div>
              <div className="rs2000 poppins-semi-bold-dell-18px">{rs20001}</div>
              <a href="javascript:ShowOverlay('edit-offer', 'animate-appear');" className="align-self-flex-start">
                <img className="text-edit-24" src={textEdit1} />
              </a>
              <img className="icon-trash-27" src={iconTrash1} />
            </div>
            <div className="overlap-group9-7">
              <div className="number-125 poppins-normal-cape-cod-18px">{number3}</div>
              <div className="fruits-9 poppins-semi-bold-dell-18px">{fruits2}</div>
              <div className="kashmir-apple-g1-1 poppins-semi-bold-dell-18px">{kashmirAppleG1}</div>
              <div className="apple-2 poppins-semi-bold-dell-18px">{apple}</div>
              <div className="number-129 poppins-semi-bold-dell-18px">{number4}</div>
              <div className="rs15000 poppins-semi-bold-dell-18px">{rs15000}</div>
              <div className="rs8000 poppins-semi-bold-dell-18px">{rs8000}</div>
              <img className="text-edit-25" src={textEdit2} />
              <img className="icon-trash-27" src={iconTrash2} />
            </div>
            <div className="overlap-group-54">
              <div className="number-125 poppins-normal-cape-cod-18px">{number5}</div>
              <div className="fruits-10 poppins-semi-bold-dell-18px">{fruits3}</div>
              <div className="australian-orchid-1 poppins-semi-bold-dell-18px">{australianOrchid}</div>
              <div className="color-2 poppins-semi-bold-dell-18px">{color}</div>
              <div className="number-130 poppins-semi-bold-dell-18px">{number6}</div>
              <div className="rs5000 poppins-semi-bold-dell-18px">{rs5000}</div>
              <div className="rs3000 poppins-semi-bold-dell-18px">{rs3000}</div>
              <img className="text-edit-23" src={textEdit3} />
              <img className="icon-trash-27" src={iconTrash3} />
            </div>
            <div className="overlap-group11-6">
              <img className="path-74-4" src={path74} />
              <div className="flex-row-7">
                <div className="number-131 poppins-normal-cape-cod-18px">{number7}</div>
                <div className="fruits-11 poppins-semi-bold-dell-18px">{fruits4}</div>
                <div className="sona-grapes-1 poppins-semi-bold-dell-18px">{sonaGrapes}</div>
                <div className="grapes-2 poppins-semi-bold-dell-18px">{grapes}</div>
                <div className="number-132 poppins-semi-bold-dell-18px">{number8}</div>
                <div className="rs4000 poppins-semi-bold-dell-18px">{rs4000}</div>
                <div className="rs2000-1 poppins-semi-bold-dell-18px">{rs20002}</div>
                <img className="text-edit-23" src={textEdit4} />
                <img className="icon-trash-27" src={iconTrash4} />
              </div>
            </div>
            <div className="overlap-group-54">
              <div className="number-133 poppins-normal-cape-cod-18px">{number9}</div>
              <div className="vegitables-3 poppins-semi-bold-dell-18px">{vegitables}</div>
              <div className="ponnakanni-1 poppins-semi-bold-dell-18px">{ponnakanni}</div>
              <div className="spinach-2 poppins-semi-bold-dell-18px">{spinach}</div>
              <div className="number-134 poppins-semi-bold-dell-18px">{number10}</div>
              <div className="rs1500 poppins-semi-bold-dell-18px">{rs1500}</div>
              <div className="rs2000-2 poppins-semi-bold-dell-18px">{rs20003}</div>
              <img className="text-edit-23" src={textEdit5} />
              <img className="icon-trash-27" src={iconTrash5} />
            </div>
            <div className="group-container-9">
              <div className="group-58">
                <div className="submit-offer poppins-medium-white-17px">{submitOffer}</div>
              </div>
              <div className="overlap-group13-4">
                <div className="number-135 poppins-medium-shady-lady-15px">{number11}</div>
              </div>
              <div className="overlap-group-55">
                <div className="number-126 poppins-medium-shady-lady-15px">{number12}</div>
              </div>
              <div className="overlap-group-55">
                <div className="number-126 poppins-medium-shady-lady-15px">{number13}</div>
              </div>
              <div className="overlap-group10-2">
                <div className="number-136 poppins-medium-shady-lady-15px">{number14}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default GenerateOffer;
