import React from "react";
import { Link } from "react-router-dom";
import UsersSilhouettesSvgrepoCom from "../UsersSilhouettesSvgrepoCom";
import SellProductSvgrepoCom from "../SellProductSvgrepoCom";
import MenuOrderSvgrepoCom from "../MenuOrderSvgrepoCom";
import NotificationSvgrepoCom from "../NotificationSvgrepoCom";
import AvatarSvgrepoCom from "../AvatarSvgrepoCom";
import B from "../B";
import "./UserBasedOrderLists.css";

function UserBasedOrderLists(props) {
  const {
    untitledDesign20,
    adminPanel,
    untitledDesign,
    leaf11,
    userManagement,
    categoryManagement,
    productManagement,
    orderManagement,
    manageNotifications,
    x41,
    x42,
    x43,
    x18,
    leaf12,
    leaf2,
    laptopSvgrepoCom,
    dashboard,
    categoryAltSvgrepoCom,
    rectangle1596,
    fromDate,
    userIdMobileNumber,
    mmDdYyyy1,
    mmDdYyyy2,
    toDate,
    showOrders,
    calenderSvgrepoCom1,
    calenderSvgrepoCom2,
    allOrders,
    userBasedOrders,
    enterArrowSvgrepoCom1,
    enterArrowSvgrepoCom2,
    welcome,
    admin,
    path77,
    path78,
    overlapGroup3,
    hiHendry,
    checkYourOrdersHere,
    search,
    no,
    orderId,
    orderTaken,
    status,
    amount,
    details,
    number1,
    car1009311,
    date1,
    rectangle16,
    delivered1,
    rs24300,
    view1,
    number2,
    car1004341,
    date2,
    delivered2,
    rs54300,
    view2,
    number3,
    car1003156,
    date3,
    rectangle19,
    outForDelivery,
    rs85400,
    overlapGroup17,
    view3,
    number4,
    car1006126,
    date4,
    rectangle18,
    delivered3,
    rs87400,
    view4,
    number5,
    car2002125,
    date5,
    rectangle20,
    cancelled,
    rs90400,
    view5,
    number6,
    number7,
    number8,
    number9,
    usersSilhouettesSvgrepoComProps,
    sellProductSvgrepoComProps,
    menuOrderSvgrepoComProps,
    notificationSvgrepoComProps,
    avatarSvgrepoComProps,
    b1Props,
    b2Props,
    b3Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="user-based-order-lists screen">
        <div className="overlap-group-container-3">
          <div className="overlap-group4-2">
            <img className="untitled-design-20" src={untitledDesign20} />
            <div className="rectangle-1-2"></div>
            <div className="admin-panel-2 poppins-semi-bold-chicago-33px">{adminPanel}</div>
            <img className="untitled-design-3" src={untitledDesign} />
            <div className="rectangle-2-2"></div>
            <img className="leaf1-4" src={leaf11} />
            <div className="rectangle-4-1"></div>
            <div className="rectangle-5-1"></div>
            <div className="rectangle-6-1"></div>
            <div className="rectangle-7-1"></div>
            <div className="rectangle-8-1"></div>
            <div className="user-management-1 poppins-medium-don-juan-17px">{userManagement}</div>
            <div className="category-management-1 poppins-medium-don-juan-17px">{categoryManagement}</div>
            <div className="product-management-1 poppins-medium-don-juan-17px">{productManagement}</div>
            <div className="order-management-2 poppins-medium-white-17px">{orderManagement}</div>
            <div className="manage-notifications-2 poppins-medium-don-juan-17px">{manageNotifications}</div>
            <img className="x4-6" src={x41} />
            <img className="x4-7" src={x42} />
            <img className="x4-8" src={x43} />
            <img className="x18-2" src={x18} />
            <img className="leaf1-5" src={leaf12} />
            <img className="leaf2-2" src={leaf2} />
            <Link to="/dashboard-pending-orders">
              <div className="group-33-1">
                <img className="laptop-svgrepo-com-1" src={laptopSvgrepoCom} />
                <div className="dashboard-1 poppins-medium-don-juan-17px">{dashboard}</div>
              </div>
            </Link>
            <UsersSilhouettesSvgrepoCom
              path1={usersSilhouettesSvgrepoComProps.path1}
              path2={usersSilhouettesSvgrepoComProps.path2}
              path6={usersSilhouettesSvgrepoComProps.path6}
              path3={usersSilhouettesSvgrepoComProps.path3}
              path4={usersSilhouettesSvgrepoComProps.path4}
              path5={usersSilhouettesSvgrepoComProps.path5}
              className={usersSilhouettesSvgrepoComProps.className}
            />
            <img className="category-alt-svgrepo-com-1" src={categoryAltSvgrepoCom} />
            <SellProductSvgrepoCom className={sellProductSvgrepoComProps.className} />
            <MenuOrderSvgrepoCom className={menuOrderSvgrepoComProps.className} />
            <NotificationSvgrepoCom className={notificationSvgrepoComProps.className} />
            <div className="rectangle-1594-1"></div>
            <div className="rectangle-2180"></div>
            <img className="rectangle-1596-1" src={rectangle1596} />
            <div className="rectangle-1595-1"></div>
            <div className="from-date-1 poppins-semi-bold-don-juan-14px">{fromDate}</div>
            <p className="user-id-mobile-number poppins-semi-bold-don-juan-14px">{userIdMobileNumber}</p>
            <div className="mm-dd-yyyy-2 poppins-normal-mountain-mist-12px">{mmDdYyyy1}</div>
            <div className="mm-dd-yyyy-3 poppins-normal-mountain-mist-12px">{mmDdYyyy2}</div>
            <div className="to-date-1 poppins-semi-bold-don-juan-14px">{toDate}</div>
            <div className="show-orders poppins-normal-white-12px">{showOrders}</div>
            <img className="calender-svgrepo-com-2" src={calenderSvgrepoCom1} />
            <img className="calender-svgrepo-com-3" src={calenderSvgrepoCom2} />
            <Link to="/all-orders">
              <div className="all-orders poppins-medium-lemon-glacier-14px">{allOrders}</div>
            </Link>
            <div className="user-based-orders poppins-medium-lemon-glacier-14px">{userBasedOrders}</div>
            <img className="enter-arrow-svgrepo-com-1" src={enterArrowSvgrepoCom1} />
            <img className="enter-arrow-svgrepo-com-2" src={enterArrowSvgrepoCom2} />
            <div className="welcome-2 poppins-medium-don-juan-14px">{welcome}</div>
            <div className="admin-2 poppins-medium-don-juan-14px">{admin}</div>
            <div className="path-container-5">
              <img className="path-77-1" src={path77} />
              <img className="path-78-1" src={path78} />
            </div>
            <AvatarSvgrepoCom
              path82={avatarSvgrepoComProps.path82}
              path85={avatarSvgrepoComProps.path85}
              path86={avatarSvgrepoComProps.path86}
              path87={avatarSvgrepoComProps.path87}
              path89={avatarSvgrepoComProps.path89}
            />
          </div>
          <div className="overlap-group3-3" style={{ backgroundImage: `url(${overlapGroup3})` }}>
            <div className="flex-row">
              <div className="flex-col">
                <div className="hi-hendry poppins-semi-bold-everglade-30px">{hiHendry}</div>
                <div className="check-your-orders-here poppins-normal-cape-cod-15px">{checkYourOrdersHere}</div>
              </div>
              <div className="search-1 poppins-semi-bold-cape-cod-18px">{search}</div>
              <div className="rectangle-2112-1"></div>
            </div>
            <div className="overlap-group9-1 poppins-medium-cape-cod-18px">
              <div className="no-2">{no}</div>
              <div className="order-id-1">{orderId}</div>
              <B className={b1Props.className} />
              <div className="order-taken">{orderTaken}</div>
              <B className={b2Props.className} />
              <div className="status-1">{status}</div>
              <div className="amount-1">{amount}</div>
              <B className={b3Props.className} />
              <div className="details-2">{details}</div>
            </div>
            <div className="overlap-group11-1">
              <div className="number-49 poppins-normal-cape-cod-15px">{number1}</div>
              <div className="car-1-0093-11-1 poppins-normal-cape-cod-15px">{car1009311}</div>
              <div className="date-5 poppins-normal-cape-cod-15px">{date1}</div>
              <div className="overlap-group1-16">
                <img className="rectangle-3" src={rectangle16} />
                <div className="delivered poppins-normal-white-14px">{delivered1}</div>
              </div>
              <div className="rs24300 poppins-semi-bold-dell-15px">{rs24300}</div>
              <div className="overlap-group-37">
                <a href="javascript:ShowOverlay('all-orders-view', 'animate-appear');">
                  <div className="rectangle-21-1"></div>
                </a>
                <div className="view-7 poppins-normal-white-14px">{view1}</div>
              </div>
            </div>
            <div className="overlap-group6-1">
              <div className="number-50 poppins-normal-cape-cod-15px">{number2}</div>
              <div className="car-1-0043-41-1 poppins-normal-cape-cod-15px">{car1004341}</div>
              <div className="date-6 poppins-normal-cape-cod-15px">{date2}</div>
              <div className="overlap-group15">
                <div className="rectangle-17"></div>
                <div className="delivered poppins-normal-white-14px">{delivered2}</div>
              </div>
              <div className="rs54300-1 poppins-semi-bold-dell-15px">{rs54300}</div>
              <div className="overlap-group2-4">
                <div className="view-6 poppins-normal-white-14px">{view2}</div>
              </div>
            </div>
            <div className="overlap-group5-1">
              <div className="number-51 poppins-normal-cape-cod-15px">{number3}</div>
              <div className="car-1-0031-56-1 poppins-normal-cape-cod-15px">{car1003156}</div>
              <div className="date-7 poppins-normal-cape-cod-15px">{date3}</div>
              <div className="overlap-group16-1">
                <img className="rectangle-19" src={rectangle19} />
                <div className="out-for-delivery-1 poppins-normal-white-14px">{outForDelivery}</div>
              </div>
              <div className="rs85400-1 poppins-semi-bold-dell-15px">{rs85400}</div>
              <div className="overlap-group17-1" style={{ backgroundImage: `url(${overlapGroup17})` }}>
                <div className="view-6 poppins-normal-white-14px">{view3}</div>
              </div>
            </div>
            <div className="overlap-group7-1">
              <div className="number-52 poppins-normal-cape-cod-15px">{number4}</div>
              <div className="car-1-0061-26-1 poppins-normal-cape-cod-15px">{car1006126}</div>
              <div className="date-8 poppins-normal-cape-cod-15px">{date4}</div>
              <div className="overlap-group18">
                <img className="rectangle-3" src={rectangle18} />
                <div className="delivered poppins-normal-white-14px">{delivered3}</div>
              </div>
              <div className="rs87400-1 poppins-semi-bold-dell-15px">{rs87400}</div>
              <div className="overlap-group19-1">
                <div className="view-6 poppins-normal-white-14px">{view4}</div>
              </div>
            </div>
            <div className="overlap-group8-1">
              <div className="number-53 poppins-normal-cape-cod-15px">{number5}</div>
              <div className="car-2-0021-25-1 poppins-normal-cape-cod-15px">{car2002125}</div>
              <div className="date-9 poppins-normal-cape-cod-15px">{date5}</div>
              <div className="overlap-group21-1">
                <img className="rectangle-3" src={rectangle20} />
                <div className="cancelled poppins-normal-white-14px">{cancelled}</div>
              </div>
              <div className="rs90400-1 poppins-semi-bold-dell-15px">{rs90400}</div>
              <div className="overlap-group20-1">
                <div className="view-6 poppins-normal-white-14px">{view5}</div>
              </div>
            </div>
            <div className="overlap-group-container-4">
              <div className="overlap-group12-1">
                <div className="number-54 poppins-medium-shady-lady-15px">{number6}</div>
              </div>
              <div className="overlap-group1-15">
                <div className="number-48 poppins-medium-shady-lady-15px">{number7}</div>
              </div>
              <div className="overlap-group1-15">
                <div className="number-48 poppins-medium-shady-lady-15px">{number8}</div>
              </div>
              <div className="overlap-group14-1">
                <div className="number-55 poppins-medium-shady-lady-15px">{number9}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default UserBasedOrderLists;
