import React from "react";
import "./XMLID1454.css";

function XMLID1454(props) {
  const { xmlid_504_, xmlid_507_, xmlid_509_, xmlid_510_, xmlid_511_, className } = props;

  return (
    <div className={`xmlid_1454_ ${className || ""}`}>
      <div className="xmlid_-container">
        <div className="xmlid_495_">
          <img className="xmlid_504_" src={xmlid_504_} />
        </div>
        <img className="xmlid_507_" src={xmlid_507_} />
        <img className="xmlid_508_" src="/img/xmlid-508--1@1x.png" />
        <img className="xmlid_509_" src={xmlid_509_} />
        <img className="xmlid_510_" src={xmlid_510_} />
        <img className="xmlid_511_" src={xmlid_511_} />
      </div>
    </div>
  );
}

export default XMLID1454;
