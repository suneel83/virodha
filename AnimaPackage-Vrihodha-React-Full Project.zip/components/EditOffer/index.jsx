import React from "react";
import "./EditOffer.css";

function EditOffer(props) {
  const {
    editAnOffer,
    productCategory,
    mainProductName,
    subProductName,
    mrp,
    unit,
    description,
    fruits,
    polygon1,
    grapes,
    polygon2,
    sonaGrapes,
    polygon4,
    text26,
    kg,
    offerPrice,
    qty,
    text27,
    text28,
    close,
    add,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="edit-offer screen">
        <div className="overlap-group-66">
          <div className="edit-an-offer poppins-semi-bold-cape-cod-21px">{editAnOffer}</div>
          <div className="flex-row-47">
            <div className="flex-col-37 poppins-medium-cape-cod-13px">
              <div className="product-category-3">{productCategory}</div>
              <div className="main-product-name-1">{mainProductName}</div>
              <div className="sub-product-name-2">{subProductName}</div>
              <div className="mrp-6">{mrp}</div>
              <div className="unit-3">{unit}</div>
              <div className="description-7">{description}</div>
            </div>
            <div className="flex-col-38">
              <div className="overlap-group-container-18">
                <div className="overlap-group3-25">
                  <div className="fruits-13">{fruits}</div>
                  <img className="polygon-1-3" src={polygon1} />
                </div>
                <div className="overlap-group5-16">
                  <div className="grapes-3">{grapes}</div>
                  <img className="polygon-2-1" src={polygon2} />
                </div>
                <div className="overlap-group4-21">
                  <div className="sona-grapes-2 poppins-medium-sonic-silver-11px">{sonaGrapes}</div>
                  <img className="polygon-4-1" src={polygon4} />
                </div>
              </div>
              <div className="flex-row-48">
                <div className="overlap-group-container-19">
                  <div className="overlap-group2-24">
                    <div className="text-26 poppins-medium-sonic-silver-11px">{text26}</div>
                  </div>
                  <div className="overlap-group8-10">
                    <div className="kg poppins-medium-sonic-silver-11px">{kg}</div>
                  </div>
                </div>
                <div className="flex-col-39 poppins-medium-cape-cod-13px">
                  <div className="offer-price-2">{offerPrice}</div>
                  <div className="qty-7">{qty}</div>
                </div>
                <div className="overlap-group-container-20">
                  <div className="overlap-group6-15">
                    <div className="text-27 poppins-medium-sonic-silver-11px">{text27}</div>
                  </div>
                  <div className="overlap-group9-10">
                    <div className="text-28 poppins-medium-sonic-silver-11px">{text28}</div>
                  </div>
                </div>
              </div>
              <div className="rectangle-2110-4"></div>
              <div className="overlap-group-container-21">
                <div className="overlap-group7-10">
                  <div className="close-8 poppins-medium-cape-cod-15px">{close}</div>
                </div>
                <div className="overlap-group10-4">
                  <div className="add-4 poppins-medium-romance-15px">{add}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EditOffer;
