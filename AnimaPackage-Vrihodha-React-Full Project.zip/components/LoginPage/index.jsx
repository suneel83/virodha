import React from "react";
import { Link } from "react-router-dom";
import "./LoginPage.css";

function LoginPage(props) {
  const {
    group36,
    untitledDesign,
    userName,
    password,
    spanText1,
    spanText2,
    spanText3,
    spanText4,
    spanText5,
    spanText6,
    submit,
    line2,
    line3,
    vrdella6,
    text1,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="login-page screen">
        <div className="overlap-group-36">
          <img className="group-36" src={group36} />
          <div className="rectangle-2088"></div>
          <img className="untitled-design-2" src={untitledDesign} />
          <div className="user-name-1 poppins-medium-camouflage-green-25px">{userName}</div>
          <div className="password poppins-medium-camouflage-green-25px">{password}</div>
          <div className="new-user-signup-here">
            <span className="poppins-medium-camouflage-green-16px">{spanText1}</span>
            <span className="span1-1">{spanText2}</span>
            <span className="span2">{spanText3}</span>
            <span className="poppins-medium-camouflage-green-16px">{spanText4}</span>
          </div>
          <div className="forgot-password-click-here">
            <span className="poppins-medium-camouflage-green-16px">{spanText5}</span>
            <span>{spanText6}</span>
          </div>
          <Link to="/dashboard-pending-orders">
            <div className="group-34">
              <div className="submit poppins-medium-white-21px">{submit}</div>
            </div>
          </Link>
          <img className="line-2" src={line2} />
          <img className="line-3" src={line3} />
          <div className="vrdella6">{vrdella6}</div>
          <div className="text-1 poppins-medium-camouflage-green-21px">{text1}</div>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
