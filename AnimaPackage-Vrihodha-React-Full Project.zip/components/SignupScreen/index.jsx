import React from "react";
import Group34 from "../Group34";
import "./SignupScreen.css";

function SignupScreen(props) {
  const { overlapGroup, firstName, lastName, email, password, line3, line4, line5, line6, untitledDesign } = props;

  return (
    <div className="container-center-horizontal">
      <div className="signup-screen screen">
        <div
          className="overlap-group-73 poppins-medium-camouflage-green-21px"
          style={{ backgroundImage: `url(${overlapGroup})` }}
        >
          <div className="rectangle-2093 border-1px-dove-gray"></div>
          <div className="first-name">{firstName}</div>
          <div className="last-name">{lastName}</div>
          <div className="email-2">{email}</div>
          <div className="password-1">{password}</div>
          <img className="line-3-1" src={line3} />
          <img className="line-4" src={line4} />
          <img className="line-5" src={line5} />
          <img className="line-6" src={line6} />
          <img className="untitled-design-16" src={untitledDesign} />
          <Group34 />
        </div>
      </div>
    </div>
  );
}

export default SignupScreen;
