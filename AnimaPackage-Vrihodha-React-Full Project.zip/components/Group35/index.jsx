import React from "react";
import "./Group35.css";

function Group35() {
  return (
    <div className="group-35-3">
      <div className="user-management-2 poppins-medium-don-juan-17px">User Management</div>
    </div>
  );
}

export default Group35;
