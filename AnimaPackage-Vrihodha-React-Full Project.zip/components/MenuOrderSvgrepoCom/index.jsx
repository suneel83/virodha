import React from "react";
import "./MenuOrderSvgrepoCom.css";

function MenuOrderSvgrepoCom(props) {
  const { className } = props;

  return (
    <div className={`menu-order-svgrepo-com-1 ${className || ""}`}>
      <div className="group-container-3">
        <div className="group-7"></div>
        <div className="group-9"></div>
      </div>
      <div className="group-container-4">
        <div className="group-3-1"></div>
        <div className="group"></div>
        <div className="group variant-1"></div>
        <div className="group variant-2"></div>
        <div className="group variant-3"></div>
      </div>
    </div>
  );
}

export default MenuOrderSvgrepoCom;
