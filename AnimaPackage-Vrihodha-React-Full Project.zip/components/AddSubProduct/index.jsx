import React from "react";
import "./AddSubProduct.css";

function AddSubProduct(props) {
  const {
    addSubProduct,
    productCategory,
    mainProductName,
    subProductName,
    mrp,
    unit,
    description,
    selectProductCategory,
    polygon1,
    selectProductName,
    polygon2,
    sellingPrice,
    qty,
    close,
    add,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="add-sub-product-1 screen">
        <div className="overlap-group-71">
          <div className="add-sub-product-2 poppins-semi-bold-cape-cod-21px">{addSubProduct}</div>
          <div className="flex-row-68">
            <div className="flex-col-53 poppins-medium-cape-cod-13px">
              <div className="product-category-5">{productCategory}</div>
              <div className="main-product-name-2">{mainProductName}</div>
              <div className="sub-product-name-4">{subProductName}</div>
              <div className="mrp-9">{mrp}</div>
              <div className="unit-4">{unit}</div>
              <div className="description-10">{description}</div>
            </div>
            <div className="flex-col-54">
              <div className="flex-col-55 poppins-medium-westar-11px">
                <div className="overlap-group5-22">
                  <div className="select-product-category-3">{selectProductCategory}</div>
                  <img className="polygon-1-4" src={polygon1} />
                </div>
                <div className="overlap-group3-33">
                  <div className="select-product-name-1">{selectProductName}</div>
                  <img className="polygon-2-2" src={polygon2} />
                </div>
                <div className="rectangle-2109-2"></div>
              </div>
              <div className="flex-row-69">
                <div className="flex-col-56">
                  <div className="rectangle-21-5"></div>
                  <div className="rectangle-2179-3"></div>
                </div>
                <div className="flex-col-57 poppins-medium-cape-cod-13px">
                  <div className="selling-price-6">{sellingPrice}</div>
                  <div className="qty-10">{qty}</div>
                </div>
                <div className="flex-col-58">
                  <div className="rectangle-21-5"></div>
                  <div className="rectangle-2181-2"></div>
                </div>
              </div>
              <div className="rectangle-2110-5"></div>
              <div className="overlap-group-container-26">
                <div className="overlap-group4-29">
                  <div className="close-11 poppins-medium-cape-cod-15px">{close}</div>
                </div>
                <div className="overlap-group2-32">
                  <div className="add-6 poppins-medium-romance-15px">{add}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AddSubProduct;
