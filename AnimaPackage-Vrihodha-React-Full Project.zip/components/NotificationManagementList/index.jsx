import React from "react";
import { Link } from "react-router-dom";
import Group35 from "../Group35";
import AvatarSvgrepoCom from "../AvatarSvgrepoCom";
import B from "../B";
import "./NotificationManagementList.css";

function NotificationManagementList(props) {
  const {
    x18,
    leaf11,
    dashboard,
    categoryManagement,
    productManagement,
    orderManagement,
    manageNotifications,
    adminPanel,
    x41,
    x42,
    x43,
    leaf12,
    leaf2,
    untitledDesign,
    laptopSvgrepoCom,
    iconUser,
    categoryAltSvgrepoCom,
    sellProductSvgrepoCom,
    menuOrderSvgrepoCom,
    iconNotifications,
    welcome,
    admin,
    path77,
    path78,
    line1,
    rectangle9,
    notificationLists,
    text19,
    title,
    notifType,
    userId,
    search,
    action,
    path74,
    number1,
    number2,
    number3,
    number4,
    number5,
    topSalesOnlyFor,
    hendry,
    markov,
    ramkumar,
    name,
    suresh,
    topSales,
    hotDeals,
    productLaunch,
    seasonalUpdate,
    maintenanceAlert,
    x30FlatDealsForMore,
    newVarietyBrocolli,
    wishingYouHap,
    downtimeAlertDearUser,
    iconTrash1,
    iconTrash2,
    iconTrash3,
    iconTrash4,
    iconTrash5,
    overlapGroup,
    plusSvgrepoCom1,
    composeMessage,
    number6,
    number7,
    number8,
    number9,
    avatarSvgrepoComProps,
    b1Props,
    b2Props,
    b3Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="notification-management-list screen">
        <div className="overlap-group4-9">
          <div className="overlap-group3-12">
            <div className="rectangle-2-10"></div>
            <img className="x18-9" src={x18} />
            <div className="rectangle-1-9"></div>
            <img className="leaf1-18" src={leaf11} />
            <div className="rectangle-3-5"></div>
            <div className="rectangle-5-5"></div>
            <div className="rectangle-6-6"></div>
            <div className="rectangle-7-6"></div>
            <div className="rectangle-8-6"></div>
            <div className="dashboard-6 poppins-medium-don-juan-17px">{dashboard}</div>
            <div className="category-management-5 poppins-medium-don-juan-17px">{categoryManagement}</div>
            <div className="product-management-6 poppins-medium-don-juan-17px">{productManagement}</div>
            <div className="order-management-9 poppins-medium-don-juan-17px">{orderManagement}</div>
            <div className="manage-notifications-9 poppins-medium-white-17px">{manageNotifications}</div>
            <div className="admin-panel-9 poppins-semi-bold-chicago-33px">{adminPanel}</div>
            <img className="x4-28" src={x41} />
            <img className="x4-29" src={x42} />
            <img className="x4-30" src={x43} />
            <img className="leaf1-19" src={leaf12} />
            <img className="leaf2-9" src={leaf2} />
            <img className="untitled-design-10" src={untitledDesign} />
            <img className="laptop-svgrepo-com-6" src={laptopSvgrepoCom} />
            <Group35 />
            <img className="icon-user-7" src={iconUser} />
            <img className="category-alt-svgrepo-com-5" src={categoryAltSvgrepoCom} />
            <img className="sell-product-svgrepo-com-9" src={sellProductSvgrepoCom} />
            <img className="menu-order-svgrepo-com-9" src={menuOrderSvgrepoCom} />
            <img className="icon-notifications-7" src={iconNotifications} />
            <div className="welcome-9 poppins-medium-don-juan-14px">{welcome}</div>
            <div className="admin-9 poppins-medium-don-juan-14px">{admin}</div>
            <div className="path-container-10">
              <img className="path-77-6" src={path77} />
              <img className="path-78-6" src={path78} />
            </div>
            <AvatarSvgrepoCom
              path82={avatarSvgrepoComProps.path82}
              path85={avatarSvgrepoComProps.path85}
              path86={avatarSvgrepoComProps.path86}
              path87={avatarSvgrepoComProps.path87}
              path89={avatarSvgrepoComProps.path89}
            />
          </div>
          <img className="line-1-7" src={line1} />
          <div className="overlap-group2-13">
            <img className="rectangle-9-1" src={rectangle9} />
            <div className="notification-lists poppins-semi-bold-everglade-30px">{notificationLists}</div>
            <div className="rectangle-10-2"></div>
            <div className="text-19 poppins-medium-cape-cod-18px">{text19}</div>
            <div className="title poppins-medium-cape-cod-18px">{title}</div>
            <div className="notiftype poppins-medium-cape-cod-18px">{notifType}</div>
            <div className="user-id poppins-medium-cape-cod-18px">{userId}</div>
            <div className="search-6 poppins-semi-bold-cape-cod-18px">{search}</div>
            <div className="action-3 poppins-medium-cape-cod-18px">{action}</div>
            <div className="rectangle-11-3"></div>
            <div className="rectangle-2101-1"></div>
            <div className="rectangle-2102-1"></div>
            <div className="rectangle-2103-1"></div>
            <div className="rectangle-2104-1"></div>
            <img className="path-74-3" src={path74} />
            <div className="number-116 poppins-normal-cape-cod-18px">{number1}</div>
            <div className="number-117 poppins-normal-cape-cod-18px">{number2}</div>
            <div className="number-118 poppins-normal-cape-cod-18px">{number3}</div>
            <div className="number-119 poppins-normal-cape-cod-18px">{number4}</div>
            <div className="number-120 poppins-normal-cape-cod-18px">{number5}</div>
            <div className="top-sales-only-for poppins-semi-bold-dell-18px">{topSalesOnlyFor}</div>
            <div className="hendry-3 poppins-semi-bold-dell-18px">{hendry}</div>
            <div className="markov-3 poppins-semi-bold-dell-18px">{markov}</div>
            <div className="ramkumar poppins-semi-bold-dell-18px">{ramkumar}</div>
            <div className="name-10 poppins-semi-bold-dell-18px">{name}</div>
            <div className="suresh poppins-semi-bold-dell-18px">{suresh}</div>
            <div className="top-sales poppins-semi-bold-dell-18px">{topSales}</div>
            <div className="hot-deals poppins-semi-bold-dell-18px">{hotDeals}</div>
            <div className="product-launch poppins-semi-bold-dell-18px">{productLaunch}</div>
            <div className="seasonal-update poppins-semi-bold-dell-18px">{seasonalUpdate}</div>
            <div className="maintenance-alert poppins-semi-bold-dell-18px">{maintenanceAlert}</div>
            <div className="x30-flat-deals-for-more poppins-semi-bold-dell-18px">{x30FlatDealsForMore}</div>
            <div className="new-variety-brocolli poppins-semi-bold-dell-18px">{newVarietyBrocolli}</div>
            <div className="wishing-you-hap poppins-semi-bold-dell-18px">{wishingYouHap}</div>
            <div className="downtime-alert-dear-user poppins-semi-bold-dell-18px">{downtimeAlertDearUser}</div>
            <img className="icon-trash-22" src={iconTrash1} />
            <img className="icon-trash-23" src={iconTrash2} />
            <img className="icon-trash-24" src={iconTrash3} />
            <img className="icon-trash-25" src={iconTrash4} />
            <img className="icon-trash-26" src={iconTrash5} />
            <a href="javascript:ShowOverlay('notification-management-compose', 'animate-appear');">
              <div className="group-63">
                <div className="group-39-1">
                  <div className="overlap-group-53" style={{ backgroundImage: `url(${overlapGroup})` }}>
                    <div className="plus-svgrepo-com-1-3" style={{ backgroundImage: `url(${plusSvgrepoCom1})` }}></div>
                    <div className="compose-message poppins-medium-white-17px">{composeMessage}</div>
                  </div>
                </div>
              </div>
            </a>
            <div className="rectangle-2112-5"></div>
            <div className="rectangle-2163-1"></div>
            <div className="rectangle-2164-1"></div>
            <div className="rectangle-2165-1"></div>
            <div className="rectangle-2166-1"></div>
            <div className="number-121 poppins-medium-shady-lady-15px">{number6}</div>
            <div className="number-122 poppins-medium-shady-lady-15px">{number7}</div>
            <div className="number-123 poppins-medium-shady-lady-15px">{number8}</div>
            <div className="number-124 poppins-medium-shady-lady-15px">{number9}</div>
            <B className={b1Props.className} />
            <B className={b2Props.className} />
            <B className={b3Props.className} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default NotificationManagementList;
