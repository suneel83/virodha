import React from "react";
import "./NotificationSvgrepoCom.css";

function NotificationSvgrepoCom(props) {
  const { className } = props;

  return (
    <div className={`notification-svgrepo-com ${className || ""}`}>
      <img className="path-9" src="/img/path-9-1@1x.png" />
      <img className="path-10" src="/img/path-10-1@1x.png" />
    </div>
  );
}

export default NotificationSvgrepoCom;
