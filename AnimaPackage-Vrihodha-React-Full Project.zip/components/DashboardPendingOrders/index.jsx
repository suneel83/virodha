import React from "react";
import { Link } from "react-router-dom";
import XMLID1454 from "../XMLID1454";
import B from "../B";
import "./DashboardPendingOrders.css";

function DashboardPendingOrders(props) {
  const {
    overlapGroup8,
    goOrganicGetHealthy,
    x18,
    line1,
    leaf11,
    welcome,
    admin,
    group50,
    adminPanel,
    x41,
    x42,
    x43,
    leaf12,
    leaf2,
    untitledDesign,
    group56,
    group35,
    iconUser,
    group57,
    sellProductSvgrepoCom,
    orderContainer,
    menuOrderSvgrepoCom,
    orderManagement,
    iconNotifications,
    manageNotifications,
    logOutCircleSvgrepoCom,
    avatarSvgrepoCom1,
    number1,
    avatarSvgrepoCom2,
    spanText1,
    spanText2,
    spanText3,
    overlapGroup6,
    pendingOrders1,
    no,
    orderId,
    userDetails,
    status,
    amount,
    details,
    actions,
    number2,
    car1009311,
    hendry,
    rectangle16,
    pending1,
    rs28700,
    group55,
    textEdit1,
    iconTrash1,
    number3,
    car1004341,
    name1,
    rectangle2207,
    pending2,
    rs54300,
    view1,
    textEdit2,
    iconTrash2,
    number4,
    car1003156,
    markov,
    rectangle2208,
    pending3,
    rs85400,
    overlapGroup4,
    view2,
    textEdit3,
    iconTrash3,
    number5,
    car1006126,
    name2,
    rectangle2209,
    pending4,
    rs87400,
    view3,
    textEdit4,
    iconTrash4,
    number6,
    car2002125,
    name3,
    rectangle2210,
    pending5,
    rs90400,
    view4,
    textEdit5,
    iconTrash5,
    number7,
    number8,
    number9,
    number10,
    hiAdminCheckYourVrihodhaStatus,
    x2,
    outForDelivery,
    number11,
    overlapGroup1,
    cancelledOrders,
    number12,
    x5,
    totalAppUsers,
    number13,
    overlapGroup3,
    pendingOrders2,
    number14,
    xMLID1454Props,
    b1Props,
    b2Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="dashboard-pending-orders screen">
        <div className="overlap-group22">
          <div className="overlap-group8" style={{ backgroundImage: `url(${overlapGroup8})` }}>
            <div className="go-organic-get-healthy poppins-semi-bold-white-61px">{goOrganicGetHealthy}</div>
          </div>
          <div className="overlap-group7">
            <div className="rectangle-2"></div>
            <img className="x18" src={x18} />
            <img className="line-1" src={line1} />
            <div className="rectangle-1"></div>
            <img className="leaf1" src={leaf11} />
            <div className="welcome poppins-medium-don-juan-14px">{welcome}</div>
            <div className="admin poppins-medium-don-juan-14px">{admin}</div>
            <Link to="/sub-category-list">
              <img className="group-50" src={group50} />
            </Link>
            <div className="admin-panel poppins-semi-bold-chicago-33px">{adminPanel}</div>
            <img className="x4" src={x41} />
            <img className="x4-1" src={x42} />
            <img className="x4-2" src={x43} />
            <img className="leaf1-1" src={leaf12} />
            <img className="leaf2" src={leaf2} />
            <img className="untitled-design" src={untitledDesign} />
            <img className="group-56" src={group56} />
            <Link to="/user-management-user-data">
              <img className="group-35" src={group35} />
            </Link>
            <img className="icon-user" src={iconUser} />
            <Link to="/category-list">
              <div className="group-42">
                <Link to="/category-list">
                  <div className="group-40">
                    <img className="group-57" src={group57} />
                  </div>
                </Link>
              </div>
            </Link>
            <img className="sell-product-svgrepo-com" src={sellProductSvgrepoCom} />
            <Link to="/all-orders">
              <div className="group-44">
                <div className="order-container" style={{ backgroundImage: `url(${orderContainer})` }}>
                  <img className="menu-order-svgrepo-com" src={menuOrderSvgrepoCom} />
                  <div className="order-management poppins-medium-don-juan-17px">{orderManagement}</div>
                </div>
              </div>
            </Link>
            <Link to="/notification-management-list">
              <div className="group-41">
                <img className="icon-notifications" src={iconNotifications} />
                <div className="manage-notifications poppins-medium-don-juan-17px">{manageNotifications}</div>
              </div>
            </Link>
            <img className="log-out-circle-svgrepo-com" src={logOutCircleSvgrepoCom} />
            <img className="avatar-svgrepo-com" src={avatarSvgrepoCom1} />
            <XMLID1454
              xmlid_504_={xMLID1454Props.xmlid_504_}
              xmlid_507_={xMLID1454Props.xmlid_507_}
              xmlid_509_={xMLID1454Props.xmlid_509_}
              xmlid_510_={xMLID1454Props.xmlid_510_}
              xmlid_511_={xMLID1454Props.xmlid_511_}
            />
            <div className="ellipse-45 border-1px-swirl"></div>
            <div className="number-2 poppins-bold-black-14px">{number1}</div>
            <div className="rectangle-2212"></div>
            <img className="avatar-svgrepo-com-1" src={avatarSvgrepoCom2} />
            <p className="hi-admin-you-have-5">
              <span className="poppins-medium-don-juan-14px">{spanText1}</span>
              <span className="span1">{spanText2}</span>
              <span className="poppins-medium-don-juan-14px">{spanText3}</span>
            </p>
          </div>
          <div className="overlap-group6" style={{ backgroundImage: `url(${overlapGroup6})` }}>
            <div className="pending-orders poppins-semi-bold-everglade-30px">{pendingOrders1}</div>
            <div className="overlap-group14 poppins-medium-cape-cod-18px">
              <div className="no">{no}</div>
              <div className="order-id">{orderId}</div>
              <B />
              <div className="user-details">{userDetails}</div>
              <B className={b1Props.className} />
              <div className="status">{status}</div>
              <div className="amount">{amount}</div>
              <B className={b2Props.className} />
              <div className="details">{details}</div>
              <div className="actions">{actions}</div>
            </div>
            <div className="overlap-group17">
              <div className="number-3 poppins-normal-cape-cod-15px">{number2}</div>
              <div className="car-1-0093-11 poppins-normal-cape-cod-15px">{car1009311}</div>
              <div className="hendry poppins-normal-cape-cod-15px">{hendry}</div>
              <div className="overlap-group">
                <img className="rectangle" src={rectangle16} />
                <div className="pending poppins-normal-white-14px">{pending1}</div>
              </div>
              <div className="rs28700 poppins-semi-bold-dell-15px">{rs28700}</div>
              <img className="group-55" src={group55} />
              <a href="javascript:ShowOverlay('pending-orders-action', 'animate-appear');">
                <img className="text-edit-1" src={textEdit1} />
              </a>
              <img className="icon-trash-1" src={iconTrash1} />
            </div>
            <div className="overlap-group9">
              <div className="number poppins-normal-cape-cod-15px">{number3}</div>
              <div className="car-1-0043-41 poppins-normal-cape-cod-15px">{car1004341}</div>
              <div className="name poppins-normal-cape-cod-15px">{name1}</div>
              <div className="overlap-group1-1">
                <img className="rectangle" src={rectangle2207} />
                <div className="pending poppins-normal-white-14px">{pending2}</div>
              </div>
              <div className="rs54300 poppins-semi-bold-dell-15px">{rs54300}</div>
              <div className="overlap-group2">
                <div className="view poppins-normal-white-14px">{view1}</div>
              </div>
              <img className="text-edit-2" src={textEdit2} />
              <img className="icon-trash-2" src={iconTrash2} />
            </div>
            <div className="overlap-group10">
              <div className="number poppins-normal-cape-cod-15px">{number4}</div>
              <div className="car-1-0031-56 poppins-normal-cape-cod-15px">{car1003156}</div>
              <div className="markov poppins-normal-cape-cod-15px">{markov}</div>
              <div className="overlap-group3">
                <img className="rectangle" src={rectangle2208} />
                <div className="pending poppins-normal-white-14px">{pending3}</div>
              </div>
              <div className="rs85400 poppins-semi-bold-dell-15px">{rs85400}</div>
              <div className="overlap-group4" style={{ backgroundImage: `url(${overlapGroup4})` }}>
                <div className="view poppins-normal-white-14px">{view2}</div>
              </div>
              <img className="text-edit-3" src={textEdit3} />
              <img className="icon-trash-3" src={iconTrash3} />
            </div>
            <div className="overlap-group11">
              <div className="number-4 poppins-normal-cape-cod-15px">{number5}</div>
              <div className="car-1-0061-26 poppins-normal-cape-cod-15px">{car1006126}</div>
              <div className="name-1 poppins-normal-cape-cod-15px">{name2}</div>
              <div className="overlap-group19">
                <img className="rectangle" src={rectangle2209} />
                <div className="pending poppins-normal-white-14px">{pending4}</div>
              </div>
              <div className="rs87400 poppins-semi-bold-dell-15px">{rs87400}</div>
              <div className="overlap-group5">
                <div className="view poppins-normal-white-14px">{view3}</div>
              </div>
              <img className="text-edit" src={textEdit4} />
              <img className="icon-trash" src={iconTrash4} />
            </div>
            <div className="overlap-group13">
              <div className="number-5 poppins-normal-cape-cod-15px">{number6}</div>
              <div className="car-2-0021-25 poppins-normal-cape-cod-15px">{car2002125}</div>
              <div className="name-2 poppins-normal-cape-cod-15px">{name3}</div>
              <div className="overlap-group20">
                <img className="rectangle" src={rectangle2210} />
                <div className="pending poppins-normal-white-14px">{pending5}</div>
              </div>
              <div className="rs90400 poppins-semi-bold-dell-15px">{rs90400}</div>
              <div className="overlap-group21">
                <div className="view poppins-normal-white-14px">{view4}</div>
              </div>
              <img className="text-edit" src={textEdit5} />
              <img className="icon-trash" src={iconTrash5} />
            </div>
            <div className="overlap-group-container">
              <div className="overlap-group12">
                <div className="number-6 poppins-medium-shady-lady-15px">{number7}</div>
              </div>
              <div className="overlap-group1">
                <div className="number-1 poppins-medium-shady-lady-15px">{number8}</div>
              </div>
              <div className="overlap-group1">
                <div className="number-1 poppins-medium-shady-lady-15px">{number9}</div>
              </div>
              <div className="overlap-group16">
                <div className="number-7 poppins-medium-shady-lady-15px">{number10}</div>
              </div>
            </div>
          </div>
          <div className="hi-admin-check-your-vrihodha-status poppins-semi-bold-eerie-black-33px">
            {hiAdminCheckYourVrihodhaStatus}
          </div>
          <Link to="/dashboard-out-for-delivery">
            <div className="group-60">
              <div className="overlap-group-1 poppins-semi-bold-white-41px">
                <img className="x2" src={x2} />
                <div className="out-for-delivery">{outForDelivery}</div>
                <div className="number-8">{number11}</div>
              </div>
            </div>
          </Link>
          <Link to="/dashboard-cancelled-orders">
            <div className="group-61">
              <div
                className="overlap-group1-2 poppins-semi-bold-white-41px"
                style={{ backgroundImage: `url(${overlapGroup1})` }}
              >
                <div className="cancelled-orders">{cancelledOrders}</div>
                <div className="number-9">{number12}</div>
              </div>
            </div>
          </Link>
          <Link to="/user-management-user-data">
            <div className="group-59">
              <div className="overlap-group2-1 poppins-semi-bold-white-41px">
                <Link to="/user-management-user-data">
                  <img className="x5" src={x5} />
                </Link>
                <div className="total-app-users">{totalAppUsers}</div>
                <div className="number-10">{number13}</div>
              </div>
            </div>
          </Link>
          <div
            className="overlap-group3-1 poppins-semi-bold-white-41px"
            style={{ backgroundImage: `url(${overlapGroup3})` }}
          >
            <div className="pending-orders-1">{pendingOrders2}</div>
            <div className="number-11">{number14}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default DashboardPendingOrders;
