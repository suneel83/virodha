import React from "react";
import "./RatingSvgrepoCom.css";

function RatingSvgrepoCom(props) {
  const { iconStar2, iconStar4, className } = props;

  return (
    <div className={`rating-svgrepo-com-1 ${className || ""}`}>
      <div className="group-1-2">
        <img className="icon-star" src="/img/path-2-1@1x.png" />
        <img className="icon-star-1" src={iconStar2} />
        <img className="icon-star-1" src="/img/path-4-1-1x-png@1x.png" />
        <img className="icon-star-1" src={iconStar4} />
      </div>
      <img className="icon-star-2" src="/img/path-6-1@1x.png" />
    </div>
  );
}

export default RatingSvgrepoCom;
