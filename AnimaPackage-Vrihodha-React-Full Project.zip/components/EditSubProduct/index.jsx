import React from "react";
import "./EditSubProduct.css";

function EditSubProduct(props) {
  const {
    editSubProduct,
    productCategory,
    mainProductName,
    subProductName,
    mrp,
    unit,
    description,
    fruits,
    place,
    poovan,
    sellingPrice,
    qty,
    close,
    update,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="edit-sub-product screen">
        <div className="overlap-group-72">
          <div className="edit-sub-product-1 poppins-semi-bold-cape-cod-21px">{editSubProduct}</div>
          <div className="flex-row-70">
            <div className="flex-col-59 poppins-medium-cape-cod-13px">
              <div className="product-category-6">{productCategory}</div>
              <div className="main-product-name-3">{mainProductName}</div>
              <div className="sub-product-name-5">{subProductName}</div>
              <div className="mrp-10">{mrp}</div>
              <div className="unit-5">{unit}</div>
              <div className="description-11">{description}</div>
            </div>
            <div className="flex-col-60">
              <div className="flex-col-61">
                <div className="overlap-group6-21">
                  <div className="fruits-21 poppins-medium-star-dust-14px">{fruits}</div>
                </div>
                <div className="overlap-group5-23">
                  <div className="place-5 poppins-medium-star-dust-14px">{place}</div>
                </div>
                <div className="overlap-group4-30">
                  <div className="poovan-3">{poovan}</div>
                </div>
                <div className="flex-row-71">
                  <div className="rectangle-2178-1"></div>
                  <div className="overlap-group7-16">
                    <div className="selling-price-7 poppins-medium-cape-cod-13px">{sellingPrice}</div>
                    <div className="rectangle-2189-1"></div>
                  </div>
                </div>
              </div>
              <div className="flex-row-72">
                <div className="rectangle-2179-4"></div>
                <div className="qty-11 poppins-medium-cape-cod-13px">{qty}</div>
                <div className="rectangle-2184-1"></div>
              </div>
              <div className="rectangle-2110-6"></div>
              <div className="overlap-group-container-27">
                <div className="overlap-group2-33">
                  <div className="close-12 poppins-medium-cape-cod-15px">{close}</div>
                </div>
                <div className="overlap-group3-34">
                  <div className="update-5 poppins-medium-romance-15px">{update}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EditSubProduct;
