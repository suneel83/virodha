import React from "react";
import { Link } from "react-router-dom";
import Group35 from "../Group35";
import MenuOrderSvgrepoCom from "../MenuOrderSvgrepoCom";
import AvatarSvgrepoCom from "../AvatarSvgrepoCom";
import B from "../B";
import "./AllOrders.css";

function AllOrders(props) {
  const {
    leaf11,
    x18,
    leaf12,
    dashboard,
    categoryManagement,
    productManagement,
    manageNotifications,
    adminPanel,
    x41,
    x42,
    x43,
    leaf2,
    untitledDesign,
    laptopSvgrepoCom,
    iconUser,
    categoryAltSvgrepoCom,
    sellProductSvgrepoCom,
    iconNotifications,
    orderManagement,
    allOrders1,
    userBasedOrders,
    enterArrowSvgrepoCom1,
    enterArrowSvgrepoCom2,
    welcome,
    admin,
    path77,
    path78,
    line1,
    overlapGroup2,
    allOrders2,
    checkAllYourStatusInTheSearchBar,
    search,
    searchSvgrepoCom3,
    print,
    text4,
    orderId,
    cartPrice,
    userName,
    orderDate,
    deliveryDate,
    status,
    details,
    number1,
    bghl811A,
    text5,
    hendry,
    date1,
    pending1,
    view1,
    number2,
    nwdd25F9,
    text6,
    name1,
    date2,
    pending2,
    view2,
    number3,
    mjml7337,
    text7,
    markov,
    date3,
    pending3,
    view3,
    number4,
    bdyl774B,
    text8,
    name2,
    date4,
    pending4,
    view4,
    number5,
    gzye47A8,
    text9,
    name3,
    date5,
    pending5,
    view5,
    number6,
    kkjfi9981,
    text10,
    suman676,
    date6,
    date7,
    cancelled1,
    view6,
    number7,
    dftyui5461,
    text11,
    vivekChand,
    date8,
    date9,
    delivered1,
    view7,
    number8,
    dftyui5462,
    text12,
    samar,
    date10,
    date11,
    delivered2,
    view8,
    number9,
    hjfhu987,
    text13,
    gurushid,
    date12,
    date13,
    cancelled2,
    view9,
    number10,
    uyru898,
    text14,
    sekarGuna,
    date14,
    date15,
    delivered3,
    view10,
    number11,
    dftyui5463,
    text15,
    sundar,
    date16,
    date17,
    delivered4,
    view11,
    number12,
    dftyui5464,
    text16,
    rajesh,
    date18,
    date19,
    cancelled3,
    view12,
    number13,
    dftyui5465,
    text17,
    sathish,
    date20,
    date21,
    delivered5,
    view13,
    number14,
    number15,
    number16,
    number17,
    number18,
    number19,
    menuOrderSvgrepoComProps,
    avatarSvgrepoComProps,
    b1Props,
    b2Props,
    b3Props,
    b4Props,
    b5Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="all-orders-1 screen">
        <div className="overlap-group49">
          <div className="overlap-group3-10">
            <div className="rectangle-2-8"></div>
            <img className="leaf1-14" src={leaf11} />
            <img className="x18-7" src={x18} />
            <div className="rectangle-1-7"></div>
            <img className="leaf1-15" src={leaf12} />
            <Link to="/dashboard-pending-orders">
              <div className="rectangle-3-3"></div>
            </Link>
            <div className="rectangle-5-3"></div>
            <div className="rectangle-6-4"></div>
            <div className="rectangle-8-4"></div>
            <div className="dashboard-4 poppins-medium-don-juan-17px">{dashboard}</div>
            <div className="category-management-3 poppins-medium-don-juan-17px">{categoryManagement}</div>
            <div className="product-management-4 poppins-medium-don-juan-17px">{productManagement}</div>
            <div className="manage-notifications-7 poppins-medium-don-juan-17px">{manageNotifications}</div>
            <div className="admin-panel-7 poppins-semi-bold-chicago-33px">{adminPanel}</div>
            <img className="x4-21" src={x41} />
            <img className="x4-22" src={x42} />
            <img className="x4-23" src={x43} />
            <img className="leaf2-7" src={leaf2} />
            <img className="untitled-design-8" src={untitledDesign} />
            <img className="laptop-svgrepo-com-4" src={laptopSvgrepoCom} />
            <Group35 />
            <img className="icon-user-5" src={iconUser} />
            <img className="category-alt-svgrepo-com-3" src={categoryAltSvgrepoCom} />
            <img className="sell-product-svgrepo-com-7" src={sellProductSvgrepoCom} />
            <img className="icon-notifications-5" src={iconNotifications} />
            <div className="rectangle-7-4"></div>
            <div className="order-management-7 poppins-medium-white-17px">{orderManagement}</div>
            <MenuOrderSvgrepoCom className={menuOrderSvgrepoComProps.className} />
            <div className="all-orders-2 poppins-medium-lemon-glacier-14px">{allOrders1}</div>
            <Link to="/user-based-order-lists">
              <div className="user-based-orders-1 poppins-medium-lemon-glacier-14px">{userBasedOrders}</div>
            </Link>
            <img className="enter-arrow-svgrepo-com-6" src={enterArrowSvgrepoCom1} />
            <img className="enter-arrow-svgrepo-com-7" src={enterArrowSvgrepoCom2} />
            <div className="welcome-7 poppins-medium-don-juan-14px">{welcome}</div>
            <div className="admin-7 poppins-medium-don-juan-14px">{admin}</div>
            <div className="path-container-8">
              <img className="path-77-4" src={path77} />
              <img className="path-78-4" src={path78} />
            </div>
            <AvatarSvgrepoCom
              path82={avatarSvgrepoComProps.path82}
              path85={avatarSvgrepoComProps.path85}
              path86={avatarSvgrepoComProps.path86}
              path87={avatarSvgrepoComProps.path87}
              path89={avatarSvgrepoComProps.path89}
            />
          </div>
          <img className="line-1-5" src={line1} />
          <div className="overlap-group2-11" style={{ backgroundImage: `url(${overlapGroup2})` }}>
            <div className="flex-row-4">
              <div className="all-container">
                <div className="all-orders-3 poppins-semi-bold-everglade-30px">{allOrders2}</div>
                <div className="check-all-your-status-in-the-search-bar poppins-normal-cape-cod-18px">
                  {checkAllYourStatusInTheSearchBar}
                </div>
              </div>
              <div className="search-4 poppins-semi-bold-cape-cod-18px">{search}</div>
              <div className="overlap-group17-2">
                <div className="search-svgrepo-com-3" style={{ backgroundImage: `url(${searchSvgrepoCom3})` }}></div>
              </div>
              <div className="overlap-group23">
                <div className="print">{print}</div>
              </div>
            </div>
            <div className="overlap-group8-6 poppins-medium-cape-cod-18px">
              <div className="text-4">{text4}</div>
              <div className="order-id-2">{orderId}</div>
              <B className={b1Props.className} />
              <div className="cart-price">{cartPrice}</div>
              <B className={b2Props.className} />
              <div className="user-name-2">{userName}</div>
              <B className={b3Props.className} />
              <div className="order-date">{orderDate}</div>
              <B className={b4Props.className} />
              <div className="delivery-date">{deliveryDate}</div>
              <B className={b5Props.className} />
              <div className="status-2">{status}</div>
              <div className="details-3">{details}</div>
            </div>
            <div className="overlap-group9-5 poppins-normal-cape-cod-18px">
              <div className="number-96">{number1}</div>
              <div className="bghl811a">{bghl811A}</div>
              <div className="text-5">{text5}</div>
              <div className="hendry-2">{hendry}</div>
              <div className="date-12">{date1}</div>
              <div className="overlap-group-52">
                <div className="rectangle-2-7"></div>
                <div className="pending-1 poppins-normal-white-15px">{pending1}</div>
              </div>
              <a href="javascript:ShowOverlay('all-orders-view', 'animate-appear');" className="align-self-flex-start">
                <div className="group-43">
                  <div className="view-10 poppins-normal-white-15px">{view1}</div>
                </div>
              </a>
            </div>
            <div className="overlap-group4-7 poppins-normal-cape-cod-18px">
              <div className="number-97">{number2}</div>
              <div className="nwdd25f9">{nwdd25F9}</div>
              <div className="text-6">{text6}</div>
              <div className="name-7">{name1}</div>
              <div className="date-13">{date2}</div>
              <div className="overlap-group26">
                <div className="rectangle-2-7"></div>
                <div className="pending-1 poppins-normal-white-15px">{pending2}</div>
              </div>
              <div className="overlap-group1-23">
                <div className="view-10 poppins-normal-white-15px">{view2}</div>
              </div>
            </div>
            <div className="overlap-group-44 poppins-normal-cape-cod-18px">
              <div className="number-98">{number3}</div>
              <div className="mjml7337">{mjml7337}</div>
              <div className="text-7">{text7}</div>
              <div className="markov-2">{markov}</div>
              <div className="date-14">{date3}</div>
              <div className="overlap-group27">
                <div className="rectangle-2-7"></div>
                <div className="pending-1 poppins-normal-white-15px">{pending3}</div>
              </div>
              <div className="overlap-group28">
                <div className="view-10 poppins-normal-white-15px">{view3}</div>
              </div>
            </div>
            <div className="overlap-group16-2 poppins-normal-cape-cod-18px">
              <div className="number-93">{number4}</div>
              <div className="bdyl774b">{bdyl774B}</div>
              <div className="text-8">{text8}</div>
              <div className="name-8">{name2}</div>
              <div className="date-15">{date4}</div>
              <div className="overlap-group29">
                <div className="rectangle-2-7"></div>
                <div className="pending-1 poppins-normal-white-15px">{pending4}</div>
              </div>
              <div className="overlap-group30">
                <div className="view-10 poppins-normal-white-15px">{view4}</div>
              </div>
            </div>
            <div className="overlap-group-45 poppins-normal-cape-cod-18px">
              <div className="number-93">{number5}</div>
              <div className="gzye47a8">{gzye47A8}</div>
              <div className="text-9">{text9}</div>
              <div className="name-9">{name3}</div>
              <div className="date-16">{date5}</div>
              <div className="overlap-group31">
                <div className="rectangle-2-7"></div>
                <div className="pending-1 poppins-normal-white-15px">{pending5}</div>
              </div>
              <div className="overlap-group32">
                <div className="view-10 poppins-normal-white-15px">{view5}</div>
              </div>
            </div>
            <div className="overlap-group-45 poppins-normal-cape-cod-18px">
              <div className="number-93">{number6}</div>
              <div className="kkjfi9981">{kkjfi9981}</div>
              <div className="text-10">{text10}</div>
              <div className="suman676">{suman676}</div>
              <div className="date-17">{date6}</div>
              <div className="date-18">{date7}</div>
              <div className="overlap-group33">
                <div className="rectangle-2133"></div>
                <div className="cancelled-2 poppins-normal-white-15px">{cancelled1}</div>
              </div>
              <div className="overlap-group34">
                <div className="view-10 poppins-normal-white-15px">{view6}</div>
              </div>
            </div>
            <div className="overlap-group-44 poppins-normal-cape-cod-18px">
              <div className="number-99">{number7}</div>
              <div className="dftyui546-1">{dftyui5461}</div>
              <div className="text-1-1">{text11}</div>
              <div className="vivek-chand">{vivekChand}</div>
              <div className="date-19">{date8}</div>
              <div className="date-10">{date9}</div>
              <div className="overlap-group-46">
                <div className="rectangle-21-2"></div>
                <div className="delivered-1 poppins-normal-white-15px">{delivered1}</div>
              </div>
              <div className="overlap-group-47">
                <div className="view-10 poppins-normal-white-15px">{view7}</div>
              </div>
            </div>
            <div className="overlap-group1-22 poppins-normal-cape-cod-18px">
              <div className="number-93">{number8}</div>
              <div className="dftyui546-2">{dftyui5462}</div>
              <div className="text-1-1">{text12}</div>
              <div className="samar">{samar}</div>
              <div className="date-20">{date10}</div>
              <div className="date-10">{date11}</div>
              <div className="overlap-group-46">
                <div className="rectangle-21-2"></div>
                <div className="delivered-1 poppins-normal-white-15px">{delivered2}</div>
              </div>
              <div className="overlap-group-47">
                <div className="view-10 poppins-normal-white-15px">{view8}</div>
              </div>
            </div>
            <div className="overlap-group-48 poppins-normal-cape-cod-18px">
              <div className="number-93">{number9}</div>
              <div className="hjfhu987">{hjfhu987}</div>
              <div className="text-13">{text13}</div>
              <div className="gurushid">{gurushid}</div>
              <div className="date-21">{date12}</div>
              <div className="date-11">{date13}</div>
              <div className="overlap-group-49">
                <div className="rectangle-2141"></div>
                <div className="cancelled-2 poppins-normal-white-15px">{cancelled2}</div>
              </div>
              <div className="overlap-group-47">
                <div className="view-10 poppins-normal-white-15px">{view9}</div>
              </div>
            </div>
            <div className="overlap-group-48 poppins-normal-cape-cod-18px">
              <div className="number-100">{number10}</div>
              <div className="uyru898">{uyru898}</div>
              <div className="text-14">{text14}</div>
              <div className="sekar-guna">{sekarGuna}</div>
              <div className="date-22">{date14}</div>
              <div className="date-11">{date15}</div>
              <div className="overlap-group-49">
                <div className="rectangle-21-2"></div>
                <div className="delivered-1 poppins-normal-white-15px">{delivered3}</div>
              </div>
              <div className="overlap-group-47">
                <div className="view-10 poppins-normal-white-15px">{view10}</div>
              </div>
            </div>
            <div className="overlap-group18-1 poppins-normal-cape-cod-18px">
              <div className="number-101">{number11}</div>
              <div className="dftyui546-3">{dftyui5463}</div>
              <div className="text-1-1">{text15}</div>
              <div className="sundar">{sundar}</div>
              <div className="date-23">{date16}</div>
              <div className="date-11">{date17}</div>
              <div className="overlap-group-49">
                <div className="rectangle-21-2"></div>
                <div className="delivered-1 poppins-normal-white-15px">{delivered4}</div>
              </div>
              <div className="overlap-group-47">
                <div className="view-10 poppins-normal-white-15px">{view11}</div>
              </div>
            </div>
            <div className="overlap-group5-4 poppins-normal-cape-cod-18px">
              <div className="number-102">{number12}</div>
              <div className="dftyui546">{dftyui5464}</div>
              <div className="text-1-1">{text16}</div>
              <div className="rajesh">{rajesh}</div>
              <div className="date-24">{date18}</div>
              <div className="date-25">{date19}</div>
              <div className="overlap-group46-1">
                <div className="rectangle-2150"></div>
                <div className="cancelled-3 poppins-normal-white-15px">{cancelled3}</div>
              </div>
              <div className="overlap-group-47">
                <div className="view-10 poppins-normal-white-15px">{view12}</div>
              </div>
            </div>
            <div className="overlap-group1-22 poppins-normal-cape-cod-18px">
              <div className="number-103">{number13}</div>
              <div className="dftyui546">{dftyui5465}</div>
              <div className="text-1-1">{text17}</div>
              <div className="sathish">{sathish}</div>
              <div className="date-26">{date20}</div>
              <div className="date-27">{date21}</div>
              <div className="overlap-group-46">
                <div className="rectangle-21-2"></div>
                <div className="delivered-1 poppins-normal-white-15px">{delivered5}</div>
              </div>
              <div className="overlap-group-47">
                <div className="view-10 poppins-normal-white-15px">{view13}</div>
              </div>
            </div>
            <div className="overlap-group-container-7">
              <div className="overlap-group25">
                <div className="number-104 poppins-medium-shady-lady-15px">{number14}</div>
              </div>
              <div className="overlap-group-50">
                <div className="number-94 poppins-medium-shady-lady-15px">{number15}</div>
              </div>
              <div className="overlap-group-50">
                <div className="number-94 poppins-medium-shady-lady-15px">{number16}</div>
              </div>
              <div className="overlap-group-51">
                <div className="number-95 poppins-medium-shady-lady-15px">{number17}</div>
              </div>
              <div className="overlap-group-51">
                <div className="number-95 poppins-medium-shady-lady-15px">{number18}</div>
              </div>
              <div className="overlap-group24">
                <div className="number-95 poppins-medium-shady-lady-15px">{number19}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AllOrders;
