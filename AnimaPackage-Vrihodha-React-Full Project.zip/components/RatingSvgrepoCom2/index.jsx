import React from "react";
import "./RatingSvgrepoCom2.css";

function RatingSvgrepoCom2(props) {
  const { iconStar2, iconStar3, iconStar4, className } = props;

  return (
    <div className={`rating-svgrepo-com-8 ${className || ""}`}>
      <div className="group-1-3">
        <img className="icon-star-5" src="/img/path-2-8@1x.png" />
        <img className="icon-star-3" src={iconStar2} />
        <img className="icon-star-3" src={iconStar3} />
        <img className="icon-star-3" src={iconStar4} />
      </div>
      <img className="icon-star-6" src="/img/path-6-8@1x.png" />
    </div>
  );
}

export default RatingSvgrepoCom2;
