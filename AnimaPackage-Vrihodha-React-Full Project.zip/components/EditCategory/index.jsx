import React from "react";
import "./EditCategory.css";

function EditCategory(props) {
  const {
    editCategory,
    untitledDesign19,
    categoryName,
    categoryImage,
    description,
    fruits,
    upload,
    fruitWithDelicious,
    close,
    update,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="edit-category screen">
        <div className="overlap-group-60">
          <div className="overlap-group2-18">
            <div className="edit-category-1 poppins-semi-bold-cape-cod-21px">{editCategory}</div>
            <div className="rectangle-2106 border-0-5px-dove-gray"></div>
            <img className="untitled-design-19-1" src={untitledDesign19} />
          </div>
          <div className="flex-row-32">
            <div className="flex-col-21 poppins-medium-cape-cod-13px">
              <div className="category-name-1">{categoryName}</div>
              <div className="category-image-1">{categoryImage}</div>
              <div className="description-2">{description}</div>
            </div>
            <div className="overlap-group-container-11">
              <div className="overlap-group5-10">
                <div className="fruits-12 poppins-normal-cod-gray-14px">{fruits}</div>
              </div>
              <div className="overlap-group7-8">
                <div className="rectangle-2111-2"></div>
                <div className="upload-2 poppins-normal-white-12px">{upload}</div>
              </div>
              <div className="overlap-group6-10">
                <p className="fruit-with-delicious poppins-normal-cod-gray-14px">{fruitWithDelicious}</p>
              </div>
            </div>
          </div>
          <div className="overlap-group-container-12">
            <div className="overlap-group4-15">
              <div className="close-3 poppins-medium-cape-cod-15px">{close}</div>
            </div>
            <div className="overlap-group3-19">
              <div className="update-2 poppins-medium-romance-15px">{update}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EditCategory;
