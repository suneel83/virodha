import React from "react";
import "./AddMainProduct.css";

function AddMainProduct(props) {
  const {
    flexCol,
    addMainProduct,
    category,
    polygon3,
    productImage,
    upload,
    productName,
    unitKgsLts,
    add,
    close,
    mrp,
    sellingPrice,
    description,
    qty,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="add-main-product screen">
        <div className="flex-col-40" style={{ backgroundImage: `url(${flexCol})` }}>
          <div className="flex-col-41">
            <div className="add-main-product-1 poppins-semi-bold-everglade-30px">{addMainProduct}</div>
            <div className="flex-row-58">
              <div className="category-6 poppins-medium-cape-cod-15px">{category}</div>
              <div className="overlap-group2-29">
                <img className="polygon-3-3" src={polygon3} />
              </div>
              <div className="product-image-3 poppins-medium-cape-cod-15px">{productImage}</div>
              <div className="overlap-group3-30">
                <div className="rectangle-2111-6"></div>
                <div className="upload-6 poppins-normal-white-12px">{upload}</div>
              </div>
            </div>
          </div>
          <div className="flex-row-59">
            <div className="flex-row-60 poppins-medium-cape-cod-15px">
              <div className="flex-col-42">
                <div className="product-name-5">{productName}</div>
                <div className="unit-kgs-lts-2">{unitKgsLts}</div>
              </div>
              <div className="flex-col-43">
                <div className="rectangle-2117-3"></div>
                <div className="rectangle-2173-1"></div>
                <div className="overlap-group-container-24">
                  <div className="overlap-group1-32">
                    <div className="add-5 poppins-medium-snow-flurry-15px">{add}</div>
                  </div>
                  <div className="overlap-group4-26">
                    <div className="close-9 poppins-medium-cape-cod-15px">{close}</div>
                  </div>
                </div>
              </div>
              <div className="flex-col-44">
                <div className="mrp-7">{mrp}</div>
                <div className="selling-price-4">{sellingPrice}</div>
                <div className="description-8">{description}</div>
              </div>
            </div>
            <div className="flex-col-45">
              <div className="flex-row-61">
                <div className="flex-col-46">
                  <div className="rectangle-2175-1"></div>
                  <div className="rectangle-2187-2"></div>
                </div>
                <div className="qty-8 poppins-medium-cape-cod-15px">{qty}</div>
                <div className="rectangle-2182-1"></div>
              </div>
              <div className="rectangle-2176-2"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AddMainProduct;
