import React from "react";
import "./Group41.css";

function Group41() {
  return (
    <div className="group-41-1">
      <img className="icon-notifications-1" src="/img/notification-svgrepo-com@1x.png" />
      <div className="manage-notifications-3 poppins-medium-don-juan-17px">Manage Notifications</div>
    </div>
  );
}

export default Group41;
