import React from "react";
import "./Layer2.css";

function Layer2(props) {
  const { className } = props;

  return (
    <div className={`layer-2-1 ${className || ""}`}>
      <div className="radio-button-off">
        <img className="path-98" src="/img/path-98-1@1x.png" />
      </div>
    </div>
  );
}

export default Layer2;
