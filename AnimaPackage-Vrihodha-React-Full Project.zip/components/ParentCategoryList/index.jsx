import React from "react";
import { Link } from "react-router-dom";
import Group35 from "../Group35";
import "./ParentCategoryList.css";

function ParentCategoryList(props) {
  const {
    x18,
    leaf11,
    dashboard,
    welcome,
    administrator,
    categoryManagement,
    productManagement,
    orderManagement,
    manageNotifications,
    adminPanel,
    x41,
    x42,
    x43,
    leaf12,
    leaf2,
    untitledDesign,
    laptopSvgrepoCom,
    usersSilhouettesSvgrepoCom,
    categoryAltSvgrepoCom,
    sellProductSvgrepoCom,
    menuOrderSvgrepoCom,
    notificationSvgrepoCom,
    parentCategories,
    subCategories,
    enterArrowSvgrepoCom1,
    enterArrowSvgrepoCom2,
    line1,
    overlapGroup,
    parentCategoryList,
    search,
    addCategory,
    plusSvgrepoCom1,
    text31,
    productName,
    productImage,
    cartId,
    action,
    number1,
    place,
    x44,
    number2,
    textEdit1,
    binSvgrepoCom1,
    number3,
    number4,
    apple,
    textEdit2,
    binSvgrepoCom2,
    x5,
    path74,
    number5,
    number6,
    number7,
    number8,
    number9,
    number10,
    color,
    grapes,
    spinach,
    textEdit3,
    textEdit4,
    textEdit5,
    binSvgrepoCom3,
    binSvgrepoCom4,
    iconTrash,
    x6,
    x7,
    x8,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="parent-category-list screen">
        <div className="overlap-group7-17">
          <div className="overlap-group1-34">
            <div className="rectangle-2-17"></div>
            <img className="x18-15" src={x18} />
            <div className="rectangle-1-15"></div>
            <img className="leaf1-30" src={leaf11} />
            <div className="rectangle-3-10"></div>
            <div className="rectangle-5-8"></div>
            <div className="rectangle-6-13"></div>
            <div className="rectangle-7-11"></div>
            <div className="rectangle-8-11"></div>
            <div className="dashboard-12 poppins-medium-don-juan-17px">{dashboard}</div>
            <div className="welcome-15 poppins-medium-don-juan-14px">{welcome}</div>
            <div className="administrator-1 poppins-medium-don-juan-16px">{administrator}</div>
            <div className="category-management-8 poppins-medium-white-17px">{categoryManagement}</div>
            <div className="product-management-13 poppins-medium-don-juan-17px">{productManagement}</div>
            <div className="order-management-15 poppins-medium-don-juan-17px">{orderManagement}</div>
            <div className="manage-notifications-15 poppins-medium-don-juan-17px">{manageNotifications}</div>
            <div className="admin-panel-15 poppins-semi-bold-chicago-33px">{adminPanel}</div>
            <img className="x4-49" src={x41} />
            <img className="x4-50" src={x42} />
            <img className="x4-51" src={x43} />
            <img className="leaf1-31" src={leaf12} />
            <img className="leaf2-15" src={leaf2} />
            <img className="untitled-design-18" src={untitledDesign} />
            <img className="laptop-svgrepo-com-11" src={laptopSvgrepoCom} />
            <Group35 />
            <img className="users-silhouettes-svgrepo-com-5" src={usersSilhouettesSvgrepoCom} />
            <img className="category-alt-svgrepo-com-8" src={categoryAltSvgrepoCom} />
            <img className="sell-product-svgrepo-com-17" src={sellProductSvgrepoCom} />
            <img className="menu-order-svgrepo-com-15" src={menuOrderSvgrepoCom} />
            <img className="notification-svgrepo-com-5" src={notificationSvgrepoCom} />
            <div className="parent-categories poppins-medium-lemon-glacier-14px">{parentCategories}</div>
            <Link to="/sub-category-list">
              <div className="sub-categories poppins-medium-lemon-glacier-14px">{subCategories}</div>
            </Link>
            <img className="enter-arrow-svgrepo-com-16" src={enterArrowSvgrepoCom1} />
            <img className="enter-arrow-svgrepo-com-17" src={enterArrowSvgrepoCom2} />
          </div>
          <img className="line-1-13" src={line1} />
          <div className="overlap-group-74" style={{ backgroundImage: `url(${overlapGroup})` }}>
            <div className="flex-row-73">
              <div className="parent-category-list-1 poppins-semi-bold-everglade-30px">{parentCategoryList}</div>
              <div className="search-10 poppins-semi-bold-cape-cod-18px">{search}</div>
              <div className="rectangle-2112-9"></div>
              <div className="overlap-group4-31">
                <a href="javascript:ShowOverlay('add-category', 'animate-appear');">
                  <div className="group-38-3">
                    <div className="add-category-3 poppins-medium-white-18px">{addCategory}</div>
                  </div>
                </a>
                <div className="plus-svgrepo-com-1-9" style={{ backgroundImage: `url(${plusSvgrepoCom1})` }}></div>
              </div>
            </div>
            <div className="overlap-group6-22 poppins-medium-cape-cod-18px">
              <div className="text-31">{text31}</div>
              <div className="product-name-7">{productName}</div>
              <div className="product-image-5">{productImage}</div>
              <div className="cart-id-1">{cartId}</div>
              <div className="action-7">{action}</div>
            </div>
            <div className="overlap-group5-24">
              <div className="number-179 poppins-normal-cape-cod-18px">{number1}</div>
              <div className="place-6 poppins-semi-bold-dell-18px">{place}</div>
              <img className="x4-52" src={x44} />
              <div className="number-180 poppins-semi-bold-dell-18px">{number2}</div>
              <a href="javascript:ShowOverlay('edit-category', 'animate-appear');">
                <img className="text-edit-34" src={textEdit1} />
              </a>
              <img className="bin-svgrepo-com-11" src={binSvgrepoCom1} />
            </div>
            <div className="overlap-group3-35">
              <div className="rectangle-210-2"></div>
              <div className="number-177 poppins-normal-cape-cod-18px">{number3}</div>
              <div className="number-178 poppins-semi-bold-dell-18px">{number4}</div>
              <div className="apple-5 poppins-semi-bold-dell-18px">{apple}</div>
              <img className="text-edit-33" src={textEdit2} />
              <img className="bin-svgrepo-com-10" src={binSvgrepoCom2} />
              <img className="x5-3" src={x5} />
            </div>
            <div className="overlap-group2-34">
              <div className="rectangle-210-2"></div>
              <div className="rectangle-2103-3"></div>
              <div className="rectangle-2104-3"></div>
              <img className="path-74-7" src={path74} />
              <div className="number-177 poppins-normal-cape-cod-18px">{number5}</div>
              <div className="number-181 poppins-normal-cape-cod-18px">{number6}</div>
              <div className="number-182 poppins-normal-cape-cod-18px">{number7}</div>
              <div className="number-178 poppins-semi-bold-dell-18px">{number8}</div>
              <div className="number-183 poppins-semi-bold-dell-18px">{number9}</div>
              <div className="number-184 poppins-semi-bold-dell-18px">{number10}</div>
              <div className="color-5 poppins-semi-bold-dell-18px">{color}</div>
              <div className="grapes-6 poppins-semi-bold-dell-18px">{grapes}</div>
              <div className="spinach-5 poppins-semi-bold-dell-18px">{spinach}</div>
              <img className="text-edit-33" src={textEdit3} />
              <img className="text-edit-35" src={textEdit4} />
              <img className="text-edit-36" src={textEdit5} />
              <img className="bin-svgrepo-com-10" src={binSvgrepoCom3} />
              <img className="bin-svgrepo-com-12" src={binSvgrepoCom4} />
              <img className="icon-trash-28" src={iconTrash} />
              <img className="x6-2" src={x6} />
              <img className="x7-2" src={x7} />
              <img className="x8-2" src={x8} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ParentCategoryList;
