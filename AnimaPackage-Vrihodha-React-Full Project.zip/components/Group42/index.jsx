import React from "react";
import "./Group42.css";

function Group42() {
  return (
    <div className="group-42-1">
      <div className="group-40-1">
        <img className="group-57-1" src="/img/group-57@1x.png" />
      </div>
    </div>
  );
}

export default Group42;
