import React from "react";
import "./UsersDataView.css";

function UsersDataView(props) {
  const {
    userDetails,
    print,
    customerName,
    contactNumber,
    email,
    hendry,
    phone,
    hendryjosephGmailCom,
    a453RdFloorRoh,
    primaryAddress,
    address2,
    address3,
    address4,
    address5,
    x1CSooriyaApartment,
    d163RdFloorDal,
    a1133RdFloorZa,
    no15KuthiraiKatt,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="users-data-view screen">
        <div className="overlap-group-67 border-1px-dove-gray">
          <div className="flex-row-49">
            <div className="user-details-1 poppins-medium-cape-cod-18px-2">{userDetails}</div>
            <div className="overlap-group3-26">
              <div className="print-2 poppins-medium-white-12px">{print}</div>
            </div>
          </div>
          <div className="overlap-group2-25">
            <div className="rectangle-2094"></div>
            <div className="customer-name-3 poppins-medium-black-15px">{customerName}</div>
            <div className="contact-number-3 poppins-medium-black-15px">{contactNumber}</div>
            <div className="email-1 poppins-medium-black-15px">{email}</div>
            <div className="hendry-7 poppins-normal-japanese-laurel-15px">{hendry}</div>
            <div className="phone-9 poppins-normal-japanese-laurel-15px">{phone}</div>
            <div className="hendryjosephgmailcom poppins-normal-japanese-laurel-15px">{hendryjosephGmailCom}</div>
            <div className="rectangle-2192"></div>
            <p className="a45-3rd-floorroh-3 poppins-medium-japanese-laurel-15px">{a453RdFloorRoh}</p>
            <div className="rectangle-2190"></div>
            <div className="primary-address poppins-medium-cape-cod-14px">{primaryAddress}</div>
          </div>
          <div className="flex-row-50">
            <div className="overlap-group-container-22">
              <div className="overlap-group4-22">
                <div className="rectangle-219"></div>
                <div className="address-2-1 poppins-medium-cape-cod-14px">{address2}</div>
              </div>
              <div className="overlap-group9-11">
                <div className="rectangle-219"></div>
                <div className="address-3 poppins-medium-cape-cod-14px">{address3}</div>
              </div>
              <div className="overlap-group8-11">
                <div className="rectangle-219"></div>
                <div className="address-3 poppins-medium-cape-cod-14px">{address4}</div>
              </div>
              <div className="overlap-group7-11">
                <div className="rectangle-219"></div>
                <div className="address-3 poppins-medium-cape-cod-14px">{address5}</div>
              </div>
            </div>
            <div className="overlap-group-container-23">
              <div className="overlap-group5-17 poppins-medium-japanese-laurel-15px">
                <div className="rectangle-2194"></div>
                <div className="rectangle-2196"></div>
                <div className="rectangle-2198"></div>
                <p className="x1-c-sooriya-apartment">{x1CSooriyaApartment}</p>
                <p className="d-16-3rd-floordal">{d163RdFloorDal}</p>
                <p className="a113-3rd-floorza">{a1133RdFloorZa}</p>
              </div>
              <div className="overlap-group6-16">
                <p className="no15-kuthirai-katt poppins-medium-japanese-laurel-15px">{no15KuthiraiKatt}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default UsersDataView;
