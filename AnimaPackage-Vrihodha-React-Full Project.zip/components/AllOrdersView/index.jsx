import React from "react";
import "./AllOrdersView.css";

function AllOrdersView(props) {
  const {
    orderDetails,
    print,
    orderId,
    car1009311,
    address,
    customerName,
    hendry,
    contactNumber,
    phone,
    spanText1,
    spanText2,
    a453RdFloorRoh,
    status,
    rectangle2096,
    pending,
    totalRs287,
    productName,
    qty,
    tax,
    surname,
    totalPrice,
    appleKashmir,
    number1,
    percent1,
    number2,
    text18,
    kamalaOrange,
    number3,
    percent2,
    number4,
    text19,
    spinachAraiKeerai,
    number5,
    percent3,
    number6,
    text20,
    cauliflower,
    number7,
    percent4,
    number8,
    text21,
    beetroot,
    number9,
    percent5,
    number10,
    text22,
    productPriceRs257,
    deliveryChargesRs30,
    netTotalPayableRs287,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="all-orders-view screen">
        <div className="overlap-group-62 border-1px-dove-gray">
          <div className="flex-row-34">
            <div className="order-details-2 poppins-medium-cape-cod-18px-2">{orderDetails}</div>
            <div className="overlap-group1-29">
              <div className="print-1 poppins-medium-white-12px">{print}</div>
            </div>
          </div>
          <div className="overlap-group2-20">
            <div className="flex-col-24">
              <div className="flex-row-35">
                <div className="order-id-5 poppins-medium-black-15px">{orderId}</div>
                <div className="car-1-0093-11-4 poppins-medium-japanese-laurel-13px">{car1009311}</div>
                <div className="address-2 poppins-medium-black-15px">{address}</div>
              </div>
              <div className="flex-row-36">
                <div className="customer-name-2 poppins-medium-black-15px">{customerName}</div>
                <div className="hendry-6 poppins-normal-japanese-laurel-15px">{hendry}</div>
              </div>
              <div className="flex-row-37">
                <div className="contact-number-2 poppins-medium-black-15px">{contactNumber}</div>
                <div className="phone-8 poppins-normal-japanese-laurel-15px">{phone}</div>
              </div>
              <div className="payment-mode-internet-banking">
                <span className="poppins-medium-black-15px">{spanText1}</span>
                <span className="poppins-medium-japanese-laurel-15px">{spanText2}</span>
              </div>
            </div>
            <p className="a45-3rd-floorroh-2 poppins-normal-japanese-laurel-15px">{a453RdFloorRoh}</p>
          </div>
          <div className="flex-row-38">
            <div className="status-4 poppins-medium-black-15px">{status}</div>
            <div className="overlap-group4-17">
              <img className="rectangle-2096-1" src={rectangle2096} />
              <div className="pending-3 poppins-normal-white-14px">{pending}</div>
            </div>
            <div className="total-rs-287 poppins-semi-bold-green-house-32px">{totalRs287}</div>
          </div>
          <div className="overlap-group3-21">
            <div className="flex-row-39 poppins-semi-bold-black-12px">
              <div className="product-name-1">{productName}</div>
              <div className="qty-3">{qty}</div>
              <div className="tax">{tax}</div>
              <div className="surname-2">{surname}</div>
              <div className="total-price">{totalPrice}</div>
            </div>
            <div className="overlap-group9-9 poppins-medium-black-12px">
              <div className="apple-kashmir">{appleKashmir}</div>
              <div className="number-141">{number1}</div>
              <div className="percent">{percent1}</div>
              <div className="number-142">{number2}</div>
              <div className="text-21">{text18}</div>
            </div>
            <div className="overlap-group6-11 poppins-medium-black-12px">
              <div className="kamala-orange">{kamalaOrange}</div>
              <div className="number-143">{number3}</div>
              <div className="percent">{percent2}</div>
              <div className="number-140">{number4}</div>
              <div className="text-22">{text19}</div>
            </div>
            <div className="overlap-group5-12 poppins-medium-black-12px">
              <div className="spinach-arai-keerai">{spinachAraiKeerai}</div>
              <div className="number-144">{number5}</div>
              <div className="percent-1">{percent3}</div>
              <div className="number-145">{number6}</div>
              <div className="text-23">{text20}</div>
            </div>
            <div className="overlap-group8-9 poppins-medium-black-12px">
              <div className="cauliflower">{cauliflower}</div>
              <div className="number-146">{number7}</div>
              <div className="percent">{percent4}</div>
              <div className="number-140">{number8}</div>
              <div className="text-24">{text21}</div>
            </div>
            <div className="overlap-group7-9 poppins-medium-black-12px">
              <div className="beetroot-1">{beetroot}</div>
              <div className="number-147">{number9}</div>
              <div className="percent">{percent5}</div>
              <div className="number-140">{number10}</div>
              <div className="text-25">{text22}</div>
            </div>
            <div className="product-price-rs257 poppins-semi-bold-black-15px">{productPriceRs257}</div>
            <div className="delivery-charges-rs30 poppins-semi-bold-black-15px">{deliveryChargesRs30}</div>
            <div className="overlap-group10-3">
              <p className="net-total-payable-rs287 poppins-semi-bold-black-15px">{netTotalPayableRs287}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AllOrdersView;
