import React from "react";
import { Link } from "react-router-dom";
import Group35 from "../Group35";
import AvatarSvgrepoCom from "../AvatarSvgrepoCom";
import "./SubCategoryList.css";

function SubCategoryList(props) {
  const {
    x18,
    leaf11,
    dashboard,
    categoryManagement,
    productManagement,
    orderManagement,
    manageNotifications,
    adminPanel,
    x41,
    x42,
    x43,
    leaf12,
    leaf2,
    untitledDesign,
    laptopSvgrepoCom,
    iconUser,
    categoryAltSvgrepoCom,
    sellProductSvgrepoCom,
    menuOrderSvgrepoCom,
    iconNotifications,
    subCategoryList1,
    productsList,
    enterArrowSvgrepoCom1,
    enterArrowSvgrepoCom2,
    welcome,
    admin,
    path77,
    path78,
    line1,
    overlapGroup2,
    subCategoryList2,
    search,
    addSubCategory,
    plusSvgrepoCom1,
    text18,
    category,
    subCategory,
    subCatOryImage,
    subCategoryId,
    action,
    number1,
    fruits1,
    place,
    x44,
    number2,
    textEdit1,
    iconTrash1,
    number3,
    number4,
    fruits2,
    apple,
    textEdit2,
    iconTrash2,
    x5,
    path74,
    number5,
    number6,
    number7,
    number8,
    number9,
    number10,
    fruits3,
    fruits4,
    vegitables,
    color,
    grapes,
    spinach,
    textEdit3,
    textEdit4,
    textEdit5,
    iconTrash3,
    iconTrash4,
    iconTrash5,
    x6,
    x7,
    x8,
    number11,
    number12,
    number13,
    number14,
    avatarSvgrepoComProps,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="sub-category-list-1 screen">
        <div className="overlap-group13-3">
          <div className="overlap-group3-11">
            <div className="rectangle-2-9"></div>
            <img className="x18-8" src={x18} />
            <div className="rectangle-1-8"></div>
            <img className="leaf1-16" src={leaf11} />
            <Link to="/dashboard-pending-orders">
              <div className="rectangle-3-4"></div>
            </Link>
            <div className="rectangle-5-4"></div>
            <div className="rectangle-6-5"></div>
            <div className="rectangle-7-5"></div>
            <div className="rectangle-8-5"></div>
            <div className="dashboard-5 poppins-medium-don-juan-17px">{dashboard}</div>
            <div className="category-management-4 poppins-medium-don-juan-17px">{categoryManagement}</div>
            <div className="product-management-5 poppins-medium-white-17px">{productManagement}</div>
            <div className="order-management-8 poppins-medium-don-juan-17px">{orderManagement}</div>
            <div className="manage-notifications-8 poppins-medium-don-juan-17px">{manageNotifications}</div>
            <div className="admin-panel-8 poppins-semi-bold-chicago-33px">{adminPanel}</div>
            <img className="x4-24" src={x41} />
            <img className="x4-25" src={x42} />
            <img className="x4-26" src={x43} />
            <img className="leaf1-17" src={leaf12} />
            <img className="leaf2-8" src={leaf2} />
            <img className="untitled-design-9" src={untitledDesign} />
            <img className="laptop-svgrepo-com-5" src={laptopSvgrepoCom} />
            <Group35 />
            <img className="icon-user-6" src={iconUser} />
            <img className="category-alt-svgrepo-com-4" src={categoryAltSvgrepoCom} />
            <img className="sell-product-svgrepo-com-8" src={sellProductSvgrepoCom} />
            <img className="menu-order-svgrepo-com-8" src={menuOrderSvgrepoCom} />
            <img className="icon-notifications-6" src={iconNotifications} />
            <div className="sub-category-list-2 poppins-medium-lemon-glacier-14px">{subCategoryList1}</div>
            <Link to="/product-list">
              <div className="products-list-2 poppins-medium-lemon-glacier-14px">{productsList}</div>
            </Link>
            <img className="enter-arrow-svgrepo-com-8" src={enterArrowSvgrepoCom1} />
            <img className="enter-arrow-svgrepo-com-9" src={enterArrowSvgrepoCom2} />
            <div className="welcome-8 poppins-medium-don-juan-14px">{welcome}</div>
            <div className="admin-8 poppins-medium-don-juan-14px">{admin}</div>
            <div className="path-container-9">
              <img className="path-77-5" src={path77} />
              <img className="path-78-5" src={path78} />
            </div>
            <AvatarSvgrepoCom
              path82={avatarSvgrepoComProps.path82}
              path85={avatarSvgrepoComProps.path85}
              path86={avatarSvgrepoComProps.path86}
              path87={avatarSvgrepoComProps.path87}
              path89={avatarSvgrepoComProps.path89}
            />
          </div>
          <img className="line-1-6" src={line1} />
          <div className="overlap-group2-12" style={{ backgroundImage: `url(${overlapGroup2})` }}>
            <div className="flex-row-5">
              <div className="sub-category-list-3 poppins-semi-bold-everglade-30px">{subCategoryList2}</div>
              <div className="search-5 poppins-semi-bold-cape-cod-18px">{search}</div>
              <div className="rectangle-2112-4"></div>
              <div className="overlap-group7-5">
                <a href="javascript:ShowOverlay('add-sub-category', 'animate-appear');">
                  <div className="group-38-1">
                    <div className="add-sub-category poppins-medium-white-18px">{addSubCategory}</div>
                  </div>
                </a>
                <div className="plus-svgrepo-com-1-2" style={{ backgroundImage: `url(${plusSvgrepoCom1})` }}></div>
              </div>
            </div>
            <div className="overlap-group5-5 poppins-medium-cape-cod-18px">
              <div className="text-18">{text18}</div>
              <div className="category-2">{category}</div>
              <div className="sub-category-1">{subCategory}</div>
              <div className="sub-catory-image">{subCatOryImage}</div>
              <div className="sub-category-id">{subCategoryId}</div>
              <div className="action-2">{action}</div>
            </div>
            <div className="overlap-group9-6">
              <div className="number-108 poppins-normal-cape-cod-18px">{number1}</div>
              <div className="fruits-6 poppins-semi-bold-dell-18px">{fruits1}</div>
              <div className="place-1 poppins-semi-bold-dell-18px">{place}</div>
              <img className="x4-27" src={x44} />
              <div className="number-109 poppins-semi-bold-dell-18px">{number2}</div>
              <a href="javascript:ShowOverlay('edit-sub-category', 'animate-appear');">
                <img className="text-edit-20" src={textEdit1} />
              </a>
              <img className="icon-trash-19" src={iconTrash1} />
            </div>
            <div className="overlap-group4-8">
              <div className="rectangle-210"></div>
              <div className="number-105 poppins-normal-cape-cod-18px">{number3}</div>
              <div className="number-106 poppins-semi-bold-dell-18px">{number4}</div>
              <div className="fruits-5 poppins-semi-bold-dell-18px">{fruits2}</div>
              <div className="apple-1 poppins-semi-bold-dell-18px">{apple}</div>
              <img className="text-edit-19" src={textEdit2} />
              <img className="icon-trash-18" src={iconTrash2} />
              <img className="x5-1" src={x5} />
            </div>
            <div className="overlap-group6-6">
              <div className="rectangle-210"></div>
              <div className="rectangle-2103"></div>
              <div className="rectangle-2104"></div>
              <img className="path-74-2" src={path74} />
              <div className="number-105 poppins-normal-cape-cod-18px">{number5}</div>
              <div className="number-110 poppins-normal-cape-cod-18px">{number6}</div>
              <div className="number-111 poppins-normal-cape-cod-18px">{number7}</div>
              <div className="number-106 poppins-semi-bold-dell-18px">{number8}</div>
              <div className="number-112 poppins-semi-bold-dell-18px">{number9}</div>
              <div className="number-113 poppins-semi-bold-dell-18px">{number10}</div>
              <div className="fruits-5 poppins-semi-bold-dell-18px">{fruits3}</div>
              <div className="fruits-7 poppins-semi-bold-dell-18px">{fruits4}</div>
              <div className="vegitables-2 poppins-semi-bold-dell-18px">{vegitables}</div>
              <div className="color-1 poppins-semi-bold-dell-18px">{color}</div>
              <div className="grapes-1 poppins-semi-bold-dell-18px">{grapes}</div>
              <div className="spinach-1 poppins-semi-bold-dell-18px">{spinach}</div>
              <img className="text-edit-19" src={textEdit3} />
              <img className="text-edit-21" src={textEdit4} />
              <img className="text-edit-22" src={textEdit5} />
              <img className="icon-trash-18" src={iconTrash3} />
              <img className="icon-trash-20" src={iconTrash4} />
              <img className="icon-trash-21" src={iconTrash5} />
              <img className="x6" src={x6} />
              <img className="x7" src={x7} />
              <img className="x8" src={x8} />
            </div>
            <div className="overlap-group-container-8">
              <div className="overlap-group12-3">
                <div className="number-114 poppins-medium-shady-lady-15px">{number11}</div>
              </div>
              <div className="overlap-group1-24">
                <div className="number-107 poppins-medium-shady-lady-15px">{number12}</div>
              </div>
              <div className="overlap-group1-24">
                <div className="number-107 poppins-medium-shady-lady-15px">{number13}</div>
              </div>
              <div className="overlap-group8-7">
                <div className="number-115 poppins-medium-shady-lady-15px">{number14}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SubCategoryList;
