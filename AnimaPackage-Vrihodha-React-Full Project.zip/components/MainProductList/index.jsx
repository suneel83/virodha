import React from "react";
import { Link } from "react-router-dom";
import Group35 from "../Group35";
import AvatarSvgrepoCom from "../AvatarSvgrepoCom";
import "./MainProductList.css";

function MainProductList(props) {
  const {
    x18,
    leaf11,
    dashboard,
    categoryManagement,
    productManagement,
    orderManagement,
    manageNotifications,
    adminPanel,
    x41,
    x42,
    x43,
    leaf12,
    leaf2,
    untitledDesign,
    laptopSvgrepoCom,
    usersSilhouettesSvgrepoCom,
    categoryAltSvgrepoCom,
    sellProductSvgrepoCom,
    menuOrderSvgrepoCom,
    notificationSvgrepoCom,
    mainProductsList1,
    subProductsList,
    enterArrowSvgrepoCom1,
    enterArrowSvgrepoCom2,
    welcome,
    admin,
    path77,
    path78,
    line1,
    overlapGroup3,
    mainProductsList2,
    search,
    addProduct,
    plusSvgrepoCom1,
    text29,
    category,
    productName,
    productImage,
    cartId,
    action,
    number1,
    fruits1,
    place,
    x44,
    number2,
    textEdit1,
    binSvgrepoCom1,
    number3,
    number4,
    fruits2,
    apple,
    textEdit2,
    binSvgrepoCom2,
    x5,
    path74,
    number5,
    number6,
    number7,
    number8,
    number9,
    number10,
    fruits3,
    fruits4,
    vegitables,
    color,
    grapes,
    spinach,
    textEdit3,
    textEdit4,
    textEdit5,
    binSvgrepoCom3,
    binSvgrepoCom4,
    binSvgrepoCom5,
    x6,
    x7,
    x8,
    avatarSvgrepoComProps,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="main-product-list screen">
        <div className="overlap-group9-13">
          <div className="overlap-group2-27">
            <div className="rectangle-2-14"></div>
            <img className="x18-12" src={x18} />
            <div className="rectangle-1-12"></div>
            <img className="leaf1-24" src={leaf11} />
            <Link to="/dashboard">
              <div className="rectangle-3-7"></div>
            </Link>
            <div className="rectangle-5-6"></div>
            <div className="rectangle-6-9"></div>
            <div className="rectangle-7-8"></div>
            <div className="rectangle-8-8"></div>
            <div className="dashboard-9 poppins-medium-don-juan-17px">{dashboard}</div>
            <div className="category-management-6 poppins-medium-don-juan-17px">{categoryManagement}</div>
            <div className="product-management-9 poppins-medium-white-17px">{productManagement}</div>
            <div className="order-management-12 poppins-medium-don-juan-17px">{orderManagement}</div>
            <div className="manage-notifications-12 poppins-medium-don-juan-17px">{manageNotifications}</div>
            <div className="admin-panel-12 poppins-semi-bold-chicago-33px">{adminPanel}</div>
            <img className="x4-38" src={x41} />
            <img className="x4-39" src={x42} />
            <img className="x4-40" src={x43} />
            <img className="leaf1-25" src={leaf12} />
            <img className="leaf2-12" src={leaf2} />
            <img className="untitled-design-13" src={untitledDesign} />
            <img className="laptop-svgrepo-com-8" src={laptopSvgrepoCom} />
            <Group35 />
            <img className="users-silhouettes-svgrepo-com-3" src={usersSilhouettesSvgrepoCom} />
            <img className="category-alt-svgrepo-com-6" src={categoryAltSvgrepoCom} />
            <img className="sell-product-svgrepo-com-13" src={sellProductSvgrepoCom} />
            <img className="menu-order-svgrepo-com-12" src={menuOrderSvgrepoCom} />
            <img className="notification-svgrepo-com-3" src={notificationSvgrepoCom} />
            <div className="main-products-list poppins-medium-lemon-glacier-14px">{mainProductsList1}</div>
            <Link to="/product-list">
              <div className="sub-products-list poppins-medium-lemon-glacier-14px">{subProductsList}</div>
            </Link>
            <img className="enter-arrow-svgrepo-com-12" src={enterArrowSvgrepoCom1} />
            <img className="enter-arrow-svgrepo-com-13" src={enterArrowSvgrepoCom2} />
            <div className="welcome-12 poppins-medium-don-juan-14px">{welcome}</div>
            <div className="admin-12 poppins-medium-don-juan-14px">{admin}</div>
            <div className="path-container-12">
              <img className="path-77-8" src={path77} />
              <img className="path-78-8" src={path78} />
            </div>
            <AvatarSvgrepoCom
              path82={avatarSvgrepoComProps.path82}
              path85={avatarSvgrepoComProps.path85}
              path86={avatarSvgrepoComProps.path86}
              path87={avatarSvgrepoComProps.path87}
              path89={avatarSvgrepoComProps.path89}
            />
          </div>
          <img className="line-1-10" src={line1} />
          <div className="overlap-group3-28" style={{ backgroundImage: `url(${overlapGroup3})` }}>
            <div className="flex-row-52">
              <div className="main-products-list-1 poppins-semi-bold-everglade-30px">{mainProductsList2}</div>
              <div className="search-8 poppins-semi-bold-cape-cod-18px">{search}</div>
              <div className="rectangle-2112-7"></div>
              <div className="overlap-group7-13">
                <a href="javascript:ShowOverlay('add-sub-category', 'animate-appear');">
                  <div className="group-38-2">
                    <div className="add-product-3 poppins-medium-white-18px">{addProduct}</div>
                  </div>
                </a>
                <div className="plus-svgrepo-com-1-7" style={{ backgroundImage: `url(${plusSvgrepoCom1})` }}></div>
              </div>
            </div>
            <div className="overlap-group5-19 poppins-medium-cape-cod-18px">
              <div className="text-29">{text29}</div>
              <div className="category-5">{category}</div>
              <div className="product-name-4">{productName}</div>
              <div className="product-image-2">{productImage}</div>
              <div className="cart-id">{cartId}</div>
              <div className="action-5">{action}</div>
            </div>
            <div className="overlap-group8-13">
              <div className="number-159 poppins-normal-cape-cod-18px">{number1}</div>
              <div className="fruits-15 poppins-semi-bold-dell-18px">{fruits1}</div>
              <div className="place-3 poppins-semi-bold-dell-18px">{place}</div>
              <img className="x4-41" src={x44} />
              <div className="number-160 poppins-semi-bold-dell-18px">{number2}</div>
              <a href="javascript:ShowOverlay('edit-sub-category', 'animate-appear');">
                <img className="text-edit-27" src={textEdit1} />
              </a>
              <img className="bin-svgrepo-com-5" src={binSvgrepoCom1} />
            </div>
            <div className="overlap-group6-18">
              <div className="rectangle-210-1"></div>
              <div className="number-157 poppins-normal-cape-cod-18px">{number3}</div>
              <div className="number-158 poppins-semi-bold-dell-18px">{number4}</div>
              <div className="fruits-14 poppins-semi-bold-dell-18px">{fruits2}</div>
              <div className="apple-3 poppins-semi-bold-dell-18px">{apple}</div>
              <img className="text-edit-26" src={textEdit2} />
              <img className="bin-svgrepo-com-4" src={binSvgrepoCom2} />
              <img className="x5-2" src={x5} />
            </div>
            <div className="overlap-group4-24">
              <div className="rectangle-210-1"></div>
              <div className="rectangle-2103-2"></div>
              <div className="rectangle-2104-2"></div>
              <img className="path-74-5" src={path74} />
              <div className="number-157 poppins-normal-cape-cod-18px">{number5}</div>
              <div className="number-161 poppins-normal-cape-cod-18px">{number6}</div>
              <div className="number-162 poppins-normal-cape-cod-18px">{number7}</div>
              <div className="number-158 poppins-semi-bold-dell-18px">{number8}</div>
              <div className="number-163 poppins-semi-bold-dell-18px">{number9}</div>
              <div className="number-164 poppins-semi-bold-dell-18px">{number10}</div>
              <div className="fruits-14 poppins-semi-bold-dell-18px">{fruits3}</div>
              <div className="fruits-16 poppins-semi-bold-dell-18px">{fruits4}</div>
              <div className="vegitables-5 poppins-semi-bold-dell-18px">{vegitables}</div>
              <div className="color-3 poppins-semi-bold-dell-18px">{color}</div>
              <div className="grapes-4 poppins-semi-bold-dell-18px">{grapes}</div>
              <div className="spinach-3 poppins-semi-bold-dell-18px">{spinach}</div>
              <img className="text-edit-26" src={textEdit3} />
              <img className="text-edit-28" src={textEdit4} />
              <img className="text-edit-29" src={textEdit5} />
              <img className="bin-svgrepo-com-4" src={binSvgrepoCom3} />
              <img className="bin-svgrepo-com-6" src={binSvgrepoCom4} />
              <img className="bin-svgrepo-com-7" src={binSvgrepoCom5} />
              <img className="x6-1" src={x6} />
              <img className="x7-1" src={x7} />
              <img className="x8-1" src={x8} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainProductList;
