import React from "react";
import "./BinSvgrepoCom.css";

function BinSvgrepoCom(props) {
  const { className } = props;

  return (
    <div className={`bin-svgrepo-com ${className || ""}`}>
      <div className="group-container">
        <div className="group-17"></div>
        <div className="group-23"></div>
        <div className="group-19"></div>
      </div>
      <div className="group-container-1">
        <div className="group-21"></div>
        <div className="group-25"></div>
      </div>
      <div className="group-container-2">
        <div className="group-29"></div>
        <div className="group-31"></div>
      </div>
    </div>
  );
}

export default BinSvgrepoCom;
