import React from "react";
import { Link } from "react-router-dom";
import Group35 from "../Group35";
import AvatarSvgrepoCom from "../AvatarSvgrepoCom";
import B from "../B";
import "./CategoryList.css";

function CategoryList(props) {
  const {
    x18,
    leaf11,
    dashboard,
    productManagement,
    orderManagement,
    manageNotifications,
    adminPanel,
    x41,
    x42,
    x43,
    leaf12,
    leaf2,
    untitledDesign,
    laptopSvgrepoCom,
    iconUser,
    sellProductSvgrepoCom,
    menuOrderSvgrepoCom,
    iconNotifications,
    categoryManagement,
    categoryAltSvgrepoCom,
    categoryLists,
    enterArrowSvgrepoCom,
    welcome,
    admin,
    path77,
    path78,
    line1,
    overlapGroup2,
    categoryList,
    search,
    addCategory,
    plusSvgrepoCom1,
    text2,
    category,
    categoryImage,
    categoryId,
    action,
    number1,
    number2,
    number3,
    number4,
    number5,
    number6,
    fruits,
    vegitables,
    breads,
    textEdit1,
    textEdit2,
    textEdit3,
    iconTrash1,
    iconTrash2,
    iconTrash3,
    untitledDesign19,
    x20,
    x21,
    path74,
    x22,
    number7,
    number8,
    surname,
    textEdit4,
    iconTrash4,
    number9,
    number10,
    number11,
    number12,
    avatarSvgrepoComProps,
    b1Props,
    b2Props,
    b3Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="category-list screen">
        <div className="overlap-group11-4">
          <div className="overlap-group3-8">
            <div className="rectangle-2-5"></div>
            <img className="x18-5" src={x18} />
            <div className="rectangle-1-5"></div>
            <img className="leaf1-10" src={leaf11} />
            <Link to="/dashboard-pending-orders">
              <div className="rectangle-3-1"></div>
            </Link>
            <div className="rectangle-6-2"></div>
            <div className="rectangle-7-2"></div>
            <div className="rectangle-8-2"></div>
            <div className="dashboard-2 poppins-medium-don-juan-17px">{dashboard}</div>
            <div className="product-management-2 poppins-medium-don-juan-17px">{productManagement}</div>
            <div className="order-management-5 poppins-medium-don-juan-17px">{orderManagement}</div>
            <div className="manage-notifications-5 poppins-medium-don-juan-17px">{manageNotifications}</div>
            <div className="admin-panel-5 poppins-semi-bold-chicago-33px">{adminPanel}</div>
            <img className="x4-15" src={x41} />
            <img className="x4-16" src={x42} />
            <img className="x4-17" src={x43} />
            <img className="leaf1-11" src={leaf12} />
            <img className="leaf2-5" src={leaf2} />
            <img className="untitled-design-6" src={untitledDesign} />
            <img className="laptop-svgrepo-com-2" src={laptopSvgrepoCom} />
            <Group35 />
            <img className="icon-user-3" src={iconUser} />
            <img className="sell-product-svgrepo-com-5" src={sellProductSvgrepoCom} />
            <img className="menu-order-svgrepo-com-6" src={menuOrderSvgrepoCom} />
            <img className="icon-notifications-3" src={iconNotifications} />
            <div className="rectangle-5-2"></div>
            <div className="category-management-2 poppins-medium-white-17px">{categoryManagement}</div>
            <img className="category-alt-svgrepo-com-2" src={categoryAltSvgrepoCom} />
            <div className="category-lists poppins-medium-lemon-glacier-14px">{categoryLists}</div>
            <img className="enter-arrow-svgrepo-com-3" src={enterArrowSvgrepoCom} />
            <div className="welcome-5 poppins-medium-don-juan-14px">{welcome}</div>
            <div className="admin-5 poppins-medium-don-juan-14px">{admin}</div>
            <div className="path-container-6">
              <img className="path-77-2" src={path77} />
              <img className="path-78-2" src={path78} />
            </div>
            <AvatarSvgrepoCom
              path82={avatarSvgrepoComProps.path82}
              path85={avatarSvgrepoComProps.path85}
              path86={avatarSvgrepoComProps.path86}
              path87={avatarSvgrepoComProps.path87}
              path89={avatarSvgrepoComProps.path89}
            />
          </div>
          <img className="line-1-3" src={line1} />
          <div className="overlap-group2-9" style={{ backgroundImage: `url(${overlapGroup2})` }}>
            <div className="flex-row-1">
              <div className="category-list-1 poppins-semi-bold-everglade-30px">{categoryList}</div>
              <div className="search-2 poppins-semi-bold-cape-cod-18px">{search}</div>
              <div className="rectangle-2112-2"></div>
              <div className="overlap-group9-3">
                <a href="javascript:ShowOverlay('add-category', 'animate-appear');">
                  <div className="group-47">
                    <a href="javascript:ShowOverlay('add-category', 'animate-appear');">
                      <div className="group-38">
                        <div className="add-category poppins-medium-white-18px">{addCategory}</div>
                      </div>
                    </a>
                  </div>
                </a>
                <div className="plus-svgrepo-com-1" style={{ backgroundImage: `url(${plusSvgrepoCom1})` }}></div>
              </div>
            </div>
            <div className="overlap-group4-5">
              <div className="rectangle-10-1"></div>
              <div className="text-2 poppins-medium-cape-cod-18px">{text2}</div>
              <div className="category poppins-medium-cape-cod-18px">{category}</div>
              <div className="category-image poppins-medium-cape-cod-18px">{categoryImage}</div>
              <div className="category-id poppins-medium-cape-cod-18px">{categoryId}</div>
              <div className="action poppins-medium-cape-cod-18px">{action}</div>
              <div className="rectangle-11-1"></div>
              <div className="rectangle-2101"></div>
              <div className="rectangle-2102"></div>
              <div className="number-71 poppins-normal-cape-cod-18px">{number1}</div>
              <div className="number-72 poppins-normal-cape-cod-18px">{number2}</div>
              <div className="number-73 poppins-normal-cape-cod-18px">{number3}</div>
              <div className="number-74 poppins-semi-bold-dell-18px">{number4}</div>
              <div className="number-75 poppins-semi-bold-dell-18px">{number5}</div>
              <div className="number-76 poppins-semi-bold-dell-18px">{number6}</div>
              <div className="fruits poppins-semi-bold-dell-18px">{fruits}</div>
              <div className="vegitables poppins-semi-bold-dell-18px">{vegitables}</div>
              <div className="breads poppins-semi-bold-dell-18px">{breads}</div>
              <a href="javascript:ShowOverlay('edit-category', 'animate-appear');">
                <img className="text-edit-10" src={textEdit1} />
              </a>
              <img className="text-edit-11" src={textEdit2} />
              <img className="text-edit-12" src={textEdit3} />
              <img className="icon-trash-11" src={iconTrash1} />
              <img className="icon-trash-12" src={iconTrash2} />
              <img className="icon-trash-13" src={iconTrash3} />
              <img className="untitled-design-19" src={untitledDesign19} />
              <img className="x20" src={x20} />
              <img className="x21" src={x21} />
              <B className={b1Props.className} />
              <B className={b2Props.className} />
              <B className={b3Props.className} />
            </div>
            <div className="overlap-group5-2">
              <div className="overlap-group-43">
                <img className="path-74" src={path74} />
                <img className="x22" src={x22} />
              </div>
              <div className="number-77 poppins-normal-cape-cod-18px">{number7}</div>
              <div className="number-78 poppins-semi-bold-dell-18px">{number8}</div>
              <div className="surname poppins-semi-bold-dell-18px">{surname}</div>
              <img className="text-edit-13" src={textEdit4} />
              <img className="icon-trash-14" src={iconTrash4} />
            </div>
            <div className="overlap-group-container-5">
              <div className="overlap-group8-4">
                <div className="number-79 poppins-medium-shady-lady-15px">{number9}</div>
              </div>
              <div className="overlap-group-42">
                <div className="number-70 poppins-medium-shady-lady-15px">{number10}</div>
              </div>
              <div className="overlap-group-42">
                <div className="number-70 poppins-medium-shady-lady-15px">{number11}</div>
              </div>
              <div className="overlap-group6-4">
                <div className="number-80 poppins-medium-shady-lady-15px">{number12}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CategoryList;
