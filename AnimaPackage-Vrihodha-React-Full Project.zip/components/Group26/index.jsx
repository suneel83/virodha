import React from "react";
import "./Group26.css";

function Group26(props) {
  const { className } = props;

  return (
    <div className={`group-26 ${className || ""}`}>
      <div className="overlap-group-78">
        <div className="group-17-4">
          <div className="add-to-cart-1 poppins-semi-bold-eerie-black-19px">Add to Cart</div>
        </div>
        <img className="greater-than-svgrepo-com-2" src="/img/greater-than-svgrepo-com-1@1x.png" />
      </div>
    </div>
  );
}

export default Group26;
