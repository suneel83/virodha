import React from "react";
import "./AddCategory.css";

function AddCategory(props) {
  const { addCategory, plusSvgrepoCom1, categoryName, categoryImage, description, upload, close, add } = props;

  return (
    <div className="container-center-horizontal">
      <div className="add-category-1 screen">
        <div className="overlap-group-61">
          <div className="add-category-2 poppins-semi-bold-cape-cod-21px">{addCategory}</div>
          <div className="overlap-group2-19 border-0-5px-dove-gray">
            <div className="plus-svgrepo-com-1-5" style={{ backgroundImage: `url(${plusSvgrepoCom1})` }}></div>
          </div>
          <div className="flex-row-33">
            <div className="flex-col-22 poppins-medium-cape-cod-13px">
              <div className="category-name-2">{categoryName}</div>
              <div className="category-image-2">{categoryImage}</div>
              <div className="description-3">{description}</div>
            </div>
            <div className="flex-col-23">
              <div className="rectangle-2108"></div>
              <div className="overlap-group4-16">
                <div className="rectangle-2111-3"></div>
                <div className="upload-3 poppins-normal-white-12px">{upload}</div>
              </div>
              <div className="rectangle-2110"></div>
              <div className="overlap-group-container-13">
                <div className="overlap-group5-11">
                  <div className="close-4 poppins-medium-cape-cod-15px">{close}</div>
                </div>
                <div className="overlap-group3-20">
                  <div className="add-1 poppins-medium-romance-15px">{add}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AddCategory;
